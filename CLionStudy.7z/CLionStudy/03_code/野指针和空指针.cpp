// Created by 黑马程序员.
#include "iostream"
using namespace std;


int main()
{
    int *p;     // 声明了一个指针变量（p就被分配了8个字节的空间）

//    int *p1 = NULL;     // 将指针标记为空
//    int *p2 = nullptr;     // 将指针标记为空
//
//    *p1 = 10;
//    *p2 = 10;

    cout << p << endl;
    cout << "hello" << endl;
    return 0;
}
