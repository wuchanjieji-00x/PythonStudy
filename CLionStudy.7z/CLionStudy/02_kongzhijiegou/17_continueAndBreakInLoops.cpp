// #include "iostream"
// #include "random"
// using namespace std;
//
// int get_random_num(int min, int max){
//     // 创建一个随机数生成器
//     random_device rd;
//     mt19937 gen(rd());
//
//     // 定义一个均匀分布的整数范围
//     uniform_int_distribution<> dis(min, max);
//
//     // 生成一个随机数并输出
//     int random_number = dis(gen);
//     return random_number;
// }
//
// int main() {
//
//
//     // continue : 跳过本次循环，进入下一次循环流程
//     // break: 直接跳出所在循环的执行
//
//     // // 1.通过for循环输出1-20之间的奇数
//     // for (int i = 1; i <= 20; i++) {
//     //     if (i % 2 == 0) {
//     //         continue; // 跳过本次循环，进入下一次。筛掉偶数，不输出
//     //     }
//     //     cout << i << endl;
//     // }
//
//     // // 2.通过for循环输出1-10的整数
//     // for (int i = 1; true; i++) {
//     //     if (i == 20) {
//     //         break;
//     //     }
//     //     cout << i << endl;
//     // }
//
//     // // 3.通过while循环输出1-20的偶数
//     // int i = 1;
//     // while (i <= 20) {
//     //     if (i % 2 == 1) {
//     //         i++; // 体会这里的i++的含义
//     //         continue; // 这里的continue会把下面的i++也给跳过，if是判断，不是循环，这个continue还是属于while循环
//     //     }
//     //     cout << i << endl;
//     //     i++;
//     // }
//
//     // // 4. continue和break关键字只能控制所在循环（如果是内层，则只控制内层，不能控制外层）
//     // for (int j = 1; j <= 5; j++) {
//     //     int i = 1;
//     //     while (i <= 20) {
//     //         if (i % 2 == 0) {
//     //             i++; // 体会这里的i++的含义
//     //             break; // 这里的continue会把下面的i++也给跳过，if是判断，不是循环，这个continue还是属于while循环
//     //         }
//     //         cout << i << endl;
//     //         i++;
//     //     }
//     // }
//
//
//     // 练习
//
//     // for (int i = 1; i <= 30; i++) {
//     //
//     //     cout << "今天是表白的第" << i << "天, 给小美送花" << endl;
//     //     int num1 = get_random_num(1, 10);
//     //     cout << num1 << endl;
//     //     int num2 = get_random_num(1, 2);
//     //     cout << num2 << endl;
//     //     if (num1 == 1) {
//     //         cout << "小美，你别生气，我以后再也不烦你了,拜拜" << endl;
//     //         break;
//     //     }else if (num2 == 1) {
//     //         cout << "小美你别生气，我今天不表白了，明天再来" << endl;
//     //         continue;
//     //     }else {
//     //         cout << "小美我喜欢你，我们看电影去吧。" << endl;
//     //     }
//
//
//     }
//
//
//
//     return 0;
// }