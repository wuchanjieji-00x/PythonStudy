// #include "iostream"
//
// using namespace std;
//
// int main() {
//
//     // int num;
//     // cout << "请输入一个数字来确定是星期几（1~7）：" << endl;
//     // cin >> num;
//     //
//     // switch (num) {
//     //     case 1:
//     //         cout << "今天是星期一" << endl;
//     //         break;
//     //     case 2:
//     //         cout << "今天是星期二" << endl;
//     //         break;
//     //     case 3:
//     //         cout << "今天是星期三" << endl;
//     //         break;
//     //     case 4:
//     //         cout << "今天是星期四" << endl;
//     //         break;
//     //     case 5:
//     //         cout << "今天是星期五" << endl;
//     //         break;
//     //     case 6:
//     //         cout << "今天是星期六" << endl;
//     //         break;
//     //     case 7:
//     //         cout << "今天是星期日" << endl;
//     //         break;
//     //     default:
//     //         cout << "输入错误" << endl;
//     // }
//
//
//
//     // // 贯穿
//     // int num;
//     // cout << "请给电影打分10/9：优秀；8/7/6：普通； 5：一般； 低于5：垃圾电影：" << endl;
//     // cin >> num;
//     //
//     // switch(num) {
//     //     case 10:
//     //     case 9:
//     //         cout << "优秀" << endl;
//     //         break;
//     //     case 8:
//     //     case 7:
//     //     case 6:
//     //         cout << "普通" << endl;
//     //         break;
//     //     case 5:
//     //         cout << "一般" << endl;
//     //         break;
//     //     default:
//     //         cout << "垃圾电影" << endl;
//     //
//     // }
//
//
//     // // 练习
//     // int num;
//     // cout << "请选择直播的场景，输入对应的场景代码数字。" << endl;
//     // cout << "1仅输出屏幕，2输出屏幕+摄像头画面， 3仅输出摄像头：" << endl;
//     // cin >> num;
//     //
//     // switch(num) {
//     //     case 1:
//     //         cout << "已经切换场景1，用户只能看到屏幕画面" << endl;
//     //         break;
//     //     case 2:
//     //         cout << "已经切换场景2，用户可以看到屏幕和摄像头画面" << endl;
//     //         break;
//     //     case 3:
//     //         cout << "已经切换场景3，用户只能看到摄像头画面" << endl;
//     //         break;
//     //     default:
//     //         cout << "您输入的代码有无，无法识别具体场景" << endl;
//     // }
//
//
//     return 0;
// }
