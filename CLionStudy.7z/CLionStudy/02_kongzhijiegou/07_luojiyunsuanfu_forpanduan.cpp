// #include "iostream"
//
// using namespace std;
//
// int main() {
//
//
//     // // ! 非
//     // int num = 1;
//     // if (!num) {
//     //     cout << "if被执行" << endl;
//     //
//     // }else {
//     //     cout << "else被执行" << endl;
//     // }
//
//     // // && 与
//     // int age, height;
//     // cout << "请输入年龄：" << endl;
//     // cin >> age;
//     // cout << "请输入身高(cm)：" << endl;
//     // cin >> height;
//     // if (age < 18 && height < 120) {
//     //     cout << "你符合条件" << endl;
//     // }else {
//     //     cout << "你不符合条件" << endl;
//     // }
//
//     // // || 或
//     // int age, height;
//     // cout << "请输入年龄：" << endl;
//     // cin >> age;
//     // cout << "请输入身高(cm)：" << endl;
//     // cin >> height;
//     // if (age < 18 || height < 120) {
//     //     cout << "你符合条件" << endl;
//     // }else {
//     //     cout << "你不符合条件" << endl;
//     // }
//
//
//     return 0;
// }