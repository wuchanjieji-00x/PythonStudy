// #include "iostream"
//
// using namespace std;
//
// int main() {
//
//
//     int i = 1;
//     while (i < 10) {
//         int j = 1;
//         while (j <= i) {
//             cout << j << "x" << i << "=" << j * i << "\t";
//             j ++;
//         }
//         cout << endl;
//         i ++;
//     }
//
//
//     return 0;
// }
