// #include "iostream"
//
// using namespace std;
//
// int main() {
//
//
//     // // for循环输出九九乘法表
//     // for (int i = 1; i < 10; i++) {
//     //     for (int j = 1; j <= i; j++) {
//     //         cout << j << "x" << i << "=" << j * i << "\t";
//     //     }
//     //     cout << endl;
//     // }
//
//
//     // 练习
//     // 通过for和while的混合嵌套完成九九乘法表的输出
//
//     // // 方式1：
//     // for (int i = 1; i < 10; i++) {
//     //     int j = 1;
//     //     while (j <= i) {
//     //         cout << j << "x" << i << "=" << j * i << "\t";
//     //         j++;
//     //     }
//     //     cout << endl;
//     // }
//
//     // // 方式2：
//     // int i = 1;
//     // while (i < 10) {
//     //     for (int j = 1; j <= i; j++) {
//     //         cout << j << "x" << i << "=" << j * i << "\t";
//     //     }
//     //     cout << endl;
//     //     i++;
//     // }
//
//     return 0;
// }
