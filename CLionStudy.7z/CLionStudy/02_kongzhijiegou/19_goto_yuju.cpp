// #include "iostream"
//
// using namespace std;
//
// int main() {
//
//     /*
//      * label A:
//      * code
//      *
//      *label B:
//      *code
//      *
//      *goto A/B/C
//      *
//      *
//      *label C
//      *code
//      *
//      */
//
//     // // 基础的goto语句
//     // a:
//     // cout << "a" << endl;
//     //
//     // b:
//     // cout << "b" << endl;
//     //
//     // goto d;  // 无条件任意跳转到指定标签
//     //
//     // c:
//     // cout << "c" << endl;
//     // d:
//     // cout << "d" << endl;
//
//     // // goto语句实现for循环
//     // int i = 1;
//     // Loop:
//     // cout << i << endl;
//     // i++;
//     // if (i <= 10) {
//     //     goto Loop;
//     // }
//
//
//
//
//     return 0;
// }
