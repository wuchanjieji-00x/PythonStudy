// #include "iostream"
//
// using namespace std;
//
// int main() {
//
//     /*
//      * if (条件判断1)
//      * {}
//      * else if (条件判断2)
//      * {}
//      * else if (条件判断3)
//      *
//      *
//      * ...
//      * else
//      * {}
//      */
//      // bool xiaomei = false;
//      // bool xiaotian = false;
//      // if (xiaomei) {
//      //     cout << "小美我也喜欢你" << endl;
//      // }
//      // else if (xiaotian) {
//      //     cout << "小甜我也喜欢你" << endl;
//      // }
//      // else {
//      //     cout << " neither xiaomei nor xiaotian" << endl;
//      // }
//
//
//     // // 练习
//     // // 1. 定义一个变量，数字类型，内容随意（1~10范围），基于 cin 语句输入猜想的数字，判断输入的数字是猜对或猜大、 猜小了
//     // int guess;
//     // int a = 3;
//     // cout << "请输入一个猜想的数字（1~10）:" << endl;
//     // cin >> guess;
//     //
//     // if (guess == a) {
//     //     cout << "你猜对了，真棒！" << endl;
//     // }
//     // else if (guess > a){
//     //     cout << "你猜大了！！！" << endl;
//     // }
//     // else {
//     //
//     //     cout << "你猜小了！！！" << endl;
//     // }
//     //
//
//
//     return 0;
// }