// #include "iostream"
// #include "random"
// using namespace std;
//
// int get_random_num(int min, int max){
//     // 创建一个随机数生成器
//     random_device rd;
//     mt19937 gen(rd());
//
//     // 定义一个均匀分布的整数范围
//     uniform_int_distribution<> dis(min, max);
//
//     // 生成一个随机数并输出
//     int random_number = dis(gen);
//     return random_number;
// }
//
// int main() {
//
//     /*
//      * for (1.循环因子初始化语句; 2.条件判断; 4.循环因子更新){
//      *     // 3.循环体
//      *     code;
//      *     ...
//      *     ...
//
//      * }
//
//      */
//
//     // // 1.基础for循环，打印1-10d的数字
//     // for (int i = 1; i <= 10; i++) {
//     //     cout << i << endl;
//     // }
//
//     // // 2.进阶for循环，打印1-20之间的奇数
//     // for (int i = 1; i <= 20; i+=2) {
//     //     cout << i << endl;
//     // }
//
//     // 3.for循环（）内的是三个部分，可以按照需求省略
//     // 省略条件判断（无限循环）//分号不可以省略
//     // for (int i = 0; ; ++i) {
//     //
//     //     cout << i << endl;
//     // }
//
//     // 省略循环因子的初始化（分号不可以省略）
//     // 虽然可以在for循环（）中省略，但是还是需要声明和初始化循环控制因子，所以还是尽量不要省略
//     // int i = 0;
//     // for (; i < 10; ++i) {
//     //     cout << i << endl;
//     // }
//
//     // 省略循环控制因子的更新
//     // 还是无尽循环
//     // for (int i = 0; i < 10; ) {
//     //
//     //     cout << i << endl;
//     //     i++; // 循环因子的更新可以写在这里
//     // }
//
//
//     // 练习
//     // // 基础for循环练习：求1-100偶数之和
//     // // 使用for循环，从1开始到100结束，累加偶数之和。
//     // int sum = 0;
//     // for (int i = 0; i <= 100; i += 2) {
//     //     sum += i;
//     // }
//     // cout << sum << endl;
//
//     //
//     // // 练习
//     // // 进阶for循环案例：猜数字
//     // int num = get_random_num(1, 10);
//     // cout << num << endl;
//     //
//     // int guess_num;
//     // cout << "请输入一个数字（1~100）：" << endl;
//     // cin >> guess_num;
//     //
//     // // int times;
//     // // for (times = 0; guess_num != num; ) {
//     // //     times++;
//     // //     if (guess_num > num) {
//     // //         cout << "猜大了，请再猜一次：" << endl;
//     // //         cin >> guess_num;
//     // //     }else {
//     // //         cout << "猜小了，请再猜一次：" << endl;
//     // //         cin >> guess_num;
//     // //     }
//     // for (bool is_continue = true; is_continue;) {
//     //     if (guess_num == num) {
//     //         cout << "猜对了" << endl;
//     //     }else if (guess_num > num) {
//     //         cout << "猜大了，请再猜一次：" << endl;
//     //         cin >> guess_num;
//     //     }else {
//     //         cout << "猜小了，请再猜一次：" << endl;
//     //         cin >> guess_num;
//     //     }
//     //
//     // }
//     //
//     // cout << "猜对了，一共猜了" << times << "次" << endl;
//
//     return 0;
// }
