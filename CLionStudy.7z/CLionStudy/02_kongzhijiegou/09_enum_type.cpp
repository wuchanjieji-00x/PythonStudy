// #include "iostream"
//
// using namespace std;
//
// int main() {
//
//
//     /*
//      *enum + 枚举类型名称{
//      *枚举元素,
//      *枚举元素，
//      *...
//      *}
//      *
//      *
//      */
//
//     // enum其实是创建了一个数组，把要评估的变量的所有的可能性都列出来放到enum数组中
//     // 默认enum数组中，第一个元素 == 0，以此类推，
//     // 在switch语句中，case + enum元素 = case + enum元素的下标（从0开始计数）
//     // 当然，enum的下标不同于数组中的下标，这个所谓的下标值是可以任意更改的，
//     // 也就是说，你可以任意将enum元素的值赋予任何整型（int short char）
//
//
//     // 询问小朋友喜欢的颜色：红黄蓝三种选1个
//     enum Color {
//         RED,    // 默认是0
//         YELLOW, // 默认是1
//         BULL   // 默认是2
//     };
//
//     // 更改enum数组元素对应的值
//     // enum Color {
//     //     RED = 5,    // 5
//     //     YELLOW, // 6
//     //     BULL   // 7
//     // };
//
//     // enum Color {
//     //     RED = 5,    // 5
//     //     YELLOW = 10, // 10
//     //     BULL = 15   // 15
//     // };
//
//
//     int num;
//     cout << "小朋友，请输入你喜欢的颜色：0是红色，1是黄色，2是蓝色：" << endl;
//     cin >> num;
//
//     switch (num) {
//         case RED:  // case  0
//             cout << "小朋友，你喜欢红色" << endl;
//             break;
//         case YELLOW: // case 1
//             cout << "小朋友，你喜欢黄色" << endl;
//             break;
//         case BULL: // case 2
//             cout << "小朋友，你喜欢蓝色" << endl;
//             break;
//         default:
//             cout << "不好意思，你输入的数字有误" << endl;
//     }
//
//     return 0;
// }