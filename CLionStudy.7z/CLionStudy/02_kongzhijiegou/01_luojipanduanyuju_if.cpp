// #include "iostream"
//
// using namespace std;
//
// int main() {
//
//     /*
//      * if (判断 输出 bool结果)：
//      * {
//      *      code;
//      *      code;
//      *      ...
//      * }
//      *
//      */
//     // cout << "今天发工资了！" << endl;
//     // int money;
//     // cout << "请输入小明发的工资：" << endl;
//     // cin >> money;
//     //
//     // if (money > 10000) {
//     //     // 满足条件会执行这里的代码
//     //     cout << "买个新电脑去，TMD！花费了9900元！" << endl;
//     //     money -= 9900;
//     //
//     // }
//     // cout << "今天发的工资还剩下：" << money << "元！" << endl;
//
//
//     // // 练习
//     // cout << "欢迎来到黑马游乐园，儿童免费，成人收费！" << endl;
//     //
//     // int age;
//     // cout << "请输入您的年龄：" << endl;
//     // cin >> age;
//     //
//     // if (age < 18) {
//     //     cout << "您未成年，免费游玩，欢迎你小朋友！" << endl;
//     //
//     // }
//     // cout << "祝您游玩愉快！！！" << endl;
//
//
//
//
//     return 0;
// }
