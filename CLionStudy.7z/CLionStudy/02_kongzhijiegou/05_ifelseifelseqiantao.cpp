// #include "iostream"
//
// using namespace std;
//
// int main() {
//
//     // int love; // 1表示喜欢，0表示不喜欢
//     // int weather; // 1表示好天气，0表示坏天气
//     // cout << "小美你喜欢我吗？1是喜欢，0是不喜欢：" << endl;
//     // cin >> love;
//     //
//     // if (love) {
//     //     // 小美喜欢我
//     //     cout << "很高兴，我也喜欢你小美！" << endl;
//     //     cout << "看一下今天的天气怎么样？1是好天气，0是坏天气：" << endl;
//     //     cin >> weather;
//     //     if (weather) {
//     //         cout << "今天是个好天气，带小美一起去踏青" << endl;
//     //     }
//     //     else {
//     //         cout << "今天天气不好，还是看电影去吧" << endl;
//     //     }
//     // }
//     // else {
//     //     cout << "伤心，我去追求小新了！" << endl;
//     // }
//
//
//     // // 练习
//     // int num = 10;
//     // int guess;
//     //
//     // cout << "请输入第一次猜想的数字：" << endl;
//     // cin >> guess;
//     //
//     // if (guess == num) {
//     //     cout << "第一次就猜对了，真棒！" << endl;
//     // }
//     // else {
//     //     cout << "不对，请再猜一次: " << endl;
//     //     cin >> guess;
//     //
//     //     if (guess == num) {
//     //         cout << "第二次猜对了，你真棒！" << endl;
//     //     }
//     //     else {
//     //         cout << "不对，请猜最后一次: " << endl;
//     //         cin >> guess;
//     //
//     //         if (guess == num) {
//     //             cout << "第三次猜对了，真棒！" << endl;
//     //         }
//     //         else {
//     //             cout << "sorry，全部猜错了，我想的是：" << num << endl;
//     //         }
//     //     }
//     //
//     // }
//
//
//
//     return 0;
// }
