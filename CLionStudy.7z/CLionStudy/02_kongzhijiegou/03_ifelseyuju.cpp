// #include "iostream"
//
// using namespace std;
//
// int main() {
//
//     /*
//      * if (判断)
//      * {
//      *      ...
//      * }
//      *else
//      *{
//      *      ...
//      *}
//      *
//      */
//     // int love;
//     // cout << "小美你喜欢我吗？喜欢扣1，不喜欢扣0：" << endl;
//     // cin >> love;
//     //
//     // if (love) // if (love == 1)
//     // {
//     //     cout << "我也喜欢你！！！" << endl;
//     // }
//     // else
//     // {
//     //     cout << "我也不喜欢你" << endl;
//     // }
//
//     //
//     // // 练习 with AI
//     // int height;
//     // // 输出欢迎语
//     // cout << "欢迎来到黑马动物园" << endl;
//     // cout << "请输入你的身高(cm)：" << endl;
//     // cin >> height;
//     //
//     // if ( height >= 120) {
//     //     cout << "您的身高超出120cm，游玩需要购票10元" << endl;
//     // }
//     // else {
//     //     cout << "您的身高未超出120cm，游玩免费" << endl;
//     // }
//     //
//     // // 输出祝愿语
//     // cout << "祝您玩得愉快" << endl;
//
//
//
//
//
//
//     return 0;
// }