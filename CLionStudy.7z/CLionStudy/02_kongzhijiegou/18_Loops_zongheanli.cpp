// #include "iostream"
// #include "random"
// using namespace std;
//
// int get_random_num(int min, int max){
//     // 创建一个随机数生成器
//     random_device rd;
//     mt19937 gen(rd());
//
//     // 定义一个均匀分布的整数范围
//     uniform_int_distribution<> dis(min, max);
//
//     // 生成一个随机数并输出
//     int random_number = dis(gen);
//     return random_number;
// }
//
// int main() {
//
//     int salary = 10000;
//     for (int i = 1; i <= 20; i++) {
//
//         // 判断余额还有没有
//         if (salary == 0) {
//             cout << "工资发完了，下个月领取吧" << endl;
//             break;
//         }
//
//         int num1 = get_random_num(1, 10); // 绩效分
//         cout << num1 << endl;
//
//         if (num1 < 5) {
//             cout << "员工" << i << ", 绩效分" << num1 << "，低于5，不发工资，下一位。" << endl;
//             continue;
//         }
//         // 开始发工资了
//         salary -= 1000;
//         cout << "向员工" << i << "发放工资1000元，账户余额" << salary << "元" << endl;
//
//     }
//
//     return 0;
// }
