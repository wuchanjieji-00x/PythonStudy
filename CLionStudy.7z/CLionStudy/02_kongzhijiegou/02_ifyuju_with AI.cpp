// #include "iostream"
//
// using namespace std;
//
// int main() {
//
//     // 先定义一个变量记录年龄
//     int age;
//
//     // 输出欢迎语
//     cout << "欢迎来到黑马游乐场，儿童免费" << endl;
//     // 提示用户输入年龄
//     cout << "请输入您的年龄：" << endl;
//     // 通过cin获取年龄，并给age 赋值
//     cin >> age;
//
//     // 通过if 判断年龄是否大于18
//     if (age > 18) {
//         // 如果大于18，则提示用户需要购买门票
//         cout << "您需要购买门票" << endl;
//     } else {
//         // 如果小于18，则提示用户免费
//         cout << "您是儿童，免费" << endl;
//     }
//
//     return 0;
// }
