// #include "iostream"
// #include "random"
// using namespace std;
//
//
// int get_random_num(int min, int max){
//     // 创建一个随机数生成器
//     random_device rd;
//     mt19937 gen(rd());
//
//     // 定义一个均匀分布的整数范围
//     uniform_int_distribution<> dis(min, max);
//
//     // 生成一个随机数并输出
//     int random_number = dis(gen);
//     return random_number;
// }
//
// int main() {
//
//
//     /*
//      * 案例需求（猜扑克牌）:
//      * 随机产出3份信息：
//      * 第一份信息：1~10的数字，代表扑克牌1~10
//      * 第二份信息：字符串，红色或黑色，代表扑克牌的花色
//      * 第三份信息：字符串，如果是红色产出红桃或方块，如果是黑色产出黑桃或梅花
//      * 案例要求:
//      * 通过嵌套判断，并结合判断语句猜测上述信息，如
//      * 先猜数字，成功后猜颜色，再成功猜测具体的花型
//      */
//
//     // 测试产生随机数：
//     // int num = get_random_num(1,10);
//     // cout << num << endl;
//
//
//     // 第一份信息：1~10的数字，代表扑克牌1~10
//     int num = get_random_num(1,10);
//
//     // 第二份信息：字符串，红色或黑色，代表扑克牌的花色
//     string color = get_random_num(0, 1)? "红色" : "黑色";
//
//     //  第三份信息：字符串，如果是红色产出红桃或方块，如果是黑色产出黑桃或梅花
//     string suit;
//     if (color == "红色") {
//         suit  = get_random_num(0, 1)? "红桃": "方块";
//
//     }else {
//         suit = get_random_num(0, 1)? "黑桃": "梅花";
//     }
//     // 测试：
//     cout << num << ": " << color << ": " << suit << endl;
//
//     // 先猜数字，成功后猜花色，再成功的话猜具体的花型
//
//     int guess_num;
//     cout << "请输入猜测的数字（1~10）：" << endl;
//     cin >> guess_num;
//
//     // 首先判断数字猜的是否正确
//     if (guess_num == num) {  // 数字猜对了
//         int guess_color;
//         cout << "数字猜对了，请继续猜测花色(红色是1，黑色是0):" << endl;
//         cin >> guess_color;
//         if ((guess_color? "红色" : "黑色") == color) { // 颜色猜对了
//             int guess_suit;
//             if (guess_color) { // 红色
//                 cout << "颜色也猜对了，请继续猜花型（红桃是1，方块是0）：" << endl;
//                 cin >> guess_suit;
//                 if ((guess_suit? "红桃": "方块") == suit) { // 花型猜对了
//                     cout << "恭喜你，猜对了！" << endl;
//                 }else { // 花型猜错了
//                     cout << "花型猜错了，游戏结束！" << "正确的结果是：" << num << ":" << color << ":" << suit << endl;
//                 }
//             }else { // 黑色
//                 cout << "颜色也猜对了，请继续猜花型（黑桃是1，梅花是0）：" << endl;
//                 cin >> guess_suit;
//                 if ((guess_suit? "黑桃": "梅花") == suit) { // 花型猜对了
//                     cout << "恭喜你，猜对了！" << endl;
//                 }else { // 花型猜错了
//                     cout << "花型猜错了，游戏结束！" << "正确的结果是：" << num << ":" << color << ":" << suit << endl;
//                 }
//             }
//
//         }else { // 颜色猜错了
//             cout << "颜色猜错了，游戏结束！" << endl;
//         }
//     }else { // 数字猜错了
//         cout << "数字猜错了，游戏结束！" << endl;
//     }
//
//
//
//     return 0;
// }