// #include "iostream"
// #include "random"
// using namespace std;
//
// int get_random_num(int min, int max){
//     // 创建一个随机数生成器
//     random_device rd;
//     mt19937 gen(rd());
//
//     // 定义一个均匀分布的整数范围
//     uniform_int_distribution<> dis(min, max);
//
//     // 生成一个随机数并输出
//     int random_number = dis(gen);
//     return random_number;
// }
//
// int main() {
//
//     // 练习：设置一个范围1-100的随机整数变量，通过while循环，配合cin语句，判断输入的数字是否等于随机数
//     int num = get_random_num(1, 100);
//     cout << num << endl;
//
//     int guess_num;
//     int times = 0;
//     cout << "请输入一个数字（1~100）：" << endl;
//     cin >> guess_num;
//     do {
//         times ++;
//         //if (guess_num == num) {
//             // cout << "猜对了，一共猜了" << times << "次" << endl;
//         if (guess_num > num) {
//             cout << "你猜大了，请再猜一次：" << endl;
//             cin >> guess_num;
//         }else {
//             cout << "你猜小了，请再猜一次：" << endl;
//             cin >> guess_num;
//         }
//
//     } while (guess_num != num);
//     cout << "猜对了，一共猜了" << times << "次" << endl;
//
//     return 0;
// }
