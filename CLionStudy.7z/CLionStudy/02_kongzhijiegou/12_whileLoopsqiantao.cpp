// #include "iostream"
// #include "random"
// using namespace std;
//
// int get_random_num(int min, int max){
//     // 创建一个随机数生成器
//     random_device rd;
//     mt19937 gen(rd());
//
//     // 定义一个均匀分布的整数范围
//     uniform_int_distribution<> dis(min, max);
//
//     // 生成一个随机数并输出
//     int random_number = dis(gen);
//     return random_number;
// }
//
// int main() {
//
//
//     /*
//      *while (条件)
//      *{
//      *      //循环体
//      *      ...
//      *      ...
//      *
//      *      while (条件)
//      *      {
//      *          循环体
//      *          ...
//      *          ...
//      *
//      *
//      *      }
//      *
//      *}
//      *
//      *
//      */
//
//     // 演示
//     // bool is_continue = true;
//     // while (is_continue) {
//     //     cout << "今天又是新的一天，开始向小美表白" << endl;
//     //
//     //     // 每一天都表白，每一次都送三朵玫瑰花
//     //     int i = 0;  // 内层循环控制因子
//     //     while (i < 3) {
//     //         cout << "送给小美第" << i + 1 << "朵玫瑰花" << endl;
//     //         i++; // 内层循环控制因子的更新
//     //     }
//     //
//     //     cout << "小美，我喜欢你" << endl;
//     //
//     //     int num = get_random_num(1, 20); // 模拟5%的几率
//     //     cout << num << endl;
//     //     if (num == 7) {
//     //         is_continue = false;
//     //     }
//     //     cout << endl;
//     // }
//     // cout << "总算表白成功了" << endl;
//
//
//     // // 练习
//     // cout << "有点胖需要减掉10斤体重，计划5天，每天目标2斤，加油！" << endl;
//     // int day = 1; // 外层循环的控制因子
//     // int lose_weight = 0; // 体重累加变量，要写到循环的外面做全局变量
//     // // 外层循环完成5天的减肥
//     // while (day <= 5) {
//     //     cout << "今天是减肥的第" << day << "天!" << endl;
//     //
//     //     // 俯卧撑的三次控制
//     //     int times1 = 1; // 第一个内层循环的控制因子
//     //     while (times1 <= 3) {
//     //         cout << "开始做减肥第" << day << "天的第" << times1 << "个俯卧撑！  ";
//     //         times1 ++; // 第一个内层循环控制因子的更新
//     //     }
//     //     cout << endl;
//     //
//     //     lose_weight ++;
//     //     cout << "减肥第" << day << "天的第" << times1 - 1 << "个俯卧撑做完，体重减少1斤, " << "目前累计减少体重：" << lose_weight << "斤!" << endl;
//     //
//     //     // 400米冲刺跑的三次控制
//     //     int times2 = 1; // 第二个内层循环的控制因子
//     //     while (times2 <= 3) {
//     //         cout << "开始做减肥第" << day << "天的第" << times2 << "个400米冲刺跑！  ";
//     //         times2 ++; // 第二个内层循环控制因子的更新
//     //     }
//     //     cout << endl;
//     //
//     //     lose_weight ++;
//     //     cout << "减肥第" << day << "天的第" << times2 - 1 << "个400米冲刺跑完成，体重减少1斤, " << "目前累计减少体重：" << lose_weight << "斤!" << endl;
//     //
//     //     day ++;  // 外层循环的控制因子的更新
//     //     cout << endl;
//     //
//     // }
//     // cout << day - 1 << "天减肥完成，体重累计减少：" << lose_weight << "斤！" << endl;
//
//
//     return 0;
// }
