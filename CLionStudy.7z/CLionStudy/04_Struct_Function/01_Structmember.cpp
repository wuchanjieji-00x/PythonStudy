// #include "iostream"
//
// using namespace std;
//
// /*
//  * 声明语法：
//  *      struct 结构体类型名
//  *      {
//  *          成员类型 成员名;
//  *          ...
//  *          ...
//  *      }
//  *
//  * 特点：
//  *      一个结构体类型，可以包含多个成员（类似数组元素），每个成员类型不限
//  *      可以做到一批不同类型的数据，混装在一个结构体内。
//  *
//  *
//  * 声明一个结构体对象：
//  * 1.struct 结构体类名称 结构体对象名称;
//  * 2.struct 结构体类名称 结构体对象名称 = {结构体成员1，结构体成员2，...}
//  *
//  * 访问方式：
//  * 结构体对象名称.结构体成员
//  * struct Student stu1;
//  * stu1.name   stu1.age   stu1.addr
//  */
//
// int main() {
//
//     // struct Student          // 一种新的数据类型（是我们自己创建的）
//     // {
//     //     string name;        // 成员1 表示姓名
//     //     int age;            // 成员2 表示年龄
//     //     string gender;      // 成员3 表示性别
//     // };
//     //
//     // // 结构体变量的声明，可以在前面带上struct关键字（可以省略不写）
//     // // 建议写上，可以清晰的知道变量是自定义结构体类型的
//     // struct Student stu;            // 结构体变量
//     // stu = {"周杰轮", 11, "男"};
//     //
//     // //    cout << stu << endl; 结构体变量是一个整体的包装，无法直接cout输出
//     // // 需要访问它的每一个成员进行输出，访问语法：结构体变量.成员名称
//     // cout << stu.name << endl;
//     // cout << stu.age << endl;
//     // cout << stu.gender << endl;
//     //
//     // struct Student stu2 = {"林俊介", 11, "男"};
//     // cout << "2号学生的姓名是：" << stu2.name << endl;
//     // cout << "2号学生的年龄是：" << stu2.age << endl;
//     // cout << "2号学生的性别是：" << stu2.gender << endl;
//
//
//     //  // 练习
//     //  // 录入5名学生信息
//     // struct Student { // 声明一个结构体
//     //     string name;
//     //     int age;
//     //     string addr;
//     // };
//     //
//     // for (int i = 1; i < 6; i++) {
//     //     cout << "正在录入学生" << i << "的信息：" << endl;
//     //     struct Student stu; // 创建一个结构体变量
//     //     cout << "请输入姓名：";
//     //     cin >> stu.name; // 给结构体变量成员赋值
//     //     cout << "请输入年龄：";
//     //     cin >> stu.age;
//     //     cout << "请输入地址：";
//     //     cin >> stu.addr;
//     //     // 访问结构体变量成员
//     //     cout << "学生" << i << "的信息核对：" << "姓名：" << stu.name << "，年龄：" << stu.age << "，地址：" << stu.addr << endl;
//     // }
//
//     return 0;
// }
