// #include "iostream"
//
// using namespace std;
//
// void switch_num(int a, int b) // 这里只是操作值
// // 这里传参的实质是：将实参的值copy一份给形参，让形参去做处理，对于实参本身而言是没有改变的
// // 但是如果传入的是内存地址：那么就是实际的在操作内存地址上存储的内容，会修改实参本身
// {
//     int tmp = a;
//     a = b;
//     b = tmp;
// }
//
//
// // 这是是操作内存，这样才能发生实际变化
// void switch_num_pointer(int *a, int *b) // 声明指针时，* 号只是声明变量a是指针变量。函数参数是地址而非数值
// {
//     int tmp = *a;  // 使用时，* 号是取值的含义
//     *a = *b;
//     *b = tmp;
// }
//
// int main() {
//
//     int x = 1;
//     int y = 2;
//
//     switch_num(x, y);
//     cout << "x=" << x << endl;
//     cout << "y=" << y << endl;
//
//     switch_num_pointer(&x, &y);
//     cout << "x=" << x << endl;
//     cout << "y=" << y << endl;
//
//
//
//     return 0;
// }
