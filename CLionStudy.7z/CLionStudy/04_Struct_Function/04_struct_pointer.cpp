// #include "iostream"
//
// using namespace std;
//
// /*
//  * 首先声明一个结构体
//  * 构建一个结构体对象，这个对象是一个结构体
//  * 然后将结构体对象的地址赋值给指针，通过指针访问结构体对象成员
//  * 访问方式：p -> 成员名称
//  *
//  *
//  */
//
// int main() {
//
//     struct Student
//     {
//         string name;
//         int age;
//         string gender;
//     };
//
//     // 先创建一个标准的结构体对象（静态内存管理）,不需要主动释放内存
//     struct Student stu = {"周杰轮", 11, "男"};
//     // 创建结构体的指针，指向结构体对象的地址
//     struct Student * p = &stu; // stu是一个结构体，不是数组，所以取地址的时候要带上 ”&“ 符号
//     // 通过结构体指针，访问结构体的成员，要使用的符号是：->
//     cout << "结构体中成员的name：" << p->name << endl;
//     cout << "结构体中成员的age：" << p->age << endl;
//     cout << "结构体中成员的gender：" << p->gender << endl;
//
//
//     // 通过new操作符，申请结构体的空间
//     struct Student * p2 = new Student {"林军杰", 21, "男"};
//     cout << "结构体2中成员的name：" << p2->name << endl;
//     cout << "结构体2中成员的age：" << p2->age << endl;
//     cout << "结构体2中成员的gender：" << p2->gender << endl;
//
//     delete p2; // 动态内存管理，主动申请内存，并主动释放内存
//
//
//
//
//     return 0;
// }
