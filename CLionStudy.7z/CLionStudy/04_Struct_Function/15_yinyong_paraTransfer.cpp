// #include "iostream"
//
// using namespace std;
//
// /*
//  * 引用传参：
//  * void func(int &a, int &b);
//  */
// void switch_num1(int a, int b)      // 值传递
// // 这里传参的实质是：将实参的值copy一份给形参，让形参去做处理，对于实参本身而言是没有改变的
// {
//     int tmp;
//     tmp = a;
//     a = b;
//     b = tmp;
// }
//
// void switch_num2(int * a, int * b)  // 地址传递
// // 这里传参的实质是：在内存地址上操作，直接修改实参
// {
//     int tmp;
//     tmp = *a;
//     *a = *b;
//     *b = tmp;
// }
//
// void switch_num3(int &a, int &b)    // 引用传递
// // 这里传参的实质是：因为这里是形参，不能直接使用实参，所以这里给实参变量贴个别名的标签，通过这个别名去直接对实参进行操作，
// // 相当于从屏幕的正面操作，会修改实参
// {
//     int tmp;
//     tmp = a;  // 这里操作还是按照变量名称操作，不过操作的是变量的别名
//     a = b;
//     b = tmp;
// }
//
//
// int main() {
//
//     int x = 1;
//     int y = 2;
//     switch_num3(x, y); // 还是传入实参变量
//     cout << "x=" << x << endl;
//     cout << "y=" << y << endl;
//
//
//
//     return 0;
// }
