// #include "iostream"
//
// using namespace std;
//
// /*
//  * 首先声明一个结构体
//  * 结构体数组指针：定义一个结构体数组对象（数组对象中每一个元素都是一个独立的结构体），
//  * 然后把数组的地址赋值给指针，使用指针操作数组成员
//  * 访问成员方式：p[i].结构体成员
//  */
//
// int main() {
//
//     // struct Student
//     // {
//     //     string name;
//     //     int age = 11;
//     //     string gender = "男";
//     // };
//     // struct Student arr1[3] = {{"周杰轮"}, {"林军杰"}, "王力鸿"};
//     // struct Student * p1 = arr1;     // 数组的对象本质上就是地址（指向数组的第一个元素的位置）
//     // cout << "数组的第一个元素中记录的name是：" << p1[0].name << endl;
//     // cout << "数组的第二个元素中记录的name是：" << p1[1].name << endl;
//     // cout << "数组的第三个元素中记录的name是：" << p1[2].name << endl;
//     //
//     // // 通过new操作符，自行申请结构体数组的空间（可以通过delete回收）
//     // struct Student * p2 =
//     //         new Student[3] {{"周杰轮"}, {"林军杰"}, {"王力鸿"}}; // 注意这种声明方式
//     //
//     // cout << "数组2的第一个元素中记录的name是：" << p2[0].name << endl;
//     // cout << "数组2的第二个元素中记录的name是：" << p2[1].name << endl;
//     // cout << "数组2的第三个元素中记录的name是：" << p2[2].name << endl;
//     //
//     // delete[] p2;
//
//
//     // // 练习
//     // struct Student {
//     //     string name;
//     //     int age;
//     //     string addr;
//     // };
//     //
//     // // struct Student arry1 = new Student[5];  // 左值是结构体对象，右值是地址，不可以这样写
//     // // struct Student *p1 = arry1;
//     // struct Student *p1 = new Student[5];  // 主动申请的内存空间，要用指针去接收内存地址
//     //
//     // for (int i = 0; i < 5; i++) {
//     //     cout << "正在录入学生" << i + 1 << "的信息：" << endl;
//     //     cout << "请输入姓名：";
//     //     cin >> p1[i].name; // 给结构体变量成员赋值
//     //     cout << "请输入年龄：";
//     //     cin >> p1[i].age;
//     //     cout << "请输入地址：";
//     //     cin >> p1[i].addr;
//     //    }
//     //
//     // for (int i = 0; i < 5; i++) {
//     //     cout << p1[i].name << ", " << p1[i].age << ", " << p1[i].addr << endl;
//     // }
//     //
//     //
//     // // 释放内存
//     // delete[] p1;
//
//     return 0;
// }
