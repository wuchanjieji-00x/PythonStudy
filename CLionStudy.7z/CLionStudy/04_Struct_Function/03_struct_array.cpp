// #include "iostream"
//
// using namespace std;
//
// /*
//  * 首先声明一个结构体
//  * 结构体数组：构建一个结构体数组对象（数组对象中每一个元素都是一个独立的结构体），
//  * 构建方式：struct 结构体类名称 数组名称[数组元素数量]; // 只声明
//  * 或：struct 结构体类名称 数组名称[数组元素数量]= {{结构体1}，{结构体2}，...} // 声明+赋值
//  *
//  * 例如 struct Student arr[3];
//  * 访问方式：
//  * arr[1].name
//  * arr[2].name
//  * arr[3].name
//  */
//
// int main() {
//
//     // struct Student
//     // {
//     //     string name;
//     //     int age;
//     //     string gender;
//     // };
//
//     // struct Student arr[3];         // 结构体数组对象的声明
//     // // 这是一个数组，数组中的每一个元素都是一个结构体对象
//     // // 可以理解为把结构体作为一个元素，逐次放进数组里面
//     // arr[0] = {"周杰轮", 11, "男"};
//     // arr[1] = {"林军杰", 11, "男"};
//     // arr[2] = {"蔡依临", 11, "女"};
//     //
//     // for (int i=0; i<3; i++)
//     // {
//     //     cout << "当前下标：" << i << "姓名是：" << arr[i].name << endl;
//     //     cout << "当前下标：" << i << "年龄是：" << arr[i].age << endl;
//     //     cout << "当前下标：" << i << "性别是：" << arr[i].gender << endl;
//     //     cout << endl;
//     // }
//
//
//
//     // // 练习
//     // // 包装5个学生的信息到一个结构体数组中
//     // struct Student { // 声明一个结构体
//     //     string name;
//     //     int age;
//     //     string addr;
//     // };
//     // struct Student arry[5];  //创建一个结构体数组
//     //
//     // for (int i = 0; i < 5; i++) {
//     //     cout << "正在录入学生" << i + 1 << "的信息：" << endl;
//     //     cout << "请输入姓名：";
//     //     cin >> arry[i].name; // 给结构体变量成员赋值
//     //     cout << "请输入年龄：";
//     //     cin >> arry[i].age;
//     //     cout << "请输入地址：";
//     //     cin >> arry[i].addr;
//     //    }
//     // // 逐个访问结构体数组元素成员
//     // cout << arry[0].name << ", " << arry[0].age << ", " << arry[0].addr << endl;
//     // cout << arry[1].name << ", " << arry[1].age << ", " << arry[1].addr << endl;
//     // cout << arry[2].name << ", " << arry[2].age << ", " << arry[2].addr << endl;
//     // cout << arry[3].name << ", " << arry[3].age << ", " << arry[3].addr << endl;
//     // cout << arry[4].name << ", " << arry[4].age << ", " << arry[4].addr << endl;
//
//
//
//
//     return 0;
// }
