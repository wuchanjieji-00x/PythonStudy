// #include "iostream"
//
// using namespace std;
//
// // 返回指针的函数，就在函数返回值声明和函数名之间添加*号即可
// int * add(int a, int b)
// {
//     int * sum = new int;
//     *sum = a + b;
//
//     return sum;
// }
//
// int main() {
//
//     int * result1 = add(1, 2);
//     cout << *result1 << endl;
//
//     delete result1;  // 不主动删除内存的话，会报内存泄露
//     // 注意，这里删除的是result1,而不是sum
//     // 那是因为，我们是用result1去调用的，不调用的话，不会产生内存申请的动作的
//
//
//
//
//     return 0;
// }