// #include "iostream"
//
// using namespace std;
//
// /*
//  * static是一个关键字，可以修饰变量和函数
//  * - 修饰变量，可以让被修饰的变量的生命周期一直持续到程序结束，不受函数结束的影响。
//  */
//
// int * add(int a, int b)
// {
//     static int sum;
//     sum = a + b;
//     return &sum;
// }
//
// int main() {
//
//     int * result = add(1, 2);
//     cout << *result << endl;
//
//     return 0;
// }


// // 练习
// #include "iostream"
//
// using namespace std;
//
// // 从头到尾不操作变量
// int * get_max1(int arry[], int length) {
//     int * max_value = new int; // 动态内存管理
//     // 申请一个int大小的内存，将地址预留出来用来存储最大值
//     *max_value = 0; // 将申请的内存初始化一个值
//     for (int i = 0; i < length; i++) {
//         if (arry [i] > *max_value) {
//             *max_value = arry[i]; // 遍历数组找到最大值，写入申请的内存中
//         }
//     }
//     return max_value; // 返回最大值所在的内存地址
// }
//
// // static关键字
// int * get_max2(int arry[], int length) {
//     static int max_value2 = 0; // 将max_value_2变量设置为静态变量，使其和main函数具有相同声明周期
//     for (int i = 0; i < length; i++) {
//         if (arry [i] > max_value2) {
//             max_value2 = arry[i]; // 遍历数组找到最大值，写入申请的内存中
//         }
//     }
//     return &max_value2;
// }
//
// int main() {
//
//     // 方式1：动态内存管理
//     int arry1[5] = {2, 55, 33, 100, 88};
//     int * result1 = get_max1(arry1, 5);
//     cout << *result1 << endl;
//     delete result1;
//
//
//     // 方式2：static关键字
//     int arry2[5] = {2, 55, 33, 100, 88};
//     int * result2 = get_max2(arry1, 5); // 传入数组地址和数组长度。得到其中元素最大值的地址
//     cout << *result2 << endl;
//
//
//     return 0;
// }
