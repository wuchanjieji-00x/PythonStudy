// #include "iostream"
//
// using namespace std;
//
// /*
//  * 函数的嵌套就是在一个函数内调用其他的函数
//  */
//
//
// /*
//  * 需求：喜欢小美，正在追求中，每天的追求方案有3种：
//  * 1. 送早餐、送花、说喜欢
//  * 2. 送花、说喜欢、邀请一起看电影
//  * 3. 邀请一起看电影、送花、说喜欢
//  * 用函数的思想，模拟这些动作。
//  */
//
// // 定义子函数，用于实现特定单一功能
// void send_food()
// {
//     cout << "小美，我给你买了早餐！" << endl;
// }
//
// void send_floor()
// {
//     cout << "小美，我给你买了玫瑰花，你真好看。" << endl;
// }
//
// void say_love()
// {
//     cout << "小美，我很喜欢你！" << endl;
// }
//
// void watch_movie()
// {
//     cout << "小美，我们一起看电影去吧。" << endl;
// }
//
// // 定义上层函数，用与顶层设计，调用不同函数实现组合的功能
// void i_like_you(int num)
// {
//     switch (num)
//     {
//         case 1:
//             send_food();
//             send_floor();
//             say_love();
//             break;
//         case 2:
//             send_floor();
//             say_love();
//             watch_movie();
//             break;
//         case 3:
//             watch_movie();
//             send_floor();
//             say_love();
//             break;
//         default:
//             cout << "今天不追求小美了，去打球去。！" << endl;
//     }
// }
//
//
// int get_max(int a, int b) {
//
//     if (a < b) {
//         return b;
//     }
//
//     return a;
// }
//
// int get_min(int a, int b) {
//
//     if (a > b) {
//        return b;
//     }
//
//     return a;
// }
//
// struct MaxAndMin {
//     int max;
//     int min;
// }; // 声明一个结构体，用于顶层设计
// struct MaxAndMin get_max_min(int a, int b) { // 定义一个结构体用来接收函数的结构体返回值
//     // 注意这种函数定义方式
//     int max = get_max(a, b);
//     int min = get_min(a, b);
//     struct MaxAndMin v = {max , min}; // 定义一个结构体对象来实际接收函数的返回值，作为其成员，最后返回结构体对象
//
//     return v;
//
// }
//
//
// int main() {
//
//     // cout << "今天天气不错，执行方案3追求小美" << endl;
//     // i_like_you(3);
//     //
//     // cout << "第二天，天气也不错，执行方案2" << endl;
//     // i_like_you(2);
//
//
//     // 练习
//     // 编写3个函数，找max和min
//     struct MaxAndMin v = get_max_min(1,2);  // 函数返回值是一个结构体，需要定义一个结构体对象接收
//     cout << v.min << "; " << v.max << endl; // 结构体是一种数据类型，不能直接打印，只能访问成员，输出成员
//
//
//
//
//     return 0;
// }
