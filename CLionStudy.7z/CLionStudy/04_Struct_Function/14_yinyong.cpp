// #include "iostream"
//
// using namespace std;
//
// /*
//  * 数据类型& 引用名 = 被引用变量;
//  *
//  * 对引用的操作等同于操作被引用变量。
//  *
//  * 变量相当于给这个内存地址存的内容打一个标签，那么引用就是这个标签的别名
//  * 可以理解为变量是学名，引用是别名
//  * 因此，引用的对象是不可变的。一种药材的学名和别名都是唯一的，别名之所以叫别名，就是对于这个学名而言的
//  */
//
// int main() {
//
//     int a = 10;
//     int& b = a;
//     cout << "a = " << a << endl;
//     cout << "b = " << b << endl;
//
//     a = 20;
//     cout << "a = " << a << endl;
//     cout << "b = " << b << endl;
//
//     b = 20;
//     cout << "a = " << a << endl;
//     cout << "b = " << b << endl;
//
//     // 不同数据类型都支持引用，包括结构体
//     int num1 = 10;
//     int& num2 = num1;
//
//     double d1 = 11.11;
//     double& d2 = d1;
//     cout << "d1=" << d1 << endl;
//     cout << "d2=" << d2 << endl;
//     d2 = 22.22;
//     cout << "d1=" << d1 << endl;
//     cout << "d2=" << d2 << endl;
//
//
//
//
//     return 0;
// }