// #include "iostream"
//
// using namespace std;
//
// /*
//  *在声明结构体的时候，可以在结构体内部给结构体成员赋予默认值
//  * 后面在构建结构体变量的时候，可以不用给已有默认值的结构体成员赋值了，可以直接使用默认值
//  * 如果不想使用结构体的默认值，可以在构建结构体变量时，给结构体成员重新赋值，可以覆盖默认值
//  */
//
// int main() {
//
//     // struct Student
//     // {
//     //     string name;        // 成员1，姓名
//     //     string major_code = "003032";   // 成员2专业代码，拥有默认值003032
//     //     int dormitory_num = 1;          // 成员3宿舍楼号，默认是1号楼
//     // };
//     //
//     // struct Student s1 = {"周杰轮"};
//     // struct Student s2 = {"林军杰", "003001", 3};
//     //
//     // cout << "学生1的姓名：" << s1.name << endl;
//     // cout << "学生1的专业代码：" << s1.major_code << endl;
//     // cout << "学生1的宿舍楼号：" << s1.dormitory_num << endl;
//     // cout << endl;
//     // cout << "学生2的姓名：" << s2.name << endl;
//     // cout << "学生2的专业代码：" << s2.major_code << endl;
//     // cout << "学生2的宿舍楼号：" << s2.dormitory_num << endl;
//
//
//     // // 练习
//     // // 录入5名学生信息，年龄默认11，不需要输入年龄
//     //    struct Student { // 声明一个结构体
//     //        string name;
//     //        int age = 11;
//     //        string addr;
//     //    };
//     //
//     //    for (int i = 1; i < 6; i++) {
//     //        cout << "正在录入学生" << i << "的信息：" << endl;
//     //        struct Student stu; // 创建一个结构体变量
//     //        cout << "请输入姓名：";
//     //        cin >> stu.name; // 给结构体变量成员赋值
//     //        // cout << "请输入年龄：";
//     //        // cin >> stu.age;
//     //        cout << "请输入地址：";
//     //        cin >> stu.addr;
//     //        // 访问结构体变量成员
//     //        cout << "学生" << i << "的信息核对：" << "姓名：" << stu.name << "，年龄：" << stu.age << "，地址：" << stu.addr << endl;
//     //    }
//
//
//
//     return 0;
// }
