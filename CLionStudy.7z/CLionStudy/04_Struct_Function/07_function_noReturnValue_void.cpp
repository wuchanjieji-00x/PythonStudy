// #include "iostream"
//
// using namespace std;
//
// /*
//  * 无返回值，不写return关键字
//  * 声明函数时，函数返回值类型为void
//  *
//  * 只实现某种功能，不用给我反馈信息
//  */
//
// void say_hello(string name)
// {
//     cout << name << ", 你好，我是黑马程序员！" << endl;
// }
//
// void say_love(int times) {
//     for (int i = 0; i < times; i++) {
//         cout << "小美，我喜欢你" << endl;
//     }
// }
//
// int main() {
//
//
//     say_hello("周杰轮");
//     say_hello("林军杰");
//
//     // 练习
//     say_love(3);
//     cout << "--------" << endl;
//     say_love(2);
//
//
//
//     return 0;
// }
