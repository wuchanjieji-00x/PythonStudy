// #include "iostream"
//
// using namespace std;
//
// /*
//  * void func(int arr[]);
//  * void func(int arr[10]);
//  * void func(int * arr);
//  * 三者完全一致，无论哪种方式，arr均被看做指针（地址传递）
//  *
//  * - 函数体内，sizeof无法统计数组大小，得到的总是8字节（指针本身大小）
//  * - 函数接受数组传入，一般建议附带数组长度（否则非常难以统计）
//  */
//
// //void func1(int arr[10])
// //{
// //    cout << "在func1函数内统计的数组总大小：" << sizeof(arr) << endl;  // 结果永远是8（64位系统）
// //}
//
// void func(int arr[], int length)
// // 注意两点：1.数组作为参数时，一定要传入数组的长度（元素个数）； 2.数组作为参数时，建议用dataType + 数组名 + []
// {
//     for (int i = 0; i < length; i++)
//     {
//         cout << arr[i] << endl;
//     }
// }
//
// int main() {
//
//     int arr[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
//     cout << "在main函数内统计的数组总大小：" << sizeof(arr) << endl;
//
//     func(arr, 10); // 传实参时，建议数组用数组名表示，加上数组的长度
//     return 0;
//
//
//
//     return 0;
// }