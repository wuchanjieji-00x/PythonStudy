// #include "iostream"
//
// using namespace std;
//
// // C++ 实例 - 创建各类三角形图案
// // 创建各类三角形图案
//
//
// int main() {
//
//     // // triangle 1 : 九九乘法表
//     // int rows;
//     //
//     // cout << "please input the number of rows: ";
//     // cin >> rows;
//     //
//     // for (int i = 1; i <= rows; i++) {
//     //     for (int j =1; j <= i; j++) {
//     //         cout << "*\t";
//     //     }
//     //     cout << endl;
//     // }
//
//
//     // // triangle 1.1
//     // int rows;
//     //
//     // cout << "please input the number of rows: ";
//     // cin >> rows;
//     //
//     // for (int i = 1; i <= rows; i++) {
//     //     for (int j =1; j <= i; j++) {
//     //         cout << j << "\t";
//     //     }
//     //     cout << endl;
//     // }
//
//
//     // // triangle 1.2
//     //
//     // 补充知识点：
//     // char letter = 'B', alphabet = 'A';
//     // cout << letter - alphabet;  / 1
//
//     // int cha = 'A';
//     // cout << cha << endl; // 65
//
//     // char cha = 'A';
//     // cout << cha << endl; // A
//
//
//     // char letter = 'B', alphabet = 'A';
//     //
//     // cout << "please input the last uppercase letter: ";
//     // cin >> letter;
//     //
//     // for (int i = 1; i <= (letter - 'A' + 1); i++) {
//     //     for (int j = 1; j <= i; j++) {
//     //         cout << alphabet << "\t";
//
//     //     }
//     //     alphabet++;
//     //     cout << endl;
//     // }
//
//
//     // // triangle 2
//     // int rows;
//     //
//     // cout << "please input the number of rows: ";
//     // cin >> rows;
//     //
//     // for (int i = rows; i >= 1; i--) {
//     //     for (int j = 1; j <= i; j++) {
//     //         cout << "*\t";
//     //     }
//     //     cout << endl;
//     // }
//
//
//     // // triangle 2.1
//     // int rows;
//     //
//     // cout << "please input the number of rows: ";
//     // cin >> rows;
//     //
//     // for (int i = rows; i >= 1; i--) {
//     //     for (int j = 1; j <= i; j++) {
//     //         cout << j << "\t";
//     //     }
//     //     cout << endl;
//     // }
//
//
//     // triangle 3  // 看不懂看不懂
//     // int rows, space;
//     //
//     // cout << "please input the number of rows: ";
//     // cin >> rows;
//     //
//     // for(int i = 1, k = 0; i <= rows; ++i, k = 0)
//     // {
//     //     for(space = 1; space <= rows-i; ++space)
//     //     {
//     //         cout <<"  ";
//     //     }
//     //
//     //     while(k != 2*i-1)
//     //     {
//     //         cout << "* ";
//     //         ++k;
//     //     }
//     //     cout << endl;
//     // }
//
//     // // AI实现
//     // int rows, space;
//     //
//     // cout << "please input the number of rows: ";
//     // cin >> rows;
//     //
//     //
//     // for (int i = 1; i <= 2 * rows - 1; ++i) {
//     //     // 内层循环控制每行的空格
//     //     for (int j = 1; j <= rows - std::abs(rows - i); ++j) {
//     //         cout << "  "; // 输出空格
//     //     }
//     //
//     //     // 内层循环控制每行的星号
//     //     for (int k = 1; k <= 2 * std::abs(rows - i) - 1; ++k) {
//     //         cout << "* "; // 输出星号
//     //     }
//     //
//     //     cout << endl; // 换行
//     // }
//
//
//     // // triangle 3.1  // 看不懂看不懂
//     // int rows, count = 0, count1 = 0, k = 0;
//     //
//     // cout << "please input the number of rows: ";
//     // cin >> rows;
//     //
//     // for(int i = 1; i <= rows; ++i)
//     // {
//     //     for(int space = 1; space <= rows-i; ++space)
//     //     {
//     //         cout << "  ";
//     //         ++count;
//     //     }
//     //
//     //     while(k != 2*i-1)
//     //     {
//     //         if (count <= rows-1)
//     //         {
//     //             cout << i+k << " ";
//     //             ++count;
//     //         }
//     //         else
//     //         {
//     //             ++count1;
//     //             cout << i+k-2*count1 << " ";
//     //         }
//     //         ++k;
//     //     }
//     //     count1 = count = k = 0;
//     //
//     //     cout << endl;
//     // }
//
//
//
//     // // triangle 4
//     // int rows;
//     //
//     // cout << "输入行数: ";
//     // cin >> rows;
//     //
//     // for(int i = rows; i >= 1; --i)
//     // {
//     //     for(int space = 0; space < rows-i; ++space)
//     //         cout << "  ";
//     //
//     //     for(int j = i; j <= 2*i-1; ++j)
//     //         cout << "* ";
//     //
//     //     for(int j = 0; j < i-1; ++j)
//     //         cout << "* ";
//     //
//     //     cout << endl;
//     // }
//
//
//
//     // // triangle 4.1： 杨辉三角
//     // int rows, coef = 1;
//     //
//     // cout << "Enter number of rows: ";
//     // cin >> rows;
//     //
//     // for(int i = 0; i < rows; i++)
//     // {
//     //     for(int space = 1; space <= rows-i; space++)
//     //         cout <<"  ";
//     //
//     //     for(int j = 0; j <= i; j++)
//     //     {
//     //         if (j == 0 || i == 0)
//     //             coef = 1;
//     //         else
//     //             coef = coef*(i-j+1)/j;
//     //
//     //         cout << coef << "   ";
//     //     }
//     //     cout << endl;
//     // }
//
//
//     // // triangle 5
//     // int rows, number = 1;
//     //
//     // cout << "输入行数: ";
//     // cin >> rows;
//     //
//     // for(int i = 1; i <= rows; i++)
//     // {
//     //     for(int j = 1; j <= i; ++j)
//     //     {
//     //         cout << number << " ";
//     //         ++number;
//     //     }
//     //
//     //     cout << endl;
//     // }
//
//     return 0;
// }
