// #include "iostream"
// #include "string"
//
// using namespace std;
//
// /*
//  * 1.创建不同数据类型变量
//  * 2.使用 C++ sizeof 运算符来计算变量占用的空间大小（字节为单位）
//  * sizeof（）语法：sizeof(dataType);
//  */
//
//
// int main() {
//
//     // 创建变量
//     int myNum = 5;               // 整型
//     long long factorial = 1;
//     unsigned long long factorial1 = 1;
//     float myFloatNum = 5.99;     // 单精度浮点型
//     double myDoubleNum = 9.98;   // 双精度浮点型
//     char myLetter = 'D';        // 字符型
//     bool myBoolean = true;       // 布尔型
//     string myString = "Runoob";  // 字符串型
//
//
//
//
//     // 输出变量
//     cout << "int: " << myNum << "\n";
//     cout << "float: " << myFloatNum << "\n";
//     cout << "double: " << myDoubleNum << "\n";
//     cout << "char: " << myLetter << "\n";
//     cout << "bool: " << myBoolean << "\n";
//     cout << "string: " << myString << "\n";
//
//     // 输出变量内存大小
//     cout << "int变量占用内存（byte）：" << sizeof(myNum) << "字节" << "\n";           // 4
//     cout << "long long 变量占用内存（byte）：" << sizeof(factorial) << "字节" << "\n";  // 8
//     cout << "unsigned long long 变量占用内存（byte）：" << sizeof(factorial1) << "字节" << "\n";  // 8
//     cout << "float变量占用内存（byte）：" << sizeof(myFloatNum) << "字节" << "\n";    // 4
//     cout << "double变量占用内存（byte）：" << sizeof(myDoubleNum) << "字节" << "\n";  // 8
//     cout << "char变量占用内存（byte）：" << sizeof(myLetter) << "字节" << "\n";       // 1
//     cout << "bool变量占用内存（byte）：" << sizeof(myBoolean) << "字节" << "\n";      // 1
//     cout << "string变量占用内存（byte）：" << sizeof(myString) << "字节" << "\n";     // 32
//
//     return 0;
// }