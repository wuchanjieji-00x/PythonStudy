// #include "iostream"
//
// using namespace std;
//
// // C++ 实例 - 求两数的最大公约数
// // 用户输入两个数，求这两个数的最大公约数。(HCF / GCD:greatest common divisor)
//
//
// // 方式3定义的函数
// // 定义一个函数来计算两个整数的最大公约数
// int gcd(int a, int b) {
//     // 首先让a > b,较大的值在前面
//     while (b != 0) {
//         int temp = b;
//         b = a % b;
//         a = temp;
//     }
//     return a;
// }
//
// int main() {
//
//     // // 方式1：更相减损法
//     // int a, b;
//     //
//     // cout << "please input two number:";
//     // cin >> a >> b;
//     //
//     // while (a != b) {
//     //     if (a > b){
//     //         a -= b;
//     //     }else{
//     //         b -= a;
//     //     }
//     // }
//     // cout << "最大公约数是（HCF）：" << a << endl;
//
//
//
//     // // 方式2：从1到较小数值升序遍历，找到最大的公约数
//     // int a, b, hcf = 1;
//     //
//     // cout << "please input two number:";
//     // cin >> a >> b;
//     //
//     // // 如果 b 大于 a 交换两个变量
//     // if (b > a) {
//     //     int temp = b;
//     //     b = a;
//     //     a = temp;
//     // }
//     // for (int i =1; i <= b; i++) {
//     //     if (a % i == 0 && b % i == 0){
//     //         hcf = i;
//     //     }
//     // }
//     // cout << "最大公约数是（HCF）：" << hcf << endl;
//
//
//
//     // // 方式3：辗转相除法，欧几里得算法
//     // // 思想：
//     // // 大数对小数取余得1次余数，之后用小数对一次余数取余得2次余数，用一次余数对二次余数取余的3次余数
//     // // 循环往复，得n次余数为0，则n次取余是的被取余的数就是最大公约数
//     //
//     // int a, b;
//     //
//     // cout << "please input two number:";
//     // cin >> a >> b;
//     // cout << gcd(a, b) << std::endl;
//
//
//     return 0;
// }
