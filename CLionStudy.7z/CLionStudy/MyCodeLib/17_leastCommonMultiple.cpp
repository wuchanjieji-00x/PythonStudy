// #include "iostream"
//
// using namespace std;
//
// // C++ 实例 - 求两数最小公倍数
// // 用户输入两个数，其这两个数的最小公倍数。(LCM: least common multiple)
//
//
// int main() {
//
//     // // 方式1：笨蛋遍历法
//     // int n1, n2, max;
//     //
//     // cout << "please input two number:";
//     // cin >> n1 >> n2;
//     //
//     // max = (n1 > n2)? n1 : n2;
//     // do {
//     //     if (max % n1 == 0 && max % n2 == 0) {
//     //         cout << "最小公倍数（LCM）：" << max;
//     //         break;
//     //     }else {
//     //         max++;
//     //     }
//     // } while (true);
//
//
//     // // 方式2：利用最大公约数公式 LCM = (a * b) / HCF(a, b)
//     // int n1, n2, max;
//     // int a, b;
//     // int lcm;
//     //
//     // cout << "please input two number:";
//     // cin >> n1 >> n2;
//     //
//     // a = n1;
//     // b = n2;
//     //
//     // // 求HCF：最大公约数
//     // while (b != 0) {
//     //     int temp = b;
//     //     b = a % b;
//     //     a = temp;
//     // }
//     // max = a;
//     //
//     // lcm = (n1 * n2) / max;
//
//     return 0;
// }