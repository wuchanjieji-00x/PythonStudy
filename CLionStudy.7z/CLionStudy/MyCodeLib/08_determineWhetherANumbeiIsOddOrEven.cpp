// #include "iostream"
//
// using namespace std;
//
// // C++ 实例 - 判断一个数是奇数还是偶数
//
// // odd number: 奇数   even number: 偶数
// // 以下我们使用 % 来判断一个数是奇数还是偶数，原理是，将这个数除于 2 如果余数为 0 为偶数，否则为奇数。
//
//
//
// int main() {
//
//     // // 方式1: if...else判断语句
//     // int number;
//     //
//     // cout << "pleease input a integer: ";
//     // cin >> number;
//     //
//     // if (number % 2 == 0) {
//     //     cout << number << " is a even number.";
//     // }else {
//     //     cout << number << " is a odd number.";
//     // }
//
//
//
//     // 方式2：三运运算符，判断语句
//     int number;
//
//     cout << "pleease input a integer: ";
//     cin >> number;
//
//     (number % 2 == 0)? cout << number << " is a even number." : cout << number << " is a odd number.";

//
//     return 0;
// }
