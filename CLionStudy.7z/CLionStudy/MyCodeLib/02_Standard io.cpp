// #include "iostream"
//
// using namespace std;
//
//
//
// int main() {
//
//
//     int number;
//
//     cout << "请输入一个整数：";
//     cin >> number;
//
//     cout << "输入的数字为：" << number;
//
//
//
//
//
//     return 0;
// }
