// #include "iostream"
//
// using namespace std;
//
// // C++ 实例 - 计算自然数之和
//
// // 计算 1+2+3+....+n 的和。
//
// int main() {
//
//     int n, sum = 0;
//
//     cout << "please input a integer: ";
//     cin >> n;
//
//     for (int i = 1; i <= n; i++) {
//         sum += i;
//     }
//     cout << "sum = " << sum << endl;
//
//     return 0;
// }
