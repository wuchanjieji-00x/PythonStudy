// #include "iostream"
//
// using namespace std;
//
// // 使用 C++ 获取用户的输入两个数字，并将两个数字相除，然后将商和余数输出到屏幕：
//
// int main() {
//
//     int divident, divisor, quotient, remainder;
//
//     cout << "输入被除数：";
//     cin >> divident;
//     cout << "输入除数：";
//     cin >> divisor;
//
//     quotient = divident / divisor;
//     remainder = divident % divisor;
//
//     cout << "商 = " << quotient << endl;
//     cout << "余数 = " << remainder;
//
//     return 0;
// }
