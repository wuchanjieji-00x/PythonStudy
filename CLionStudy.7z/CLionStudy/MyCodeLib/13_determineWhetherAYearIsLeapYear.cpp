// #include "iostream"
//
// using namespace std;
//
// // C++ 实例 - 判断闰年
// // 用户输入年份，判断该年份是否为闰年
//
// // 普通闰年：公历年份是4的倍数，且不是100的倍数的，为闰年（如2004年、2020年等就是闰年）
// // 世纪闰年：公历年份是整百数的，必须是400的倍数才是闰年（如1900年不是闰年，2000年是闰年）
//
// int main() {
//
//     int year;
//
//     cout << "please input a year number: ";
//     cin >> year;
//
//     if (year % 4 == 0) {
//         if (year % 100 == 0) {  // 这一步是不是可以不要
//             if (year % 400 == 0) {
//                 cout << year << " is a leap year";
//             }else {
//                 cout << year << " is not a leap year";
//             }
//         }else {
//             cout << year << " is a leap year";
//         }
//     }else {
//         cout << year << " is not a leap year";
//     }
//
//     return 0;
// }
