// #include "iostream"
//
// using namespace std;
//
// // 以下我们使用两种方法来交换两个变量：使用临时变量与不使用临时变量。
//
// int main() {
//
//     // // 方式1：使用临时变量
//     // int a = 5, b = 10, temp;
//     //
//     // cout << "before change: " << endl;
//     // cout << "a = " << a << ", " << "b = " << b << endl;
//     //
//     // temp = a;
//     // a = b;
//     // b = temp;
//     //
//     // cout << "\nafter change: " << endl;
//     // cout << "a = " << a << ", " << "b = " << b << endl;
//
//
//     // 方式2：不使用临时变量
//     int a = 5, b = 10, temp;
//
//     cout << "before change: " << endl;
//     cout << "a = " << a << ", " << "b = " << b << endl;
//
//     a = a + b;
//     b = a - b;
//     a = a - b;
//
//
//     cout << "\nafter change: " << endl;
//     cout << "a = " << a << ", " << "b = " << b << endl;
//
//     return 0;
// }
