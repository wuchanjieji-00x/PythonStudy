// #include "iostream"
//
// using namespace std;
//
// // C++ 实例 - 判断元音/辅音
// // 元音：vowel   辅音：consonants
//
// // 英语有 26 个字母，元音只包括 a、e、i、o、u 这五个字母，其余的都为辅音。y是半元音、半辅音字母，但在英语中都把他当作辅音。
//
//
//
// bool isVowel(char letter) {
//     letter = tolower(letter);
//
//     if (letter == 'a' || letter == 'e' || letter == 'i' || letter == 'o' || letter == 'u')
//     {
//         return true;
//     }
//     else {
//         return false;
//     }
// }
//
// int main() {
//     // // 方式1：
//     // char character;
//     // bool ischar;
//     // int isLowercaseVowel, isUppercaseVowel;
//     //
//     // cout << "please input a letter: ";
//     // cin >> character;
//     //
//     // ischar = ((character >= 'a' && character <= 'z') || (character >= 'A' && character <= 'Z'));
//     // if (ischar) {
//     //
//     //     // 小写字母元音
//     //     isLowercaseVowel = ( character == 'a'|| character == 'e'|| character == 'i'|| character == 'o'|| character == 'u');
//     //     // 大写字母元音
//     //     isUppercaseVowel = ( character == 'A'|| character == 'E'|| character == 'I'|| character == 'O'|| character == 'U');
//     //     // if判断语句
//     //     if (isLowercaseVowel || isUppercaseVowel) {
//     //         cout << character << " is a vowel";     // 元音
//     //     } else {
//     //         cout << character << " is a consonant"; // 辅音
//     //     }
//     // }else {
//     //     cout << "The input is not a letter.";
//     // }
//
//
//     // 方式2：using function
//     char letter;
//     bool ischar;
//     cout << "please input a letter: ";
//     cin >> letter;
//
//     ischar = ((letter >= 'a' && letter <= 'z') || (letter >= 'A' && letter <= 'Z'));
//     if (ischar) {
//         if (isVowel(letter)) {
//             cout << letter << " is a vowel";     // 元音
//         }else {
//             cout << letter << " is a consonant"; // 辅音
//         }
//     }else {
//         cout << "The input is not a letter.";
//     }
//
//
//
//     return 0;
// }