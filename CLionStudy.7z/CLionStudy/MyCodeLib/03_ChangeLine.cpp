// #include "iostream"
//
// using namespace std;
//
//
//
// int main() {
//
//
//     // 换行符：\n
//     cout << "Runoob \n";
//     cout << "Google \n";
//     cout << "TaoBao \n";
//
//
//     // 行终止符：endl
//     cout << "Runoob" << endl;;
//     cout << "Google" << endl;;
//     cout << "TaoBao" << endl;
//
//
//
//
//
//     return 0;
// }
