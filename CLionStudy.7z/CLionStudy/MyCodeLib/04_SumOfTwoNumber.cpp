//
// #include "iostream"
//
// using namespace std;
//
// // 使用 C++ 获取用户的输入两个数字，并将两个数字相加，然后输出到屏幕：
//
// int main() {
//
//     int firstNumber, secondNumber, sumOfTwoNumbers;
//
//     // // 方式1：
//     // cout << "请输入第一个整数：" << endl;
//     // cin >> firstNumber;
//     // cout << "请输入第二个整数：" << endl;
//     // cin >> secondNumber;
//
//     // 方式2：
//     cout << "请输入两个整数：" << endl;
//     cin >> firstNumber >> secondNumber;
//
//
//     sumOfTwoNumbers = firstNumber + secondNumber;
//
//     cout << firstNumber << "+" << secondNumber << " = " << sumOfTwoNumbers;
//
//
//     return 0;
// }
//
