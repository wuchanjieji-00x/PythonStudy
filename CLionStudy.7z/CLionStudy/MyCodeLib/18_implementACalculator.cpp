// C++ 实例 - 实现一个简单的计算器
// 使用 C++ 创建一个简单的计算器，可以实现 +, -, *, / 。


// // 方式1: 拿到用户输入的数字,和操作运算符,对运算符做switch判断
//
// #include "iostream"
//
// using namespace std;
//
// int main() {
//     float num1, num2;
//     char op;
//
//     cout << "Enter two numbers: ";
//     cin >> num1 >> num2;
//     cout << "Enter an operator (+, -, *, /): ";
//     cin >> op;
//
//     switch (op) {
//         case '+':
//             cout << num1 << " + " << num2 << " = " << num1 + num2;
//             break;
//         case '-':
//             cout << num1 << " - " << num2 << " = " << num1 - num2;
//             break;
//         case '*':
//             cout << num1 << " * " << num2 << " = " << num1 * num2;
//             break;
//         case '/':
//             if (num2 != 0)
//                 cout << num1 << " / " << num2 << " = " << num1 / num2;
//             else
//                 cout << "Error! Division by zero.";
//             break;
//         default:
//             cout << "Error! Invalid operator.";
//             break;
//     }
//
//     return 0;
// }



// // 方式1: main函数外面自定义函数,main函数里面switch语句直接调用函数
// #include "iostream"
// using namespace std;
//
// float add(float num1, float num2) {
//     return num1 + num2;
// }
//
// float subtract(float num1, float num2) {
//     return num1 - num2;
// }
//
// float multiply(float num1, float num2) {
//     return num1 * num2;
// }
//
// float divide(float num1, float num2) {
//     if (num2 != 0) {
//         return num1 / num2;
//     }else {
//         cout << "Error! Division by zero.";
//         return 0;
//     }
// }
//
// int main() {
//     float num1, num2, result;
//     char op;
//
//     cout << "Enter two numbers: ";
//     cin >> num1 >> num2;
//     cout << "Enter an operator (+, -, *, /): ";
//     cin >> op;
//
//     switch (op) {
//         case '+':
//             result = add(num1, num2);
//             break;
//         case '-':
//             result = subtract(num1, num2);
//             break;
//         case '*':
//             result = multiply(num1, num2);
//             break;
//         case '/':
//             result = divide(num1, num2);
//         default:
//             cout << "Error! Invalid operator.";
//             break;
//
//     }
//     cout << num1 << " " << op << " " << num2 << " = " << result;
//
//     return 0;
// }



