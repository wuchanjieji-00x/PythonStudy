// #include "iostream"
//
// using namespace std;
//
//
// // C++ 实例 - 判断三个数中的最大数
//
// // 通过屏幕我们输入三个数字，并找出最大的数。
//
//
// int main() {
//
//     // // 方式1：if
//     // float n1, n2, n3;
//     //
//     // cout << "please input three float: ";
//     // cin >> n1 >> n2 >> n3;
//     //
//     // if (n1 >= n2 && n1 >= n3) {
//     //     cout << "the maximum is " << n1;
//     // }
//     // if (n2 >= n1 && n2 >= n3) {
//     //     cout << "the maximum is " << n2;
//     // }
//     // if (n3 >= n1 && n3 >= n2) {
//     //     cout << "the maximum is " << n3;
//     // }
//
//
//
//     // // 方式2：if...   (else if)  ...else...
//     // float n1, n2, n3;
//     //
//     // cout << "please input three float: ";
//     // cin >> n1 >> n2 >> n3;
//     //
//     // if (n1 >= n2 && n1 >= n3) {
//     //     cout << "the maximum is " << n1;
//     // }else if (n2 >= n1 && n2 >= n3) {
//     //     cout << "the maximum is " << n2;
//     // }else {
//     //     cout << "the maximum is " << n3;
//     // }
//
//
//
//     // 方式3: 使用内嵌的if...else...
//     float n1, n2, n3;
//
//     cout << "please input three float: ";
//     cin >> n1 >> n2 >> n3;
//
//     if (n1 >= n2) {
//         if (n1 >= n3) {
//             cout << "the maximum is " << n1;
//         }else {
//             cout << "the maximum is " << n3;
//         }
//     }else {
//         if (n2 >= n3) {
//             cout << "the maximum is " << n2;
//         }else {
//             cout << "the maximum is " << n3;
//         }
//     }
//
//     return 0;
// }
