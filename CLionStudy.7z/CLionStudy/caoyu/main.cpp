#include <iostream>

int main1() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
