// Created by 黑马程序员.
#include "iostream"
using namespace std;

void say_love(int times)
{
    for (int i = 0; i < times; i ++)
    {
        cout << "小美，我喜欢你！！！" << endl;
    }
}

int main()
{
    say_love(5);
    return 0;
}
