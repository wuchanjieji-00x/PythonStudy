//
// Created by xiaozh52 on 2024/8/4.
//
#include <iostream>

int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
