// #include "iostream"
//
// using namespace std;
//
// int main() {
//
//
//     // 赋值运算符：=、+=、-=、/=、%=
//
//     // += 将变量本身进行加法操作，将结果再次赋值给变量本身
//     int num = 5;
//     num += 3; // 等同于num = num + 3
//     cout << num << endl; // 8
//
//     // -=  将变量本身进行减法操作，将结果再次赋值给变量本身
//     num -= 3; // 等同于 num = num - 3
//     cout << num << endl; // 5
//
//     // *=  将变量本身进行乘法操作，将结果再次赋值给变量本身
//     num *= 5; // 等同于 num = num * 5
//     cout << num << endl; // 25
//
//     // /=  将变量本身进行除法操作，将结果再次赋值给变量本身
//     num /= 5; // 等同于 num = num / 5
//     cout << num << endl; // 5
//
//     // %=  将变量本身进行取余操作，将结果再次赋值给变量本身
//     num %= 3;  // 等同于 num = num % 3
//     cout << num << endl; // 2
//
//
//     return 0;
// }



// // 练习
// #include "iostream"
//
// using namespace std;
//
// int main() {
//
//     int balance = 50;
//     cout << "小明余额：" << balance << "元。" << endl;
//
//     balance -= 5;
//     cout << "购买冰淇淋花费5元，余额剩余：" << balance << "元。" << endl;
//
//     balance += 10;
//     cout << "转卖冰淇淋的得到10元，余额剩余：" << balance << "元。" << endl;
//
//     balance -= 2;
//     cout << "购买彩票花费20元，余额剩余：" << balance << "元。" << endl;
//
//     balance *= 2;
//     cout << "彩票中奖余额翻倍，余额剩余：" << balance << "元。" << endl;
//
//
//     return 0;
// }

