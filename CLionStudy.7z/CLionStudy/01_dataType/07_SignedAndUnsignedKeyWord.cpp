// #include "iostream"
// #include "windows.h"
//
// using namespace std;
//
// int main() {
//
//     SetConsoleOutputCP(CP_UTF8);
//
//     // 有符号：signed(可选)
//     // 无符号：unsigned（必写）
//
//     int num1 = -10;
//     signed num2 = -10;
//     cout << num1 << ", " << num2 << endl;
//
//     unsigned int num3 = -30;  // 4294967266, num3只能接收正整数
//     cout << num3 << endl;
//
//
//     // 其他数据类型同int类型一致
//
//
//     // tips：
//     // 对于int, short, long的无符号类型有快捷写法
//     u_short num4 = 100;  // 等同于 unsigned shot
//     u_int num5 = 200;    // 等同于 unsigned int
//     u_long num6 = 1000;  // 等同于 unsigned long
//     cout << num4 << endl;
//     cout << num5 << endl;
//     cout << num6 << endl;
//
//
//
//     return 0;
// }