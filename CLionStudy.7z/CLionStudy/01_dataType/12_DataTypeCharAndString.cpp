// #include "iostream"
// #include "windows.h"
//
// using namespace std;
//
// int main() {
//
//     SetConsoleOutputCP(CP_UTF8);
//
//     // C语言风格的字符串（了解）
//     char s1[] = "itheima"; // 字符数组形式的字符串
//     char *s2 = "itcast"; // 指针形式的字符串
//
//     // C++语言风格的字符串 （首选）
//     string s3 = "I love C++"; // C++ string类型的字符串
//
//     // s1 = "666";   // s1是字符数组形式的字符串，不允许二次赋值
//     s2 = "777";
//     s3 = "888";
//
//     cout << s1 << endl;
//     cout << s2 << endl;
//     cout << s3 << endl;
//
//
//     return 0;
// }
