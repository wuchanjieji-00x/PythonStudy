// #include "iostream"
// #include "windows.h"
//
// using namespace std;
//
// int main() {
//     SetConsoleOutputCP(CP_UTF8);
//
//     // 变量的特征：变量的“量”是可以变的
//     int bmi = 30;
//     cout << "小明现在的BMI是：" << bmi << endl;
//
//     bmi = 25;
//     cout << "经过一个月的减肥，小明现在的BMI是：" << bmi << endl;
//
//     // 变量的特征：进行数学计算，加减乘除
//     bmi = bmi -2; // bmi -= 2
//     cout << "又经过一个月的减肥，小明的BMI减少了2点，小明现在的BMI是：" << bmi << endl;
//
//     return 0;
// }



// // 练习
// #include "iostream"
// #include "windows.h"
// using namespace std;
//
// int main() {
//     SetConsoleOutputCP(CP_UTF8);
//
//     int balance = 50;
//     cout << "小明余额：" << balance << "元。" << endl;
//
//     balance = balance - 5;
//     cout << "购买冰淇淋花费5元，余额剩余： " << balance << "元。" << endl;
//
//     balance = balance +10;
//     cout << "转卖冰淇淋得到10元，余额剩余： " << balance << "元。" << endl;
//
//     balance = balance - 2;
//     cout << "购买彩票花费2元，余额剩余： " << balance << "元。" << endl;
//
//     balance = balance * 2;
//     cout << "彩票中奖余额翻倍，余额剩余： " << balance << "元。" << endl;
//
//
//     return 0;
// }