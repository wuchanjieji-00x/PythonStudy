// #include "iostream"
// #include "windows.h"
//
// using namespace std;
//
// int main() {
//     SetConsoleOutputCP(CP_UTF8);
//     // 变量声明快捷方式1：变量类型 + 变量名称 = 变量值
//     int age = 21;
//     string name = "小明";
//     cout << "我叫做：" << name << ", 我今年" << age << "岁。" << endl;
//
//     // 变量声明快捷方式2：变量类型 + 变量名称, + 变量名称, ...
//     // 一次性声明多个变量
//     int a, b, c;
//     a = 10;
//     b = 20;
//     c = 30;
//     cout << a << b << c << endl;
//
//     // 变量声明快捷方式3：变量类型 + 变量名称1 = 变量值1， 变量名称2 = 变量值2， 变量名称3 = 变量值3， ...
//     int d = 40, e = 50, f = 60;
//     cout << d << e << f << endl;
//     return 0;
// }