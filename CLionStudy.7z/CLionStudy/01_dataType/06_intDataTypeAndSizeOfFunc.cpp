#include "iostream"
#include "windows.h"

using namespace std;

// int main() {
//     SetConsoleOutputCP(CP_UTF8);
//
//     // 四类整型：short\int\long\long long
//     short num1 = 10;
//     int num2 = 20;
//     long num3 = 30;
//     long long num4 = 40;
//     cout << num1 << endl;
//     cout << num2 << endl;
//     cout << num3 << endl;
//     cout << num4 << endl;
//
//
//     // sizeof() 函数：sizeof(数据)
//     // 输出数据占用的内存，单位是字节
//     cout << "short类型变量，占用字节：" << sizeof(num1) << endl;
//     cout << "int类型变量，占用字节：" << sizeof(num2) << endl;
//     cout << "long类型变量，占用字节：" << sizeof(num3) << endl;
//     cout << "long long类型变量，占用字节：" << sizeof(num4) << endl;
//
//     return 0;
// }




// // 练习
// #define BMI 30
// #define FLOAT 180.5
// #define CHAR "C"
// #define STRING "C++"
// int main() {
//
//     SetConsoleOutputCP(CP_UTF8);
//
//
//     cout << "整型符号常量，占用字节：" << sizeof(BMI) << endl;  // 4
//     cout << "浮点型符号常量，占用字节：" << sizeof(FLOAT) << endl; // 8
//     cout << "字符型符号常量，占用字节：" << sizeof(CHAR) << endl; // 2
//     cout << "字符串型符号常量，占用字节：" << sizeof(STRING) << endl; // 4
//
//     cout << "整型字面常量，占用内存：" << sizeof(30) << endl; //4
//     cout << "浮点型字面常量，占用内存：" << sizeof(180.5) << endl; // 8
//     cout << "字符型字面常量，占用内存：" << sizeof("C") << endl; // 2
//     cout << "字符串型字面常量，占用内存：" << sizeof("C++") << endl; // 4
//
//     return 0;
// }