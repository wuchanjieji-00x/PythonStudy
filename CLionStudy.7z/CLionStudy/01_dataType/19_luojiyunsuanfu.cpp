// #include "iostream"
//
// using namespace std;
//
// int main() {
//
//
//     // ! 非，对表达式的逻辑结果取反
//     bool b1 = !(1 == 1);
//     bool b2 = !(1 == 2);
//     cout << b1 << endl; // 0
//     cout << b2 << endl; // 1
//
//     // && 与
//     // 两个条件同时为真（true），结果为真，否则只要有一个为假，结果就为假
//     bool b3 = 1 == 1 && 2 == 2;
//     bool b4 = 1 == 2 && 2 == 2;
//     cout << b3 << endl; // 1
//     cout << b4 << endl; // 0
//
//     // || 或
//     // 只要有一个为真，结果就是真；两个条件都为假，结果就是假
//     bool b5 = 1 == 1 || 2 == 2;
//     bool b6 = 1 == 2 || 2 == 2;
//     bool b7 = 1 == 2 || 2 == 3;
//     cout << b5 << endl; // 1
//     cout << b6 << endl; // 1
//     cout << b7 << endl; // 0
//
//     return 0;
// }