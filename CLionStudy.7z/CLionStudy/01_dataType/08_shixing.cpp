// #include "iostream"
// #include "windows.h"
//
// using namespace std;
//
// int main() {
//
//     SetConsoleOutputCP(CP_UTF8);
//
//     // 实型：float\double\long double
//     // float：单精度浮点数，4字节，有效位数：6-7bit
//     // 有效位包括：整数位，小数点，小数位
//     float num1 = 1234567879; // 只有7位有效位
//     float num2 = 1.234567890; // 1.234568，只有7位有效位
//
//     cout << num1 << endl;  // 1.23457e+09  科学计数法
//     cout << fixed;         // 设置成小数显示
//     cout.width(20);   // 设置显示的最大宽度（最大位数），不够在前方用空格补充
//
//     cout << num1 << endl;  // 1234567936.000000，只有7位有效位
//     cout << num2 << endl;  // 1.234568，只有7位有效位
//
//     cout << sizeof(num1) << sizeof(num2) << endl; // 4 4
//
//
//     // double：双精度浮点数，8字节，有效位数：15-16bit
//     double num3 = 1234567890.1234567890;
//     cout << num3 << ", "<< sizeof(num3) << endl; // 1234567890.123457, 8, 8个字节，16个有效位
//
//     // long double：长精度（多精度）浮点数，16字节，有效位数：18-19bit
//     long double num4 = 1234567890.1234567890123456789;
//     cout << num4 << ", "<< sizeof(num4) << endl; // 1234567890.123457, 16, 16个字节，同样16个有效位
//     // long double对数字的内存获取并没有多大提升，其实还是看编译器
//
//
//     return 0;
// }