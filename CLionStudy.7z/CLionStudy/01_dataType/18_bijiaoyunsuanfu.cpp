// #include "iostream"
// #include "cstring"  // C语言的字符串处理库
// using namespace std;
//
// int main() {
//
//     // 比较运算符：
//     // == 相等；
//     // != 不相等；
//     // > 大于；
//     // < 小于
//     // >= 大于等于
//     // <= 小于等于
//
//     // int num1 = 3;
//     // int num2 = 5;
//     //
//     // // 0 false 假   1 true 真
//     // bool r1 = num1 == num2;
//     // bool r2 = num1 != num2;
//     // cout << "num1 == num2: " << r1 << endl;
//     // cout << "num1 != num2: " << r2 << endl;
//     //
//     // cout << "3 < 5 " << (3 < 5) << endl;
//     // cout << "3 > 5 " << (3 > 5) << endl;
//     // cout << "3 <= 5 " << (3 <= 5) << endl;
//     // cout << "3 >= 5 " << (3 >= 5) << endl;
//
//
//     // 字符串的比较
//
//     // // C语言风格字符串：
//     // // 数组形：1. char s[] = "hello"
//     // // 指针型：2. char *ptr = "hello"
//     // // 字面量型：3. "hello"
//     // char s1[] = "hello";
//     // char *s2 = "hello";
//     // cout << "s1 == s2 " << (s1 == s2) << endl; //结果为0
//     // // 比较C语言字符出啊你，直接应用比较运算符的话，比较的是内存地址，而不是内容
//     //
//     // // 需要用的strcmp()函数，需要导入cstring库
//     // // strcmp函数结果：0代表相等；-1代表s1 < s2; 1代表s1 > s2
//     // cout << "s1 == s2 " << strcmp(s1, s2) << endl; //结果为0
//     // char s3[] = "a";
//     // char *s4 = "b";
//     // cout << "s3和s4的比较结果： " << strcmp(s3, s4) << endl;  // -1
//     //
//     // cout << "字符串字面量 c 是否大于 a: " << strcmp("c", "a") << endl; // 1
//
//     // // C++字符串
//     // // 在字符串的比较中，只要有一个C++风格字符串就可以应用比较运算符了
//     // // 输出的是bool型结果
//     // string s5 = "a"; // C++风格
//     // char s6[] = "a"; // C语言风格
//     // cout << "s5 == s6 : " << (s5 == s6) << endl;  // 1
//
//
//     return 0;
// }