// # include "iostream"
// using namespace std;
//
// int main()
// {
//     21; // 整型，整数
//     180.5; // 实型，小数
//     'C'; // 字符，有且仅有1个，只能是1，不能是0或者其他数目
//     "itheima"; // 字符串，双引号包围，任意个字符.这是标注字符串
//     ""; // 空字符串
//     "C"; // 单字符串，标准字符串
//     // cout打印内容到控制台
//     cout << 21 << endl;
//     cout << 180.5 << endl;
//     cout << 'C' << endl;
//     cout << "itheima" << endl;
//     cout << "" << endl;
//
//     return 0;
// }
