// #include "iostream"
// #include "windows.h"
//
// using namespace std;
//
// int main() {
//
//     SetConsoleOutputCP(CP_UTF8);
//
//     // 布尔量：bool
//     // 字面量只有两个：true\false 全部小写
//     // 本质上对应：1/0
//     bool flag1 = true;   // true表示为真，本质上是数字1
//     bool flag2 = false;  // false表示为假，本质上是数字0
//
//     cout << flag1 << endl; // 1
//     cout << flag2 << endl; // 0
//
//     bool flag3 = 1;   // 虽然程序能运行，但是别这么写
//     bool flag4 = 0;  //
//
//     cout << flag3 << endl; // 1
//     cout << flag4 << endl; // 0
//
//
//
//     return 0;
// }
