#include <iostream>

int main0() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}



// code module
//
// #include "iostream"
// #include "windows.h"
//
// using namespace std;
//
// int main() {
//
//     SetConsoleOutputCP(CP_UTF8);
//
//
//
//     return 0;
// }



// #include "iostream"
//
// using namespace std;
//
// int main() {
//
//
//
//     return 0;
// }