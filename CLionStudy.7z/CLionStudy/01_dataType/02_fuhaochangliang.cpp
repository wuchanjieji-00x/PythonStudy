// #include <codecvt>
//
// #include "iostream"
// #include "windows.h"
// using namespace std;
// #define FAT_BMI 28
// #define J2C_RATE 4.19  //焦耳转卡路里的比率
//
// // 符号常量：#define + 名称(标识符) + 常量值
// // 符号常量定义在代码的开头
// // 符号常量的定义，不需要分号结尾
//
// // 解决中文乱码
// // 方式1：引入windows.h库
// // 方式2：引入system("chcp 65001")
//
// int main() {
//
//     // SetConsoleOutputCP(CP_UTF8);
//
//     system("chcp 65001");
//
//     // 使用符号常量的语句是正常的代码，要写在main函数中
//     // 使用：直接使用符号常量的标识符即可
//     cout << FAT_BMI << endl;
//     cout << "焦耳转卡路里需要除以： " << J2C_RATE << endl;
//     return 0;
// }

// // 练习：
// #include "iostream"
// #include "windows.h"
//
// #define NAME "周杰伦"
// #define AGE 21
// #define HEIGHT 180.5
// #define WEIGHT 56
//
// using namespace std;
//
// int main() {
//     SetConsoleOutputCP(CP_UTF8);
//
//     cout << "我是" << NAME << ", "<< "今年" << AGE << "岁。" << endl;
//     cout << "身高" << HEIGHT << "cm, " << "体重" << WEIGHT << "kg" <<endl;
//
//     return 0;
// }

