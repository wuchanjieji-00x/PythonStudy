// #include "iostream"
//
// using namespace std;
//
// int main() {
//
//
//     // // 单目（只有一个操作数）运算符：+、-
//     // int num1 = +10;
//     // int num2 = -10;
//     // cout << num1 << ", " << num2 << endl;
//
//     // // 双目（有两个操作数）运算符：+、-、*、/、%
//     // int num3 = 10 + 5;
//     // int num4 = 10 - 5;
//     // int num5 = 10 * 5;
//     // int num6 = 10 / 5;
//     // int num7 = 10 / 3; // 如果两个操作数都是整数，则结果为整除结果，即只除一次，舍弃余数
//     // int num8 = 10 % 3;
//     //
//     // cout << "10 + 5 = " << num3 << endl;
//     // cout << "10 - 5 = " << num4 << endl;
//     // cout << "10 * 5 = " << num5 << endl;
//     // cout << "10 / 5 = " << num6 << endl;
//     // cout << "10 / 3 = " << num7 << endl;
//     // cout << "10 % 3= " << num8 << endl;
//
//     // // 单目操作符：++(+1)、--(-1)
//     // // 前置递增
//     // int a1 = 2;
//     // int b = ++a1;
//     // cout << "a1= " << a1 << endl; // 3
//     // cout << "b= " << b << endl; // 3
//     // // 后置递增
//     // int a2 = 2;
//     // int c = a2++;
//     // cout << "a2= " << a2 << endl; // 3
//     // cout << "c= " << c << endl; // 2
//     // // 前置递减
//     // int a3 = 2;
//     // int d = --a3;
//     // cout << "a3= " << a3 << endl; // 1
//     // cout << "d= " << d << endl; // 1
//     // // 后置递减
//     // int a4 = 2;
//     // int e = a4--;
//     // cout << "a4= " << a4 << endl; // 1
//     // cout << "e= " << e << endl; // 2
//
//     return 0;
// }