// #include "iostream"
// #include "windows.h"
//
// using namespace std;
//
// int main() {
//     SetConsoleOutputCP(CP_UTF8);
//
//     // 字符串和字符串拼接
//     string name = "小黑";
//     string major = "物理";
//
//     string msg = "我的名字是：" + name + ", 我的专业是：" + major;
//     cout << msg << endl;
//     // 字符串和非字符串拼接
//     // 使用to_string(data)函数，将data转化为字符串后再拼接
//     int age = 21;
//     double height = 180.5; // 这里需要做精度控制，不然会出现很多0
//
//     string msg1 = "我的名字是：" + name + ", 我的专业是：" + major + ", 我的年龄是：" + to_string(age) + "岁"
//                   + ", 我的身高是：" + to_string(height) + "cm";
//     cout << msg1 << endl;
//
//
//     return 0;
// }