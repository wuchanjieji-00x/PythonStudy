// #include "iostream"
// #include "windows.h"
//
// using namespace std;
//
// int main() {
//
//     SetConsoleOutputCP(CP_UTF8);
//
//     // 转义字符：将普通的字符使用\开头，将其含义进行转换，对照得到ACII表的控制字符的功能
//     // \n : 换行
//     // \t : 制表符
//     // \\ : 表示一个反斜杠本身
//     // \': 单引号
//     // \": 双引号
//
//     // \n : 换行
//     cout << "你好呀 \n我喜欢你" << endl;
//
//     cout << "----------我是分割符" << endl;
//
//     // \t : 制表符
//     // \t = Tab键，一个\t相当于创建了一个表格的一个单元格，单元格的长度为8个字符位
//     // 没有按照表格对齐
//     cout << "Hello itheima" << endl;
//     cout << "a itcast" << endl;
//     // 按照表格对齐
//     cout << "Hello\titheima" << endl;
//     cout << "a\titcast" << endl;
//     cout << "----------我是分割符" << endl;
//
//     // \\ : 表示一个反斜杠本身
//     cout << "\\" << endl;  // \
//     cout << "----------我是分割符" << endl;
//
//     // 对于\"和\'，这是反向转义，将双引号和单引号的特殊功能消除掉
//     cout << " \"      \' " << endl;  //  "      '
//
//
//
//     return 0;
// }
