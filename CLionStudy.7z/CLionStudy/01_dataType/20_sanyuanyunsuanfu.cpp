// #include "iostream"
//
// using namespace std;
//
// int main() {
//
//
//     // // 三元运算符：
//     // // 表达式？ v1 : v2;
//     // // 如果表达式输出的bool量为真，输出v1的值
//     // // 如果表达式输出的boll量为假，输出v2的值
//     //
//     // int num1, num2;
//     // cout << "请输入num1的值：" << endl;
//     // cin >> num1;
//     // cout << "请输入num2的值：" << endl;
//     // cin >> num2;
//     //
//     // // 两种输出方式
//     // int num3 = num1 > num2? num1 : num2;
//     // cout << num3 << endl;
//     //
//     // // string value = num1 > num2? "num1大于num2" : "num1小于num2";
//     // // cout << value << endl;
//
//
//     // // 练习
//     // int num1, num2;
//     //
//     // cout << "请输入小明第一次考试的成绩：" << endl;
//     // cin >> num1;
//     // cout << "请输入小明第二次考试的成绩：" << endl;
//     // cin >> num2;
//     //
//     // string value = num2 > num1? "买糖" : "不买糖";
//     // cout << "对小明的考试成绩进行判断，结果是：" << value << endl;
//
//     return 0;
// }
