// #include "iostream"
// #include "windows.h"
//
// using namespace std;
//
// int main() {
//
//     SetConsoleOutputCP(CP_UTF8);
//
//     // // 非中文输入演示
//     // int num1;
//     // cout << "请输入一个整数：" << endl;
//     // cin >> num1;
//     // cout << num1 << endl;
//     //
//     // double num2;
//     // cout << "请输入一个小数：" << endl;
//     // cin >> num2;
//     // cout << num2 << endl;
//     //
//     // char c1;
//     // cout << "请输入一个字符：" << endl;
//     // cin >> c1;
//     // cout << c1 << endl;
//     //
//     // string s1;
//     // cout << "请输入一个字符串：" << endl;
//     // cin >> s1;
//     // cout << s1 << endl;
//
//
//     // // 中文乱码
//     // string s2;
//     // cout << "请输入一个中文字符串：" << endl;
//     // cin >> s2;
//     // cout << s2 << endl;
//     //
//     //
//     // return 0;
// }



// // 练习
//
// #include "iostream"
// using namespace std;
//
// int main() {
//
//     string name;
//     cout << "请输入您的姓名：" << endl;
//     cin >> name;
//
//     double height;
//     cout << "请输入您的身高（cm）:" << endl;
//     cin >> height;
//
//     int age;
//     cout << "请输入您的年龄：" << endl;
//     cin >> age;
//
//     cout << "信息输入完成，您的信息如下：" << endl;
//     cout << "姓名：" << name << endl;
//     cout << "身高：" << height << "cm" << endl;
//     cout << "年龄：" << age << endl;
//
//     return 0;
// }