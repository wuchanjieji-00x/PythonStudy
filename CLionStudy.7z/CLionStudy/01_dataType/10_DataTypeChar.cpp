// #include "iostream"
// #include "windows.h"
//
// using namespace std;
//
// int main() {
//
//     SetConsoleOutputCP(CP_UTF8);
//
//     // 字符存入的是数字，但实际上输出的是字符。对应ASCII表：美国信息交换标准代码
//     char ch = 97;
//     cout << ch << endl;  // a
//
//     char ch1 = 65;
//     cout << ch1 << endl;  // A
//
//     char ch2 = 'a';
//     cout << ch2 + 1 << endl;  // 98
//
//     char ch3 = 'a' + 2; // 99
//     cout << ch3 << endl;  // c
//
//     return 0;
// }