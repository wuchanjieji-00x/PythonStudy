// #include "iostream"
// #include "windows.h"
// using namespace std;
//
// int main() {
//
//     SetConsoleOutputCP(CP_UTF8);
//
//     // 1.变量的声明（定义）：变量类型+变量名；
//     int age;  // 声明整型变量
//     float height; // 声明实型（浮点型）变量
//     char gender;  // 声明字符型变量
//     string name; // 声明字符串型变量
//
//     // 2.变量的赋值：变量名 = 变量值
//     age = 21;
//     height = 180.5;
//     gender = 'm';
//     name = "小明";
//     // 3.使用变量：直接使用变量的标识符（名称）即可
//     cout << "age = " << age << endl;
//     cout << name << "的年纪: " << age << endl;
//     cout << name << "的身高: " << height << endl;
//     cout << name << "的性别: " << gender << endl;
//     return 0;
// }




// // 练习
// #include "iostream"
// #include "windows.h"
// using namespace std;
//
// int main() {
//
//     SetConsoleOutputCP(CP_UTF8);
//     string name;
//     int age;
//     float height;
//     int weight;
//
//     name = "周杰伦";
//     age = 21;
//     height = 180.5;
//     weight = 56;
//
//     cout << "我是" << name<< ", " << "今年" << age << "岁。" << endl;
//     cout << "身高" << height << "cm, " << "体重" << weight << "kg。" << endl;
//
//
//     return 0;
// }