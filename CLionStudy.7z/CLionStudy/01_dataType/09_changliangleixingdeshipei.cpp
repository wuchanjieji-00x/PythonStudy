// #include "iostream"
// #include "windows.h"
//
// using namespace std;
//
// int main() {
//
//     SetConsoleOutputCP(CP_UTF8);
//
//     // // 不带后缀的数字的类型适配：
//     // // 整数类型默认int
//     // // 小数类型默认double
//     //
//     // cout << "10的字节数是：" << sizeof(10) << endl; // 10的字节数是：4 int
//     // cout << "9999999999的字节数是：" << sizeof(9999999999) << endl; // 9999999999的字节数是：8  long long
//     // cout << "3.14的字节数是：" << sizeof(3.14) << endl; // 3.14的字节数是：8  double
//
//
//     // 带后缀的数字的类型适配：
//     // U/u = unsigned
//     cout << "10u的字节数是：" << sizeof(10u) << endl;  // 10u的字节数是：4
//
//     // L/l = long
//     // 注意：long类型在windows系统下是4字节，Linux系统下是8字节
//     cout << "10l的字节数是：" << sizeof(10l) << endl; //10l的字节数是：4
//
//     // F/f = float
//     // D/d = double 不用写，默认就是double
//     cout << "3.14f的字节数是：" << sizeof(3.14f) << endl; // 3.14f的字节数是：4 ,float
//     cout << "3.14的字节数是：" << sizeof(3.14) << endl; // 3.14的字节数是：8, 默认double
//
//
//     return 0;
// }