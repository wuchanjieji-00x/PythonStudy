// #include "iostream"
// #include "random"
// using namespace std;
//
// int get_random_num(int min, int max){
//     // 创建一个随机数生成器
//     random_device rd;
//     mt19937 gen(rd());
//
//     // 定义一个均匀分布的整数范围
//     uniform_int_distribution<> dis(min, max);
//
//     // 生成一个随机数并输出
//     int random_number = dis(gen);
//     return random_number;
// }
//
// int main() {
//
//
//     /*
//      * 获取数组长度： sizeof(数组对象) / sizeof(数组某个元素)
//      *
//      * 高级for循环获取数组每个元素：
//      * for (元素类型 临时变量: 数组变量)
//      * {
//      *      临时变量即数组元素;
//      *      逐个将数组元素赋值个循环控制因子;
//      * }
//      *
//      */
//
//     // int arr[] = {1, 2, 3, 4, 5};
//     //
//     // // while循环
//     // int i = 0; // 循环控制因子。在循环中作为数组的下标，从0开始
//     // while (i < sizeof(arr) / sizeof(arr[0])) {
//     //     cout << "while循环第" << i + 1 << "次取出的元素：" << arr[i] << endl;
//     //     i++; // 循环控制因子的更新
//     // }
//
//     // // for 循环
//     // // 这里循环因子还可以用i，因为while循环的i的作用域只在while循环里，已经被销毁了，这里可以接着用
//     // for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); i++) {
//     //     cout << "for循环第" << i + 1 << "次取出的元素：" << arr[i] << endl;
//     // }
//
//     // // 高级for循环
//     // for (int element: arr) {
//     //     cout << "高级for循环取出的元素：" << element << endl;
//     //
//     // }
//
//
//     // 练习
//     /*
//      * 声明1个10元素的数组
//      * 准备10个随机数字（1-100），存入数组中
//      * 找出数组中，最大的和最小的数字并输出
//      */
//
//
//     // int arr1[10];
//     // for (int i = 0; i < 10; i++) {
//     //     int num = get_random_num(1, 100);
//     //     arr1[i] = num;
//     // }
//     // // for (int element: arr1) {
//     // //     int num = get_random_num(1, 100);
//     // //     element = num;
//     // // }
//     // int max_value = arr1[0];
//     // int min_value = arr1[0];
//     // for (int element: arr1) {
//     //     cout << element << endl;
//     //     if (element > max_value) {
//     //         max_value = element;
//     //     }
//     //     if (element < min_value) {
//     //         min_value = element;
//     //     }
//     // }
//     // cout << max_value << ", " << min_value << endl;
//
//     return 0;
// }
