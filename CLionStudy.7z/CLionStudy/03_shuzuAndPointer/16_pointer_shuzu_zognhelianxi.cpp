// #include "iostream"
//
// using namespace std;
//
// int main() {
//
//     // // 降序排列
//     // int * pArr = new int[10]{3, 5, 1, 10, 9, 6, 2, 7, 8, 4};
//     //
//     // int min; // 变量用于记录最小值，也用于进行最小值的比较
//     // int min_index; // 用于记录最小值所在的下标
//     //
//     // for (int i = 0; i < 9; i++) {
//     //     // 循环执行9次，每一次都在当前选定的范围内，找出本次的最小值并放入开头位置
//     //     for (int j = i; j < 10; j++) {
//     //         if (j == i) { // 在第一个元素的时候
//     //             min = pArr[j]; // 将第一个元素记录到min中
//     //             min_index = j; // 将对应的下标记录到min_index中
//     //         }
//     //         // 开始比较
//     //         if (pArr[j] < min) {
//     //             min = pArr[j];
//     //             min_index = j;
//     //         }
//     //     }
//     //     // 进行交换，将当前最小值的值和第一个元素（相对，第一次是0下标，第二次是1下标，第三次是2下标。。。）进行位置交换
//     //     // 第一个元素的下标，用i即可
//     //     int tmp = pArr[i]; // 将i下标元素的值，通过tmp临时变量进行备份
//     //     pArr[i] = pArr[min_index];
//     //     pArr[min_index] = tmp;
//     // }
//     //
//     //
//     // for (int i = 0; i < 10; i++) {
//     //     cout << pArr[i] << endl;
//     // }
//
//
//
//     // // 升序排列
//     // int * pArr1 = new int[10]{3, 5, 1, 10, 9, 6, 2, 7, 8, 4};
//     //
//     // int max;
//     // int max_index;
//     //
//     // for (int i = 0; i < 9; i++) {
//     //     for (int j = i; j < 10; j++) {
//     //         if (j == i) {
//     //             max = pArr1[j];
//     //             max_index = j;
//     //         }
//     //
//     //         if (pArr1[j] > max) {
//     //             max = pArr1[j];
//     //             max_index = j;
//     //         }
//     //     }
//     //     int tmp1 = pArr1[i];
//     //     pArr1[i] = pArr1[max_index];
//     //     pArr1[max_index] = tmp1;
//     // }
//     //
//     // for (int i = 0; i < 10; i++) {
//     //     cout << pArr1[i] << endl;
//     // }
//
//     return 0;
// }
