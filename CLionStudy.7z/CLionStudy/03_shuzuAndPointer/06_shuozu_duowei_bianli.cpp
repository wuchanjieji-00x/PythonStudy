// #include "iostream"
//
// using namespace std;
//
// /*
//  * 会有多层嵌套循环
//  * 每一层循环对应一个维
//  * 一般for循环更为方便
//  */
//
//
// int main() {
//
//     // // 二维数组
//     // int v1[2][3] = {
//     //     {1, 2, 3},
//     //     {4, 5, 6}
//     // };
//     //
//     // for (int i = 0; i < sizeof(v1) / sizeof(v1[0]); i++) {
//     //     // v1[0] -> {1, 2, 3}
//     //     // v1[1] -> {4, 5, 6}
//     //     for (int j = 0; j < sizeof(v1[0]) / sizeof(v1[0][0]); j++) {
//     //         cout << v1[i][j] << endl;
//     //     }
//     // }
//
//
//     // // 三维数组
//     // int v2[2][2][3] = {
//     //     {
//     //         {1, 2, 3},
//     //         {4, 5, 6}
//     //     },
//     //     {
//     //         {7, 8, 9},
//     //         {10, 11, 12}
//     //     }
//     // };
//     // 常规写法
//     // for (int i = 0; i < sizeof(v2) / sizeof(v2[0]); i++) {
//     //     for (int j = 0; j < sizeof(v2[0]) / sizeof(v2[0][0]); j++) {
//     //         for (int k = 0; k < sizeof(v2[0][0]) / sizeof(v2[0][0][0]); k++) {
//     //             cout<< v2[i][j][k] << endl;
//     //         }
//     //     }
//     // }
//
//
//     // 在循环条件内计算数组元素时，更高级的写法：
//     // for (int i = 0; i < sizeof(v2) / sizeof(v2[0]); i++) {
//     //     for (int j = 0; j < sizeof(v2[j]) / sizeof(v2[j][0]); j++) {
//     //         for (int k = 0; k < sizeof(v2[j][k]) / sizeof(v2[j][k][0]); k++) {
//     //             cout<< v2[i][j][k] << endl;
//     //         }
//     //     }
//     // }
//
//
//
//
//     return 0;
// }
