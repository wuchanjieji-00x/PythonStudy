// #include "iostream"
//
// using namespace std;
//
//
// int main() {
//
//     // 在下标1和3位置插入数字2，4
//     int *p_arr = new int[5] {1, 3, 5, 7, 9};
//
//     int *p_newArry = new int[7];
//
//     int offset = 0;
//     for (int i = 0; i < 7; i++) {
//         if (i == 1) {
//             p_newArry[i] = 2;
//             offset++;
//             continue;
//         }else if (i == 3) {
//             p_newArry[i] = 4;
//             offset++;
//             continue;
//         }
//
//         p_newArry[i] = p_arr[i - offset];
//
//     }
//
//     delete[] p_arr;
//
//     p_arr = p_newArry;
//
//     for (int i = 0; i < 7; i++) {
//         cout << p_newArry[i] << endl;
//     }
//
//     return 0;
// }
