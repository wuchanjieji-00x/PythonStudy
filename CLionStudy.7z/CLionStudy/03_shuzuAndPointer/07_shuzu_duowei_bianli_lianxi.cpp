// #include "iostream"
// #include "random"
// using namespace std;
//
// int get_random_num(int min, int max){
//     // 创建一个随机数生成器
//     random_device rd;
//     mt19937 gen(rd());
//
//     // 定义一个均匀分布的整数范围
//     uniform_int_distribution<> dis(min, max);
//
//     // 生成一个随机数并输出
//     int random_number = dis(gen);
//     return random_number;
// }
//
// int main() {
//
//     string names[] = {
//         "Landon", "Avery", "Kamden", "Bentley", "Finnegan", "Nash", "Emmett", "Greyson",
//         "Noah", "Jace", "Jaxton", "Sawyer", "Zachary", "Eli", "Keegan", "Lincoln", "Isaac",
//         "Asher", "Declan", "Theo", "Levi", "Dominic", "Austin", "Wyatt", "Carter", "Logan",
//         "Luke", "Max", "Ethan", "Miles", "Oliver", "Hudson", "Owen", "William", "Joshua",
//         "Benjamin", "Henry", "Lucas", "Alexander", "Jackson", "Mason", "Grayson", "Ryder",
//         "Elijah", "Liam", "Caleb", "Thomas", "Cooper", "Hunter", "Connor"};
//
//     // cout << names[0] << endl;
//     // string str_arry[2][2][5];
//     // for (int i = 0; i < 2; i++) {
//     //     for (int j = 0; j < 2; j++) {
//     //         for (int k = 0; k < 5; k++){
//     //
//     //             string major = (i == 0? "物理" : "计算机");
//     //             string class_name = (j == 0? "一班" : "二班");
//     //             int seat_num = k + 1;
//     //
//     //             string name = names[get_random_num(0, (sizeof(names) / sizeof(names[0]) - 1))];
//     //
//     //             string msg = major + "专业, " + class_name + ", " + "座位号" + to_string(seat_num) + "的同学叫：" + name;
//     //
//     //             str_arry[i][j][k] = msg;
//     //
//     //             cout << str_arry[i][j][k] << endl;
//
//
//
//                 // cout << k << endl;
//                 // string name = names[get_random_num(0, (sizeof(names) / sizeof(names[0]) - 1))];
//                 //
//                 // cout << "专业" << i + 1 << ": " << (i == 0? "物理" : "计算机") << ", 班级：" << (j == 0? "1班" : "2班") + 1 << "班, " << "座位号：" << k + 1 << "号，" << "姓名: " << name << endl;
//             }
//         }
//     }
//     // for (int i = 0; i < 2; i++) {
//     //     for (int j = 0; j < 2; j++) {
//     //         for (int k = 0; k < 5; k++) {
//     //             cout << str_arry[i][j][k] << endl;
//     //         }
//     //     }
//     // }
//
//
//
//
//     return 0;
// }
