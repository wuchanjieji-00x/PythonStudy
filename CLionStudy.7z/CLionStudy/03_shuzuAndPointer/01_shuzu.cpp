// #include "iostream"
// #include "random"
// using namespace std;
//
// int get_random_num(int min, int max){
//     // 创建一个随机数生成器
//     random_device rd;
//     mt19937 gen(rd());
//
//     // 定义一个均匀分布的整数范围
//     uniform_int_distribution<> dis(min, max);
//
//     // 生成一个随机数并输出
//     int random_number = dis(gen);
//     return random_number;
// }
//
// int main() {
//
//
//     /*
//      *
//      * 数组类型 + 数组名称
//      *
//      *
//      *数组名称【下标索引】 可以访问数组元素
//      *
//      *
//      *
//      */
//
//
//     // // 数组声明和赋值分开完成
//     // // int v1[5] = {};
//     // int v1[5];
//     //
//     // v1[0] = 11;
//     // v1[1] = 22;
//     // v1[2] = 33;
//     // v1[3] = 44;
//     // v1[4] = 55;
//     //
//     // cout << "v1数组第1个元素是：" << v1[0] << endl;
//     // cout << "v1数组第2个元素是：" << v1[1] << endl;
//     // cout << "v1数组第3个元素是：" << v1[2] << endl;
//     // cout << "v1数组第4个元素是：" << v1[3] << endl;
//     // cout << "v1数组第5个元素是：" << v1[4] << endl;
//     //
//     // // 数组声明和赋值一起完成
//     // // 数组类型 + 数组名称+[] = {元素， 元素， 元素，...}
//     // int v2[] = {11, 22, 33, 44, 55};  // 这种情况，[]内不用写数组长度，IDE会自动识别出来
//     // cout << "v2数组第1个元素是：" << v2[0] << endl;
//     // cout << "v2数组第2个元素是：" << v2[1] << endl;
//     // cout << "v2数组第3个元素是：" << v2[2] << endl;
//     // cout << "v2数组第4个元素是：" << v2[3] << endl;
//     // cout << "v2数组第5个元素是：" << v2[4] << endl;
//
//
//
//     // // 练习
//     // // 获取随机数
//     // int num = get_random_num(1, 10);
//     // cout << num << endl;
//     //
//     // // 获取用户输入的10元素数组
//     // int arry[10];
//     // for (int i = 0; i < 10; i++) {
//     //     cout << "请输入第" << i + 1 << "个数字：";
//     //     // cout << endl;
//     //     cin >> arry[i];
//     // }
//     // // 判断数组中有几个和随机数相等的元素
//     // int times = 0;
//     // // for循环遍历数组
//     // for (int j = 0; j < 10; j++) {
//     //     if (arry[j] == num) {
//     //         times++;
//     //     }
//     // }
//     // cout << "你总共猜对了" << times << "次" << endl;
//
//     return 0;
// }