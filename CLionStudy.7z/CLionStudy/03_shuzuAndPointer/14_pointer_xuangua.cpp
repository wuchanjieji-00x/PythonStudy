// #include "iostream"
//
// using namespace std;
//
// /*
//  * 1. 不要轻易进行指针之间的赋值。
//  * 2. 一旦用delete，要确保真的这个内存区域没人用了。
//  */
//
// int main() {
//
//     int *p1 = new int;
//     *p1 = 10;
//
//     int *p2 = p1;
//
//     cout << "指针变量p1指向的内存区域的值是：" << *p1 << endl;
//     // delete p1;
//     // 删除指针变量p1，那么指针变量p2的指向是不可控的，那么输出其指向的值就是随机的
//     cout << "指针变量p2指向的内存区域的值是：" << *p2 << endl;
//
//
//
//
//
//     return 0;
// }
