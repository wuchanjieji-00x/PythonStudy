#include "iostream"
using namespace std;

int main()
{
    cout << "I Love C++" << endl;  // 除纯数字外，必须用双引号
    cout << 10 << endl; // 纯数字可用可不用引号
    cout << "I am 10 " << "years old" << endl;

    return 0;
}