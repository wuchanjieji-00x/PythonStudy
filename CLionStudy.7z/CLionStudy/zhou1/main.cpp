#include <iostream>

int mainws() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
