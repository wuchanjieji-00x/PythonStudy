//
// Created by xiaozh52 on 24-8-4.
//
#include "iostream"
using namespace std;

int main()
{
    cout << "Hello World!!!" << endl;
    return 0;
}
