
#include "vector"
using namespace std;



// 216.组合总和III


int main() {

    // backTacking
    class Solution{
    private:
        vector<vector<int>> result;
        vector<int> path;
        // targetSum：目标和，也就是题目中的n。
        // k：题目中要求k个数的集合。
        // sum：已经收集的元素的总和，也就是path里元素的总和。
        // 其实这里sum这个参数也可以省略，每次targetSum减去选取的元素数值，然后判断如果targetSum为0了，说明收集到符合条件的结果了
        // startIndex：下一层for循环搜索的起始位置
        void backTracking(int targetSum, int k, int sum, int startIndex) {
            if (path.size() == k) {
                if (sum == targetSum) result.push_back(path);
                return;  // 如果path.size() == k 但sum != targetSum 直接返回,不收集结果
            }

            for (int i = startIndex; i <= 9; i++) {
                sum += i; // 处理
                path.push_back(i); // 处理
                backTracking(targetSum, k, sum, i+1); // 注意i+1调整startIndex
                sum -= i; // 回溯
                path.pop_back(); // 回溯
            }
        }

    public:
        vector<vector<int>> combinationSum3(int k, int n) {
            result.clear();
            path.clear();
            backTracking(n, k, 0, 1);
            return result;
        }

    };



    // 剪枝优化
    class Solution {
    private:
        vector<vector<int>> result; // 存放结果集
        vector<int> path; // 符合条件的结果
        void backtracking(int targetSum, int k, int sum, int startIndex) {
            if (sum > targetSum) { // 剪枝操作
                return;  // 如果path里的元素和已经大于n了，就没有必要再往下遍历了
            }
            if (path.size() == k) {
                if (sum == targetSum) result.push_back(path);
                return; // 如果path.size() == k 但sum != targetSum 直接返回
            }
            for (int i = startIndex; i <= 9 - (k - path.size()) + 1; i++) { // 剪枝：我要k个元素，集合中至少有k个元素我才去遍历
                // i是集合的下标，9是集合的最大值，9 - (k - path.size()) + 1是剪枝操作，剪掉后面不满足条件的元素
                sum += i; // 处理
                path.push_back(i); // 处理
                backtracking(targetSum, k, sum, i + 1); // 注意i+1调整startIndex
                sum -= i; // 回溯
                path.pop_back(); // 回溯
            }
        }

    public:
        vector<vector<int>> combinationSum3(int k, int n) {
            result.clear(); // 可以不加
            path.clear();   // 可以不加
            backtracking(n, k, 0, 1);
            return result;
        }
    };






    return 0;

}