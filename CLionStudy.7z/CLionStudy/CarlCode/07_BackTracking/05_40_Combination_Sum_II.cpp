

#include <algorithm>
#include <vector>
using namespace std;

// 40.组合总和II




int main() {

    // 要在搜索的过程中就去掉重复组合
    // 所谓去重，其实就是使用过的元素不能重复选取。
    // 也就是说,如果数组内本身有重复元素,那么在一个组合中,这两个重复的元素是可以同时出现的.因为虽然元素相同,但仍然是两个元素
    // 但是不能出现两个相同的组合。

    // 综合来看,假如数组中有重复元素,我们已经拿相同元素的第一个,和数组元素进行组合匹配了,那么如果接着拿剩余的相同元素再去和数组元素进行组合匹配的话
    // 那必然会出现相同的组合

    // 强调一下，树层去重的话，需要对数组排序！因为这样,我们就能保证相同的元素出现在一起，我们只拿相同元素的第一个去组合匹配数组元素,
    // 其他的相同元素直接跳过,这样我们就能保证相同的元素不会出现在同一层中。
    // 也就是所谓的同一树层相同两个或多个重复元素,不能重复选取
    // 但是,同一树枝上相同元素可以重复选取


    // 解法1:用used数组去重
    // 时间复杂度: O(n * 2^n)
    // 空间复杂度: O(n)
    class Solution {
    private:
        vector<vector<int>> result;
        vector<int> path;
        void backTracking(vector<int>& candidates, int target, int sum, int startIndex, vector<bool>& used) {
            if (sum == target) {
                result.push_back(path);
                return;
            }

            // 请体会这里for循环终止的第二个判断条件
            for (int i = startIndex; i < candidates.size() && sum + candidates[i] <= target; i++) {
                // used[i - 1] == true，说明同一树枝candidates[i - 1]使用过
                // used[i - 1] == false，说明同一树层candidates[i - 1]使用过
                // 要对同一树层使用过的元素进行跳过
                if (i > 0 && candidates[i] == candidates[i - 1] && !used[i- 1] == false) {
                    continue;
                }
                sum += candidates[i];
                path.push_back(candidates[i]);
                used[i] = true;
                // 这里的startIndex == i+1是为了一个元素只能使用一次
                backTracking(candidates, target, sum, i + 1, used);
                used[i] = false;
                sum -= candidates[i];
                path.pop_back();
            }
        }

    public:
        vector<vector<int>> combinationSum2(vector<int>& candidates, int target) {
            vector<bool> used(candidates.size(), false);
            // usede数组大小一定和传入的数组大小一致,意为将元素映射为元素是否使用过的bool量
            result.clear();
            path.clear();
            // 首先把给candidates排序，让其相同的元素都挨在一起。
            // 之后,我们只使用相同元素的第一个元素,而后的相同元素都在for循环的continue 语句中跳过。
            sort(candidates.begin(), candidates.end());
            backTracking(candidates, target, 0, 0, used); // 从传入的数组第一个元素开始递归遍历
            return  result;
        }
    };


    // 解法2:
    // 直接用startIndex来去重
    class Solution {
    private:
        vector<vector<int>> result;
        vector<int> path;
        void backTracking(vector<int>& candidates, int target, int sum, int startIndex) {
            if (sum == target) {
                result.push_back(path);
                return;
            }

            for (int i = startIndex; i < candidates.size() && sum + candidates[i] <= target; i++) {
                // 要对同一树层使用过的元素进行跳过
                // 或者说是,数组中使用过的元素,后面出现其数值相同的元素就跳过
                if (i > startIndex && candidates[i] == candidates[i - 1]) {
                    continue;
                }
                sum += candidates[i];
                path.push_back(candidates[i]);
                backTracking(candidates, target, sum, i + 1); // 和39.组合总和的区别1，这里是i+1，每个元素在每个组合中只能使用一次
                sum -= candidates[i];
                path.pop_back();
            }
        }

    public:
        vector<vector<int>> combinationSum2(vector<int>& candidates, int target) {
            result.clear();
            path.clear();
            // 首先把给candidates排序，让其相同的元素都挨在一起
            sort(candidates.begin(), candidates.end());
            backTracking(candidates, target, 0, 0);
            return  result;
        }
    };






    return 0;

}