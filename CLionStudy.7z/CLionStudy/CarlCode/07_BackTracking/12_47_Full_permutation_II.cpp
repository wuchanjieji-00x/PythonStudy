
#include <algorithm>
# include <vector>
using namespace std;


// 47.全排列 II



int main() {

    //
    // 时间复杂度: 最差情况所有元素都是唯一的。复杂度和全排列1都是 O(n! * n) 对于 n 个元素一共有 n! 中排列方案。
    // 而对于每一个答案，我们需要 O(n) 去复制最终放到 result 数组
    // 空间复杂度: O(n) 回溯树的深度取决于我们有多少个元素

    // 如果要对树层中前一位去重，就用used[i - 1] == false，如果要对树枝前一位去重用used[i - 1] == true
    class Solution {
    private:
        vector<vector<int>> result;
        vector<int> path;
        void backtracking (vector<int>& nums, vector<bool>& used) {
            // 此时说明找到了一组
            if (path.size() == nums.size()) {
                result.push_back(path);
                return;
            }
            for (int i = 0; i < nums.size(); i++) {
                // used[i - 1] == true，说明同一树枝nums[i - 1]使用过
                // used[i - 1] == false，说明同一树层nums[i - 1]使用过
                // 如果同一树层nums[i - 1]使用过则直接跳过
                if (i > 0 && nums[i] == nums[i - 1] && used[i - 1] == false) {  // 树层去重
                    continue;
                }
                if (used[i] == false) {  // 树枝去重: 同一树枝上，nums[i]已经使用过了
                    used[i] = true;
                    path.push_back(nums[i]);
                    backtracking(nums, used);
                    path.pop_back();
                    used[i] = false;
                }
            }
        }
    public:
        vector<vector<int>> permuteUnique(vector<int>& nums) {
            result.clear();
            path.clear();
            sort(nums.begin(), nums.end()); // 排序
            vector<bool> used(nums.size(), false);
            backtracking(nums, used);
            return result;
        }
    };








    return 0;

}