


#include <algorithm>
#include <vector>
#include <unordered_set>
using namespace std;


// 90.子集II

// 这是取有重复元素的子集,可以任意改变顺序,所以我们去重之前可以将数组先排序,让相同的元素紧挨在一起


int main() {

    // 版本1:used数组 + 排序, 去重
    class Solution {
    private:
        vector<vector<int>> result;
        vector<int> path; // 其实这里取名为node更合适
        void backTracking(vector<int>& nums, int startIndex, vector<bool>& used) {
            result.push_back(path);
            // 不用写终止条件,for循环里的判断条件相当于已经做了终止条件了
            for (int i = startIndex; i < nums.size(); i++) {
                // used[i - 1] == true，说明同一树枝candidates[i - 1]使用过
                // used[i - 1] == false，说明同一树层candidates[i - 1]使用过
                // 而我们要对同一树层使用过的元素进行跳过
                if (i > 0 && nums[i] == nums[i - 1] && used[i - 1] == false) {
                    continue;
                }
                path.push_back(nums[i]);
                used[i] = true;
                backTracking(nums, i + 1, used);
                used[i] == false;
                path.pop_back();
            }
        }

    public:
        vector<vector<int>> subsetsWithDup(vector<int>& nums) {
            result.clear();
            path.clear();
            vector<bool> used(nums.size(), false);
            sort(nums.begin(), nums.end()); // 去重需要排序
            backTracking(nums, 0, used);
            return result;
        }
    };


    // 版本2:set去重
    // 没看懂
    class Solution {
    private:
        vector<vector<int>> result;
        vector<int> path;
        void backtracking(vector<int>& nums, int startIndex) {
            result.push_back(path);
            unordered_set<int> uset;
            for (int i = startIndex; i < nums.size(); i++) {
                if (uset.find(nums[i]) != uset.end()) {  // 这里是for循环里的跳过操作,是针对横向遍历每一层所作的去重逻辑
                    continue;
                }
                uset.insert(nums[i]);
                path.push_back(nums[i]);
                backtracking(nums, i + 1);
                path.pop_back();
            }
        }

    public:
        vector<vector<int>> subsetsWithDup(vector<int>& nums) {
            result.clear();
            path.clear();
            // sort(nums.begin(), nums.end()); // 去重需要排序
            // 这里我们用unordered_set,不用set,因为set不能存储重复元素.这里不需要排序了
            backtracking(nums, 0);
            return result;
        }
    };



    // 版本3:使用startIndex + 排序,去重
    class Solution {
    private:
        vector<vector<int>> result;
        vector<int> path;
        void backtracking(vector<int>& nums, int startIndex) {
            result.push_back(path);
            for (int i = startIndex; i < nums.size(); i++) {
                // 而我们要对同一树层使用过的元素进行跳过
                if (i > startIndex && nums[i] == nums[i - 1] ) { // 注意这里使用i > startIndex
                    continue;
                }
                path.push_back(nums[i]);
                backtracking(nums, i + 1);
                path.pop_back();
            }
        }

    public:
        vector<vector<int>> subsetsWithDup(vector<int>& nums) {
            result.clear();
            path.clear();
            sort(nums.begin(), nums.end()); // 去重需要排序
            backtracking(nums, 0);
            return result;
        }
    };






    return 0;

}
