// // #include "iostream"
//
// #include <vector>
// using namespace std;
//
// // 第77题. 组合
//
//
//
//
// int main() {
//
//     // backTracking 回溯
//     class Solution {
//     private:
//         vector<vector<int>> result; // 二维数组result来存放结果集
           // 至于为什么取名为path？从上面树形结构中，可以看出，结果其实就是一条根节点到叶子节点的路径
//         vector<int> path; // 一维数组path来存放符合条件的结果
//         void backTracking(int n, int k,int startIndex) {
//             if (path.size() == k) {
//                 result.push_back(path);
//                 return;
//             }
//
//             for (int i = startIndex; i <= n; i++) {
//                 path.push_back(i); // 处理节点
//                 backTracking(n, k, i + 1); // 递归
//                 path.pop_back(); // 回溯，撤销处理的节点
//             }
//         }
//
//     public:
//         vector<vector<int>> combine(int n, int k) {
//             result.clear(); // 可以不写
//             path.clear(); // 可以不写
//             // 这里的startIndex可以不写，默认从1开始?？？
//             // 这里的startIndex为什么是1？？
//             // 因为我们的path是由集合里的元素组成的，我们第一次往path里放元素放的就是集合的第一个元素
//             backTracking(n, k, 1);
//             return result;
//         }
//     };
//
//
//     // 剪枝优化
//     // 时间复杂度: O(n * 2^n)
//     // 空间复杂度: O(n)
//     class Solution {
//     private:
//         vector<vector<int>> result;
//         vector<int> path;
//         void backtracking(int n, int k, int startIndex) {
//             if (path.size() == k) {
//                 result.push_back(path);
//                 return;
//             }
//             for (int i = startIndex; i <= n - (k - path.size()) + 1; i++) { // 优化的地方
//                 path.push_back(i); // 处理节点
//                 backtracking(n, k, i + 1);
//                 path.pop_back(); // 回溯，撤销处理的节点
//             }
//         }
//     public:
//
//         vector<vector<int>> combine(int n, int k) {
//             backtracking(n, k, 1);
//             return result;
//         }
//     };
//
//
//
//
//
//
//
//
//     return 0;
//
// }