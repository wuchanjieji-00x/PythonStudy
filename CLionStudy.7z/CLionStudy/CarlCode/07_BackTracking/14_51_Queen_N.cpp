

#include <string>
#include <vector>
using namespace std;


// 51. N皇后



int main() {


    // 回溯
    // 棋盘的列数(宽度)就是for循环的长度，棋盘的行数(高度)就是递归的深度
    // for循环遍历行，递归遍历列
    // 时间复杂度: O(n!)
    // 空间复杂度: O(n)
    class Solution {
    private:
        vector<vector<string>> result;

        // n 为输入的棋盘大小，n * n的棋盘
        // row 是当前递归到棋盘的第几行了
        void backTracking(int n, int row, vector<string>& chessboard) {
            if (row == n) {
                result.push_back(chessboard);
                return; // 递归结束条件.一条路径走完，收获一条结果，就是一个排布方案，结束递归
            }

            for (int col = 0; col < n; col++) {
                // 不合法的路径直接跳过
                if (isValid(row, col, chessboard, n)) { // 验证合法就可以放
                    chessboard[row][col] = 'Q'; // 放置皇后
                    backTracking(n, row + 1, chessboard);
                    chessboard[row][col] = '.'; // 回溯，撤销皇后
                }
            }
        }

        bool isValid(int row, int col, vector<string>& chessboard, int n) {
            // 检查列
            for (int i = 0; i < row; i++) {
                if (chessboard[i][col] == 'Q') {
                    return false;
                }
            }

            // 因为在单层搜索的过程中，每一层递归，只会选for循环（也就是同一行）里的一个元素，所以行内不用去重了。
            // 行内是逐个遍历列，所以行内不用去重了

            // 检查 135度角是否有皇后
            for (int i = row - 1, j = col - 1; i >=0 && j >= 0; i--,j--) {
                if (chessboard[i][j] == 'Q') {
                    return  false;
                }
            }
            // 检查 45度角是否有皇后
            for(int i = row - 1, j = col + 1; i >= 0 && j < n; i--, j++ ) {
                if (chessboard[i][j] == 'Q') {
                    return false;
                }
            }

            return true;
        }
    public:
        vector<vector<string>> solveNQueens(int n) {
            result.clear();
            vector<string> chessboard(n, string(n, '.'));
            // chessboard是一个包含n个字符串（由n个.组成的字符串）的n * n的矩阵（二维数组）
            backTracking(n, 0, chessboard);
            return result;
        }
    };








    return 0;

}
