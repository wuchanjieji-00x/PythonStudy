
#include <vector>
#include <unordered_set>

using namespace std;

// 491.递增子序列
// 这里和直接取子集的区别: 数组中有



int main() {

    // 版本一:使用 unordered_set 树层去重
    class Solution {
    private:
        vector<vector<int>> result;
        vector<int> path;
        void backtracking(vector<int>& nums, int startIndex) {
            if (path.size() > 1) {
                result.push_back(path);
                // 注意这里不要加return，要取树上的节点
            }
            // 是记录本层元素是否重复使用，新的一层uset都会重新定义（清空），所以要知道uset只负责本层！
            // 只所以用unordered_set, 因为set底层是红黑树，可以快速查找.且它可以支持快速查重,而不需要对数组先进行排序,让相同元素紧挨在一起
            unordered_set<int> uset; // 使用set对本层元素进行去重
            for (int i = startIndex; i < nums.size(); i++) {
                if ((!path.empty() && nums[i] < path.back())  // 确保递增
                        || uset.find(nums[i]) != uset.end()) { // 树层去重
                    continue;
                        }
                uset.insert(nums[i]); // 记录这个元素在本层用过了，本层后面不能再用了
                path.push_back(nums[i]);
                backtracking(nums, i + 1);
                path.pop_back();
            }
        }
    public:
        vector<vector<int>> findSubsequences(vector<int>& nums) {
            result.clear();
            path.clear();
            backtracking(nums, 0);
            return result;
        }
    };


    // // 版本2:使用 数组 树层去重
    // 数组，set，map都可以做哈希表，而且数组干的活，map和set都能干，但如果数值范围小的话能用数组尽量用数组。
    // 题目说数值范围[-100, 100]
    class Solution {
    private:
        vector<vector<int>> result;
        vector<int> path;
        void backtracking(vector<int>& nums, int startIndex) {
            if (path.size() > 1) {
                result.push_back(path);
            }
            int used[201] = {0}; // 这里使用数组来进行去重操作，题目说数值范围[-100, 100]
            for (int i = startIndex; i < nums.size(); i++) {
                if ((!path.empty() && nums[i] < path.back())
                        || used[nums[i] + 100] == 1) {
                    continue;
                        }
                used[nums[i] + 100] = 1; // 记录这个元素在本层用过了，本层后面不能再用了
                path.push_back(nums[i]);
                backtracking(nums, i + 1);
                path.pop_back();
            }
        }
    public:
        vector<vector<int>> findSubsequences(vector<int>& nums) {
            result.clear();
            path.clear();
            backtracking(nums, 0);
            return result;
        }
    };







    return 0;

}
