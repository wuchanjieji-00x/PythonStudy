// #include <vector>
//
// #include "string"
// using namespace std;
//
// // 17.电话号码的字母组合
//
//
//
//
// int main() {
//
//     // 版本1
//     // 时间复杂度: O(3^m * 4^n)，其中 m 是对应三个字母的数字个数，n 是对应四个字母的数字个数
//     // 空间复杂度: O(3^m * 4^n)
//     class Solution {
//     private:
//         const string letterMap[10] = {
//             "", // 0
//             "", // 1
//             "abc", // 2
//             "def", // 3
//             "ghi", // 4
//             "jkl", // 5
//             "mno", // 6
//             "pqrs", // 7
//             "tuv", // 8
//             "wxyz", // 9
//         };
//     public:
//         vector<string> result;
//         string s;
//         void backTracking(const string& digits, int index) {
//             if (index == digits.size()) {
//                 result.push_back(s);
//                 return;
//             }
//
//             int digit = digits[index] - '0';  // 将index指向的字符类型的数字转为int
//             string letters = letterMap[digit]; // 取数字对应的字符集
//
//             for (int i = 0; i < letters.size(); i++) {
//                 s.push_back(letters[i]); // 处理
//                 backTracking(digits, index + 1); // 递归，注意index+1，下一层要处理下一个数字了
//                 s.pop_back();  // 回溯
//             }
//         }
//
//         vector<string> letterCombinations(string digits) {
//             s.clear();
//             result.clear();
//             if (digits.size() == 0) {
//                 return result;
//             }
//
//             backTracking(digits, 0); // 从输入的字符串中的第一个数字字符开始遍历
//             return result;
//         }
//     };
//
//
//
//
//     // 版本二
//     // 把回溯的过程放在递归函数里
//     class Solution {
//     private:
//         const string letterMap[10] = {
//             "", // 0
//             "", // 1
//             "abc", // 2
//             "def", // 3
//             "ghi", // 4
//             "jkl", // 5
//             "mno", // 6
//             "pqrs", // 7
//             "tuv", // 8
//             "wxyz", // 9
//         };
//     public:
//         vector<string> result;
//         void getCombinations(const string& digits, int index, const string& s) { // 注意参数的不同
//             if (index == digits.size()) {
//                 result.push_back(s);
//                 return;
//             }
//             int digit = digits[index] - '0';
//             string letters = letterMap[digit];
//             for (int i = 0; i < letters.size(); i++) {
//                 getCombinations(digits, index + 1, s + letters[i]);  // 注意这里的不同
//             } // i=0时，s为空，然后s加上i，作为新的s去递归遍历另一个index对应的字符集，然后递归结束，返回上一层，然后i=1，s仍然为空
//         }
//         vector<string> letterCombinations(string digits) {
//             result.clear(); // 因为s是作为s传进来的，我们将s的初始化或者元素的清除，放在了函数的形参里了
//             if (digits.size() == 0) {
//                 return result;
//             }
//             getCombinations(digits, 0, "");
//             return result;
//
//         }
//     };
//
//
//
//
//
//
//
//
//
//
//     return 0;
//
// }
