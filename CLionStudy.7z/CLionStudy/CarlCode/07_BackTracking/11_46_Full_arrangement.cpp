


#include <vector>
using namespace std;

// 46.全排列
// 首先排列是有序的，也就是说 [1,2] 和 [2,1] 是两个集合，这和之前分析的子集以及组合所不同的地方。
// 也就是说,允许出现元素数值相同,但是元素位置不同的数组

// 排列问题的不同
// 1.每层都是从0开始搜索而不是startIndex
// 2.需要used数组记录path里都放了哪些元素了.
// 也就是说,我们对每一个节点,都递归匹配了整个数组的元素,所以不需要startIndex,每次都是从数组第一个元素开始匹配
// 但是,对于树枝而言,当前节点去遍历匹配数组元素时,对于当前节点的上一节点,也就是同一个分支上,已经遍历过的元素,不能再遍历了.
// 因为,同一排列组合中,每个元素只能使用一次


// 可以把全排列看作一个相同的组合,但是组合中的元素是有序的

int main() {

    // 版本1
    // 时间复杂度: O(n!)
    // 空间复杂度: O(n)
    class Solution {
    public:
        vector<vector<int>> result;
        vector<int> path; // 其实命名为node更合适
        void backTracking(vector<int>& nums, vector<bool>& used) {
            if (path.size() == nums.size()) {
                result.push_back(path);
                return;
            }

            for (int i = 0; i < nums.size(); i++) {
                if (used[i] == true) continue;

                used[i] = true; // 表明在当前i这个分支上,已经使用过元素i了,分支下面的子分支上不能重复使用了
                path.push_back(nums[i]);
                backTracking(nums, used);
                path.pop_back();
                used[i] = false;
            }
        }

        vector<vector<int>> permute(vector<int>& nums) {
            result.clear();
            path.clear();
            vector<bool> used(nums.size(), false);
            backTracking(nums, used);
            return result;
        }
    };







    return 0;

}
