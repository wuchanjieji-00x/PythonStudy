
#include <vector>
using namespace std;


// 37. 解数独
// 二维递归



int main() {


    //
    class Solution {
    private:
        // 因为解数独找到一个符合的条件（就在树的叶子节点上）立刻就返回，
        // 相当于找从根节点到叶子节点一条唯一路径，所以需要使用bool返回值。
        // 我们只需要找到一种方案就返回true了，不需要用result数组存储所有解（如果解不唯一的话）。
        bool backTracking(vector<vector<char>>& board) {
            for (int i = 0; i < board.size(); i++) {  // 遍历行
                for (int j = 0; j < board[0].size(); j++) {  // 遍历列
                    if (board[i][j] != '.') { // 只在空格上放数字
                        for (char k = '1'; k <= '9'; k++) { // 从1-9遍历填充
                            if (isValid(i, j, k, board)) { // 只有是合法的才继续递归  // (i, j) 这个位置放k是否合适
                                board[i][j] = k; // 合法则放k
                                if (backTracking(board)) return true; // 在放置k这个树枝上往下递归遍历，如果有解，返回true
                                board[i][j] = '.';   // 回溯，撤销k  // 在k的树枝上如果没有找到解，则撤销k,回溯，继续递归求解
                            }
                        }
                        return false;  // 9个数都试完了，都不行，那么就返回false
                        // 这里就是一个树枝上的递归终止条件
                    }
                }

            }
            return true; // 遍历完没有返回false，说明找到了合适棋盘位置了
            // 不对，在遍历中，会遍历整棵树，要么有解，我们就在这里返回true，通过递归函数一层一层返回；要么没有解，舍弃树枝，返回false
            // 说白了，这个return是当遍历到最后一个格子，说明找到了一种方案，就return true，通过递归函数一层一层返回，直到根节点，返回true，说明找到了解
        }
        bool isValid(int row, int col, char val, vector<vector<char>>& board) {
            // 判断行里是否重复
            // 这里为什么需要检查行？因为这一格子试过1-9,下一个格子还是从1-9开始遍历
            // 这里肯定能优化，树层肯定能剪枝的
            for (int i = 0; i < 9; i++) {
                if (board[row][i] == val) {
                    return false;
                }
            }
            // 判断列里是否重复
            for (int j = 0; j < 9; j++) {
                if (board[j][col] == val) {
                    return false;
                }
            }
            // int startRow = row - row % 3;
            // int startCol = col - col % 3;
            int startRow = (row / 3) * 3;
            int startCol = (col / 3) * 3;
            for (int i = startRow; i < startRow + 3; i++) { // 判断9方格里是否重复
                for (int j = startCol; j < startCol + 3; j++) {
                    if (board[i][j] == val) {
                        return false;
                    }
                }
            }
            return true; // 如果三个检查条件都满足了（没有返回false），则返回true
        }

    public:
        void solveSudoku(vector<vector<char>>& board) {
            backTracking(board); // 递归函数会给我们返回bool结果
        }
    };


    return 0;

}