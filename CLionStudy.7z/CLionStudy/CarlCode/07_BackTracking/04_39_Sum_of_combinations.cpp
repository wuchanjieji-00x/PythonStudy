
#include <algorithm>
#include <vector>
using namespace std;

// 39. 组合总和




int main() {

    // 版本1
    class Solution {
    private:
        vector<vector<int>> result;
        vector<int> path;
        void backTracking(vector<int>& candidates, int target, int sum, int startIndex) {
            if (sum > target) {
                return;  // 舍弃
            }

            if (sum == target) {
                result.push_back(path);
                return; // 将路径添加到结果中
            }

            for (int i = startIndex; i < candidates.size(); i++) {
                sum += candidates[i];
                path.push_back(candidates[i]);
                // 请好好体会下面这个i
                // 我们要做的是树层去重，而非树枝去重
                backTracking(candidates, target, sum, i); // 不用i+1了，表示可以重复读取当前的数
                sum -= candidates[i];
                path.pop_back();
            }
        }

    public:
        vector<vector<int>> combinationSum(vector<int>& candidates, int target) {
            result.clear();
            path.clear();
            backTracking(candidates, target, 0, 0);
            // 这里的startIndex从0开始，这才是正规的写法，表示的是数组的第一个元素
            return  result;
        }
    };



    // 剪枝优化
    // 在求和问题中，排序之后加剪枝是常见的套路！
    class Solution {
    private:
        vector<vector<int>> result;
        vector<int> path;
        void backtracking(vector<int>& candidates, int target, int sum, int startIndex) {
            if (sum == target) {
                result.push_back(path);
                return;
            }

            // 如果 sum + candidates[i] > target 就终止遍历
            // 请好好体会下面for循环的判断语句
            // 这是第一次for循环的判断语句中出现非i的判断条件
            // 而且这个是在for循环对sum重新赋值之后，在下个递归的for循环里再做判断
            for (int i = startIndex; i < candidates.size() && sum + candidates[i] <= target; i++) {
                sum += candidates[i];
                path.push_back(candidates[i]);
                backtracking(candidates, target, sum, i);
                sum -= candidates[i];
                path.pop_back();

            }
        }
    public:
        vector<vector<int>> combinationSum(vector<int>& candidates, int target) {
            result.clear();
            path.clear();
            sort(candidates.begin(), candidates.end()); // 需要排序
            backtracking(candidates, target, 0, 0);
            return result;
        }
    };

    return 0;

}
