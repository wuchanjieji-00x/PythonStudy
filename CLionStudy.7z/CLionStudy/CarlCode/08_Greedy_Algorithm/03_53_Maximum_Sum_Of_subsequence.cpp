// #include "iostream"

#include <cstdint>
#include <vector>
using namespace std;

// 53. 最大子序和
// 最大和的连续子数组

//


int main() {


    // 解法1：暴力解法
    // 两层for循环：第一层 for 就是设置起始位置，第二层 for 循环遍历数组寻找最大值
    // 时间复杂度：O(n^2)
    // 空间复杂度：O(1)
    class Solution {
    public:
        int maxSubArray(vector<int>& nums) {
            int result = INT32_MIN;
            int count = 0;
            for (int i = 0; i < nums.size(); i++) { // 设置起始位置
                count = 0;
                for (int j = i; j < nums.size(); j++) { // 每次从起始位置i开始遍历寻找最大值
                    count += nums[j];
                    result = count > result ? count : result;
                }
            }
            return result;
        }
    };



    // 解法2：贪心
    // 时间复杂度：O(n)
    // 空间复杂度：O(1)
    // 当然题目没有说如果数组为空，应该返回什么，所以数组为空的话返回啥都可以了

    // 局部最优：当前“连续和”为负数的时候立刻放弃，从下一个元素重新计算“连续和”，因为负数加上下一个元素 “连续和”只会越来越小
    // 全局最优：选取最大“连续和”
    // 局部最优的情况下，并记录最大的“连续和”，可以推出全局最优。
    class Solution {
    public:
        int maxSubArray(vector<int>& nums) {
            int result = INT32_MIN;
            int count = 0;
            for (int i = 0; i < nums.size(); i++) {
                count += nums[i];
                // 相当于元素逐个加进来，进来一个元素计算一次count,也就是子序列的和
                // 同时计算出新的子序列的和之后，要和之前的count进行比较，我们只留最大的
                if (count > result) { // 取区间累计的最大值（相当于不断确定最大子序终止位置）
                    result = count;
                }
                if (count <= 0) count = 0; // 相当于重置最大子序起始位置，因为遇到负数一定是拉低总和
            }
            return result;
        }
    };



    // 解法3：动态规划
    // 时间复杂度：O(n)
    // 空间复杂度：O(n)
    class Solution {
    public:
        int maxSubArray(vector<int>& nums) {
            if (nums.size() == 0) return 0;
            vector<int> dp(nums.size(), 0); // dp[i]表示包括i之前的最大连续子序列和
            dp[0] = nums[0];
            int result = dp[0];
            for (int i = 1; i < nums.size(); i++) {
                dp[i] = max(dp[i - 1] + nums[i], nums[i]); // 状态转移公式
                if (dp[i] > result) result = dp[i]; // result 保存dp[i]的最大值
            }
            return result;
        }
    };





    return 0;

}
