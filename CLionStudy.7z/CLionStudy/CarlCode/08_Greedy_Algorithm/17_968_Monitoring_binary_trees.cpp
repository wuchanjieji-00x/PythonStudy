

using namespace std;


// 968.监控二叉树

// hard!!! 没看懂

// 二叉树的定义
struct TreeNode {
    int val;
    TreeNode *left;
    TreeNode *right;
    // 构造函数，用于初始化节点
    // 三种方式用于构建一个节点
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    // 在创建一个node的时候，需要传入一个int类型的值，作为节点的值, 初始化节点的左右子树为nullptr
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};


int main() {


    // 版本一
    class Solution {
    private:
        int result;
        int traversal(TreeNode* cur) {

            // 空节点，该节点有覆盖
            if (cur == nullptr) return 2;

            int left = traversal(cur->left);    // 左
            int right = traversal(cur->right);  // 右

            // 情况1
            // 左右节点都有覆盖
            if (left == 2 && right == 2) return 0;

            // 情况2
            // left == 0 && right == 0 左右节点无覆盖
            // left == 1 && right == 0 左节点有摄像头，右节点无覆盖
            // left == 0 && right == 1 左节点有无覆盖，右节点摄像头
            // left == 0 && right == 2 左节点无覆盖，右节点覆盖
            // left == 2 && right == 0 左节点覆盖，右节点无覆盖
            if (left == 0 || right == 0) {
                result++;
                return 1;
            }

            // 情况3
            // left == 1 && right == 2 左节点有摄像头，右节点有覆盖
            // left == 2 && right == 1 左节点有覆盖，右节点有摄像头
            // left == 1 && right == 1 左右节点都有摄像头
            // 其他情况前段代码均已覆盖
            if (left == 1 || right == 1) return 2;

            // 以上代码我没有使用else，主要是为了把各个分支条件展现出来，这样代码有助于读者理解
            // 这个 return -1 逻辑不会走到这里。
            return -1;
        }

    public:
        int minCameraCover(TreeNode* root) {
            result = 0;
            // 情况4
            if (traversal(root) == 0) { // root 无覆盖
                result++;
            }
            return result;
        }
    };



    // // 版本二,版本1的精简版
    class Solution {
    private:
        int result;

        int traversal(TreeNode *cur) {
            if (cur == nullptr) return 2;
            int left = traversal(cur->left); // 左
            int right = traversal(cur->right); // 右
            if (left == 2 && right == 2) return 0;
            else if (left == 0 || right == 0) {
                result++;
                return 1;
            } else return 2;
        }

    public:
        int minCameraCover(TreeNode *root) {
            result = 0;
            if (traversal(root) == 0) {
                // root 无覆盖
                result++;
            }
            return result;
        }
    };


    return 0;
}
