
#include <string>
using namespace std;


// 738.单调递增的数字



int main() {


    // 解法1：暴力解法，超时了
    // 时间复杂度：O(n × m) m为n的数字长度
    // 空间复杂度：O(1)
    class Solution {
    private:
        // 判断一个数字的各位上是否是递增
        bool checkNum(int num) {
            int max = 10;
            while (num) {
                int t = num % 10;  // 依次拿到数字的个位，十位，百位...
                if (max >= t) max = t;
                else return false;
                num = num / 10;
            }
            return true;
        }
    public:
        int monotoneIncreasingDigits(int N) {
            for (int i = N; i > 0; i--) { // 从大到小遍历
                if (checkNum(i)) return i;
            }
            return 0;
        }
    };




    // 解法2：贪心
    // 时间复杂度：O(n)，n 为数字长度
    // 空间复杂度：O(n)，需要一个字符串，转化为字符串操作更方便
    class Solution {
    public:
        int monotoneIncreasingDigits(int N) {
            string strNum = to_string(N);
            // flag用来标记赋值9从哪里开始
            // 设置为这个默认值，为了防止第二个for循环在flag没有被赋值的情况下执行
            // 也就是说，当数字本身就是递增的数字，那我们直接把这个数字输出就可以了
            // 初始化为nums,size，这样最下面的for循环就不会执行了
            int flag = strNum.size();
            // 为什么从后往前遍历？因为这样才能利用之前遍历的结果，因为要求的是递增的数字
            for (int i = strNum.size() - 1; i > 0; i--) {
                if (strNum[i - 1] > strNum[i] ) {
                    // 最后代码实现的时候，也需要一些技巧，例如用一个flag来标记从哪里开始赋值9
                    flag = i; // 不能前一位减减后，下一位就赋9，比如N=1000，如果这样来，最后的数字是900，而不是999了
                    strNum[i - 1]--;
                }
            }
            for (int i = flag; i < strNum.size(); i++) {
                strNum[i] = '9';
            }
            return stoi(strNum); // 将字符串转换为int
        }
    };






    return 0;

}