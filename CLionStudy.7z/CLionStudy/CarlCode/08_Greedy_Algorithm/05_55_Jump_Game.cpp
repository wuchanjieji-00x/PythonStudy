// #include "iostream"

#include <vector>
using namespace std;

// 55. 跳跃游戏




int main() {

    // 贪心
    // 这个问题就转化为跳跃覆盖范围究竟可不可以覆盖到终点！
    // 贪心算法局部最优解：每次取最大跳跃步数（取最大覆盖范围），
    // 整体最优解：最后得到整体最大覆盖范围，看是否能到终点。
    // 时间复杂度: O(n)
    // 空间复杂度: O(1)
    class Solution {
    public:
        bool canJump(vector<int>& nums) {
            int cover = 0;
            if (nums.size() == 1) return true;  // 只有一个元素，就是能达到
            for (int i = 0; i <= cover; i++) { // 注意这里是小于等于cover
                cover = max(i + nums[i], cover);
                if (cover >= nums.size() - 1) return true; // 说明可以覆盖到终点了
            }
            return false; // 在以上的for循环尝试中，没有找到覆盖到终点的情况，说明不能覆盖到终点
        }
    };








    return 0;

}
