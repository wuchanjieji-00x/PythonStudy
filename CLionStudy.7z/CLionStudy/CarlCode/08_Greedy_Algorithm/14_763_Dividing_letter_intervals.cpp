
#include <algorithm>
#include <vector>
#include <string>
using namespace std;

// 763.划分字母区间




int main() {

    // 版本1
    // 时间复杂度：O(n)
    // 空间复杂度：O(1)，使用的hash数组是固定大小
    class Solution {
    public:
        vector<int> partitionLabels(string S) {
            int hash[27] = {0}; // i为字符，hash[i]为字符出现的最后位置
            for (int i = 0; i < S.size(); i++) { // 统计每一个字符最后出现的位置
                // 遍历一遍数组后，hash表下标（字母）对应的值就是该字母最后出现的位置（在字符串s中的下标），也就是最远距离
                // 请体会这种hash思想
                hash[S[i] - 'a'] = i;
            }
            vector<int> result;
            int left = 0;
            int right = 0;
            for (int i = 0; i < S.size(); i++) {
                // max的意思是，当我们找到第一个字母的最远距离后，接着往后遍历的时候，要逐个比较最远距离内的元素对应的最远距离是否超出
                // 根据题意，一个合法的区间是其中的元素只在这个区间出现
                right = max(right, hash[S[i] - 'a']); // 找到字符出现的最远边界

                // 当遍历到达这个最远右边界后，输出这个区间的长度
                if (i == right) {
                    result.push_back(right - left + 1); // 注意这里输出的是区间的长度
                    left = i + 1; // 输出之后，更新下下一个区间的起始位置
                }
            }
            return result;
        }
    };



    // 版本2：
    // 这里提供一种与452.用最少数量的箭引爆气球 (opens new window)、435.无重叠区间 (opens new window)相同的思路。
    // 统计字符串中所有字符的起始和结束位置，记录这些区间(实际上也就是435.无重叠区间(opens new window)题目里的输入)
    // 将区间按左边界从小到大排序，找到边界将区间划分成组，互不重叠。 找到的边界就是答案


    class Solution {
    public:
        static bool cmp(vector<int> &a, vector<int> &b) {
            return a[0] < b[0];
        }
        // 记录每个字母出现的区间
        vector<vector<int>> countLabels(string s) {
            vector<vector<int>> hash(26, vector<int>(2, INT_MIN));
            vector<vector<int>> hash_filter;
            for (int i = 0; i < s.size(); ++i) {
                if (hash[s[i] - 'a'][0] == INT_MIN) {
                    hash[s[i] - 'a'][0] = i;
                }
                hash[s[i] - 'a'][1] = i;
            }
            // 去除字符串中未出现的字母所占用区间
            for (int i = 0; i < hash.size(); ++i) {
                if (hash[i][0] != INT_MIN) {
                    hash_filter.push_back(hash[i]);
                }
            }
            return hash_filter;
        }
        vector<int> partitionLabels(string s) {
            vector<int> res;
            // 这一步得到的 hash 即为无重叠区间题意中的输入样例格式：区间列表
            // 只不过现在我们要求的是区间分割点
            vector<vector<int>> hash = countLabels(s);
            // 按照左边界从小到大排序
            sort(hash.begin(), hash.end(), cmp);
            // 记录最大右边界
            int rightBoard = hash[0][1];
            int leftBoard = 0;
            for (int i = 1; i < hash.size(); ++i) {
                // 由于字符串一定能分割，因此,
                // 一旦下一区间左边界大于当前右边界，即可认为出现分割点
                if (hash[i][0] > rightBoard) {
                    res.push_back(rightBoard - leftBoard + 1);
                    leftBoard = hash[i][0];
                }
                rightBoard = max(rightBoard, hash[i][1]);
            }
            // 最右端
            res.push_back(rightBoard - leftBoard + 1);
            return res;
        }
    };






    return 0;

}