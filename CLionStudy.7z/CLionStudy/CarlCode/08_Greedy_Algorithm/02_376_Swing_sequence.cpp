// #include "iostream"
#include <string.h>
#include <vector>
using namespace std;

// 376. 摆动序列




int main() {


    // 解法1：贪心
    class Solution {
    public:
        int wiggleMaxLength(vector<int>& nums) {
            if (nums.size() <= 1) return nums.size(); // 一个元素的数组，摆动是1
            // if (nums.size() == 2 && nums[0] != nums[1]) return 2; // 这里我们可以写死，就是如果只有两个元素，且元素不同，那么结果为 2
            // 不写死的话，我们默认数组的首元素前面还有一个数值相同的元素，那么prediff = 0，那么也包括在下面的判断条件里了
            int curDiff = 0; // 当前一对差值
            int preDiff = 0; // 前一对差值
            int result = 1;  // 记录峰值个数，序列默认序列最右边有一个峰值
            for (int i = 0; i < nums.size() - 1; i++) {
                curDiff = nums[i + 1] - nums[i];
                // 出现峰值
                if ((preDiff <= 0 && curDiff > 0) || (preDiff >= 0 && curDiff < 0)) {
                    result++;
                }
                preDiff = curDiff;
            }
            return result;
        }
    };

    // 版本1忽略了情况三：单调坡度有平坡
    // 版本1中我们考虑了中间有平坡的情况，但是没有考虑先上升，再平坡，再上升的情况
    // 我们在版本1中把平坡上所有的元素只看做了一个摆动，可以解决中间有平坡的情况
    // 对于情况三，我们希望的摆动是什么？说白了，就是元素的差值换符号了，如果想象成坡的话，那就是坡换向了
    // 所以当curDiff的符号和preDiff的符号相反时，就认为出现了摆动，
    // 那么一旦有了preDiff,我们先让preDiff原地等着，直到遇到下一个curDiff，然后curDiff和preDiff进行比较，如果符号相反，那么就认为出现了摆动


    // 版本2
    class Solution {
    public:
        int wiggleMaxLength(vector<int>& nums) {
            if (nums.size() <= 1) return nums.size(); // 一个元素的数组，摆动是1
            // if (nums.size() == 2 && nums[0] != nums[1]) return 2; // 这里我们可以写死，就是如果只有两个元素，且元素不同，那么结果为 2
            // 不写死的话，我们默认数组的首元素前面还有一个数值相同的元素，那么prediff = 0，那么也包括在下面的判断条件里了
            int curDiff = 0; // 当前一对差值
            int preDiff = 0; // 前一对差值
            int result = 1;  // 记录峰值个数，序列默认序列最右边有一个峰值
            for (int i = 0; i < nums.size() - 1; i++) {
                curDiff = nums[i + 1] - nums[i];
                // 出现峰值
                if ((preDiff <= 0 && curDiff > 0) || (preDiff >= 0 && curDiff < 0)) {
                    result++;
                    preDiff = curDiff; // 改动点
                    // 意为当我们确认出现了一个摆动，也就是坡换向了，才让preDiff更新为curDiff
                }

            }
            return result;
        }
    };


    // 解法2：动态规划
    // 时间复杂度：O(n^2)
    // 空间复杂度：O(n)
    class Solution {
    public:
        int dp[1005][2];
        int wiggleMaxLength(vector<int>& nums) {
            memset(dp, 0, sizeof dp);
            dp[0][0] = dp[0][1] = 1;
            for (int i = 1; i < nums.size(); ++i) {
                dp[i][0] = dp[i][1] = 1;
                for (int j = 0; j < i; ++j) {
                    if (nums[j] > nums[i]) dp[i][1] = max(dp[i][1], dp[j][0] + 1);
                }
                for (int j = 0; j < i; ++j) {
                    if (nums[j] < nums[i]) dp[i][0] = max(dp[i][0], dp[j][1] + 1);
                }
            }
            return max(dp[nums.size() - 1][0], dp[nums.size() - 1][1]);
        }
    };






    return 0;

}
