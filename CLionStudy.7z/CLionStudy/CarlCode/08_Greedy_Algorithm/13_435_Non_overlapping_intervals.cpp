
#include <algorithm>
#include <vector>
using namespace std;

// 435. 无重叠区间




int main() {

    // 版本1：先按照左边界排序
    class Solution {
    public:
        static bool cmp (const vector<int>& a, const vector<int>& b) {
            return a[0] < b[0]; // 改为左边界排序
        }
        int eraseOverlapIntervals(vector<vector<int>>& intervals) {
            // 下面的遍历是从i=1开始的，所以这里把数组元素数为0的情况单独拿出来
            if (intervals.size() == 0) return 0;
            sort(intervals.begin(), intervals.end(), cmp);

            // 这里是按照题意，上面我们把数组元素数目为0的情况单独拿出来，为0就是0个重叠区间
            // 那么数组不为0呢？那就至少需要删除0个重叠区间，最极端的情况，数组里的区间本身个个都不重叠
            // 那么需要删除的重叠区间数就是0，所以这里初始化为0
            int count = 0; // 注意这里从0开始，因为是记录重叠区间

            // 这里end是按照左边界排序后的interval数组的第一个元素（向量）中的第二个元素
            // 也就是end初始化为按照左边界排序后，第一个区间的右边界
            int end = intervals[0][1]; // 记录区间分割点
             // 那为什么i要从1开始遍历呢？因为我们要判断当前区间的左边界和上一个区间的右边界是否重叠
            // 所以至少需要两个i，或者说至少需要两个区间
            // 也正是因为这样，我们才会把i=0的情况单独拿出来
            for (int i = 1; i < intervals.size(); i++) {
                if (intervals[i][0] >= end)  end = intervals[i][1]; // 无重叠的情况，更新end
                else { // 重叠情况，注意这里是<0，因为就算i的左边界和i-1的右边界相等，二者也是不重叠的区间
                    end = min(end, intervals[i][1]);
                    // 这里为什么取二者中较小的右边界作为i新的右边界呢？
                    // 因为这里是i和i-1是重叠区间了，那么我们就只保留二者之间的较小右边界，相当于把二者右侧不重叠的部分删除了
                    // 只保留右侧重叠的部分，左边界不用管，这样作为一个新的区间再往下遍历
                    // 如果下一个i的左边界在这个重叠范围内，那这三个区间都是重叠区间，那我们至少要删除两个
                    // 这样就回到了上面if的判断逻辑了：判断两个单独的区间是否有重叠部分
                    count++;
                    // 这里如果两个相邻的区间如果有重叠部分，那我们要删除二者中的一个
                }
            }
            return count;
        }
    };


    // 版本1精简版：用 intervals[i][1] 替代 end变量，只判断 重叠情况就好
    class Solution {
    public:
        static bool cmp (const vector<int>& a, const vector<int>& b) {
            return a[0] < b[0]; // 改为左边界排序
        }
        int eraseOverlapIntervals(vector<vector<int>>& intervals) {
            if (intervals.size() == 0) return 0;
            sort(intervals.begin(), intervals.end(), cmp);
            int count = 0; // 注意这里从0开始，因为是记录重叠区间
            for (int i = 1; i < intervals.size(); i++) {
                if (intervals[i][0] < intervals[i - 1][1]) { //重叠情况
                    intervals[i][1] = min(intervals[i - 1][1], intervals[i][1]);
                    count++;
                }
            }
            return count;
        }
    };


    // 版本1的另一个版本
    // 本题其实和452.用最少数量的箭引爆气球 (opens new window)非常像，弓箭的数量就相当于是非交叉区间的数量，
    // 只要把弓箭那道题目代码里射爆气球的判断条件加个等号（认为[0，1][1，2]不是相邻区间），然后用总区间数减去弓箭数量 就是要移除的区间数量了。
    // 改变点1：区间=要变化
    // 改变点2：弓箭数是非交叉区间的数量，那么用总区间数-非交叉区间数=要移除的交叉区间数量
    class Solution {
    public:
        // 按照区间右边界排序
        static bool cmp (const vector<int>& a, const vector<int>& b) {
            return a[1] < b[1]; // 右边界排序
        }
        int eraseOverlapIntervals(vector<vector<int>>& intervals) {
            if (intervals.size() == 0) return 0;
            sort(intervals.begin(), intervals.end(), cmp);

            int result = 1; // points 不为空至少需要一支箭
            for (int i = 1; i < intervals.size(); i++) {
                if (intervals[i][0] >= intervals[i - 1][1]) {
                    result++; // 需要一支箭
                }
                else {  // 气球i和气球i-1挨着
                    intervals[i][1] = min(intervals[i - 1][1], intervals[i][1]); // 更新重叠气球最小右边界
                }
            }
            return intervals.size() - result;
        }
    };

    // 上个版本用右边界排序
    class Solution {
    public:
        // 按照区间左边界排序
        static bool cmp (const vector<int>& a, const vector<int>& b) {
            return a[0] < b[0]; // 左边界排序
        }
        int eraseOverlapIntervals(vector<vector<int>>& intervals) {
            if (intervals.size() == 0) return 0;
            sort(intervals.begin(), intervals.end(), cmp);

            int result = 1; // points 不为空至少需要一支箭
            for (int i = 1; i < intervals.size(); i++) {
                if (intervals[i][0] >= intervals[i - 1][1]) {
                    result++; // 需要一支箭
                }
                else {  // 气球i和气球i-1挨着
                    intervals[i][1] = min(intervals[i - 1][1], intervals[i][1]); // 更新重叠气球最小右边界
                }
            }
            return intervals.size() - result;
        }
    };


    // 版本2：按照右边界排序
    // 时间复杂度：O(nlog n) ，有一个快排
    // 空间复杂度：O(n)，有一个快排，最差情况(倒序)时，需要n次递归调用。因此确实需要O(n)的栈空间
    class Solution {
    public:
        // 按照区间右边界排序
        static bool cmp (const vector<int>& a, const vector<int>& b) {
            return a[1] < b[1];
        }
        int eraseOverlapIntervals(vector<vector<int>>& intervals) {
            if (intervals.size() == 0) return 0;
            sort(intervals.begin(), intervals.end(), cmp);
            // 因为最后输出的是区间总数-非交叉区间数= 需要删除的交叉区间数
            // 而这里count意为记录非交叉区间数,所以至少为1.
            // 极端情况，数组只有一个区间，那么交叉区间=1-1
            // 或者数组中所有区间都交叉，那么用区间总数-所有非交叉的区间（size-1）=1
            int count = 1; // 记录非交叉区间的个数
            int end = intervals[0][1]; // 记录区间分割点
            for (int i = 1; i < intervals.size(); i++) {
                if (end <= intervals[i][0]) {
                    end = intervals[i][1];
                    count++; // 只有二者不交叉，才记录。那么交叉的情况我们只拿第一个区间，其余区间不计数就好了
                }
            }
            return intervals.size() - count;
        }
    };







    return 0;

}
