// #include "iostream"

#include <vector>
using namespace std;

// 122.买卖股票的最佳时机 II




int main() {


    // 贪心
    // 只收集正利润就是贪心所贪的地方！
    // 局部最优：收集每天的正利润，全局最优：求得最大利润。
    // 思路：每天只能做买或卖的一个操作，上维度，由每天的股票价格，推出每两天之间的利润，我们只贪正利润，避开利润为负的两天的区间
    // 时间复杂度：O(n)
    // 空间复杂度：O(1)
    class Solution {
    public:
        int maxProfit(vector<int>& prices) {
            int result = 0;
            for (int i = 1; i < prices.size(); i++) {
                result += max(prices[i] - prices[i - 1], 0);
            }
            return result;
        }
    };


    // 动态规划
    // 时间复杂度：$O(n)$
    // 空间复杂度：$O(n)$
    class Solution {
    public:
        int maxProfit(vector<int>& prices) {
            // dp[i][1]第i天持有的利润
            // dp[i][0]第i天持有股票后的利润
            int n = prices.size();
            vector<vector<int>> dp(n, vector<int>(2, 0));
            dp[0][0] -= prices[0]; // 持股票
            for (int i = 1; i < n; i++) {
                // 第i天持股票利润 = max(第i-1天持股票利润, 第i-1天持利润-买第i天的股票)
                dp[i][0] = max(dp[i - 1][0], dp[i - 1][1] - prices[i]);
                // 第i天持股票利润 = max(第i-1天持有的利润，第i-1天持有股票的最多现金+第i天卖出股票)
                dp[i][1] = max(dp[i - 1][1], dp[i - 1][0] + prices[i]);
            }
            return max(dp[n - 1][0], dp[n - 1][1]);
        }
    };









    return 0;

}
