
#include <vector>
using namespace std;


// 860.柠檬水找零

// 贪心：
// 局部最优：遇到账单20，优先消耗美元10，完成本次找零。全局最优：完成全部账单的找零

int main() {


    // 贪心
    // 时间复杂度: O(n)
    // 空间复杂度: O(1)
    class Solution {
    public:
        bool lemonadeChange(vector<int>& bills) {

            int five = 0;
            int ten = 0;
            int twenty = 0;

            for (int bill : bills) {

                // 情况一：客户给5元，直接收下
                if (bill == 5) five++;
                // 情况二：客户给10元，收10找5
                if (bill == 10) {
                    if (five <= 0) return false;
                    ten++;
                    five--;
                }
                // 情况三：客户给20元，收20优先找10+5，如果不行，则找5+5+5
                if (bill == 20) {
                    // 优先消耗10美元，因为5美元的找零用处更大，能多留着就多留着.贪心
                    if (ten > 0 && five > 0) {
                        ten--;
                        five--;
                        twenty++; // 其实这行代码可以删了，因为记录20已经没有意义了，不会用20来找零
                    } else if (five >= 3) {
                        five -= 3;
                        twenty++; // 同理，这行代码也可以删了
                    } else {
                        return false;
                    }
                }

            }
            return true;
        }
    };


    return 0;

}
