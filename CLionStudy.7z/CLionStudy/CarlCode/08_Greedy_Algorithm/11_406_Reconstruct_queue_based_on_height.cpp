
#include <algorithm>
#include <list>
#include <vector>
using namespace std;

// 406.根据身高重建队列
// 本题有两个维度，h和k，看到这种题目一定要想如何确定一个维度，然后再按照另一个维度重新排列。
// 遇到两个维度权衡的时候，一定要先确定一个维度，再确定另一个维度。如果两个维度一起考虑一定会顾此失彼。



int main() {

    // 版本一
    // 时间复杂度：O(nlog n + n^2)
    // 空间复杂度：O(n)
    // 局部最优：优先按身高高的people的k来插入。插入操作过后的people满足队列属性
    // 全局最优：最后都做完插入操作，整个队列满足题目队列属性
    class Solution {
    public:
        static bool cmp(const vector<int>& a, const vector<int>& b) {
            // 按照身高排序之后，优先按身高高的people的k来插入，后序插入节点也不会影响前面已经插入的节点，最终按照k的规则完成了队列。
            // 如果身高相等，那就按照k来排序，k小的放前面
            if (a[0] == b[0]) return a[1] < b[1];
            return a[0] > b[0];
        }
        vector<vector<int>> reconstructQueue(vector<vector<int>>& people) {
            sort (people.begin(), people.end(), cmp);
            vector<vector<int>> que;
            for (int i = 0; i < people.size(); i++) {
                int position = people[i][1];
                que.insert(que.begin() + position, people[i]);
                // 第一个参数：插入的位置，注意这种写法
                // 第二个参数：插入的元素
            }
            return que;
        }
    };


    // 版本二
    // 时间复杂度：O(nlog n + n^2)
    // 空间复杂度：O(n)
    // 使用C++中的list（底层链表实现）比vector（数组）效率高得多。
    class Solution {
    public:
        // 身高从大到小排（身高相同k小的站前面）
        static bool cmp(const vector<int> &a, const vector<int> &b) {
            if (a[0] == b[0]) return a[1] < b[1];
            return a[0] > b[0];
        }

        vector<vector<int> > reconstructQueue(vector<vector<int> > &people) {
            sort(people.begin(), people.end(), cmp);
            list<vector<int> > que; // list底层是链表实现，插入效率比vector高的多
            for (int i = 0; i < people.size(); i++) {
                int position = people[i][1]; // 插入到下标为position的位置
                std::list<vector<int> >::iterator it = que.begin(); // 注意这种链表的操作方式
                while (position--) {
                    // 寻找在插入位置
                    it++;
                }
                que.insert(it, people[i]);
            }
            return vector<vector<int> >(que.begin(), que.end());
        }
    };


    return 0;
}
