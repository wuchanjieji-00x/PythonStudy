

#include <vector>
using namespace std;

// 135. 分发糖果

// 先确定右边评分大于左边的情况（也就是从前向后遍历）
// 此时局部最优：只要右边评分比左边大，右边的孩子就多一个糖果，全局最优：相邻的孩子中，评分高的右孩子获得比左边孩子更多的糖果
// 再确定左孩子大于右孩子的情况（从后向前遍历）
// 局部最优：取candyVec[i + 1] + 1 和 candyVec[i] 最大的糖果数量，保证第i个小孩的糖果数量既大于左边的也大于右边的。
// 全局最优：相邻的孩子中，评分高的孩子获得更多的糖果。


int main() {


    // 贪心：用最少的糖果
    // 时间复杂度: O(n)
    // 空间复杂度: O(n)
    class Solution {
    public:
        int candy(vector<int>& ratings) {
            vector<int> candyVec(ratings.size(), 1);

            // 从前向后:右孩子得分比左孩子得分高
            for (int i = 1; i < ratings.size(); i++) {
                if (ratings[i] > ratings[i - 1]) {
                    candyVec[i] = candyVec[i - 1] + 1;
                }
            }
            // 从后向前：左孩子比右孩子得分高
            for (int i = ratings.size() - 2; i >= 0; i--) {
                if (ratings[i] > ratings[i + 1]) {
                    candyVec[i] = max(candyVec[i], candyVec[i + 1] + 1);
                    // 这里的max,是将从前向后的情况的结果也考虑进来，取较大值。这样两边的孩子的情况都考虑了进来
                }
            }

            // 统计结果
            int result = 0;
            for (int i = 0; i < ratings.size(); i++) {
                result += candyVec[i];
            }
            return result;
        }
    };








    return 0;

}