#include <algorithm>
#include <vector>
using namespace std;


// 56. 合并区间



int main() {

    // 贪心
    // 时间复杂度: O(nlogn)
    // 空间复杂度: O(logn)，排序需要的空间开销
    class Solution {
    public:
        vector<vector<int>> merge(vector<vector<int>>& intervals) {
            vector<vector<int>> result;
            // 下面的遍历是从i=1开始的，所以这里把数组元素数为0的情况单独拿出来
            if (intervals.size() == 0) return result; // 区间集合为空直接返回
            // 排序的参数使用了lambda表达式
            sort(intervals.begin(), intervals.end(), [](const vector<int>& a, const vector<int>& b){return a[0] < b[0];});

            // 第一个区间就可以放进结果集里，后面如果重叠，在result上直接合并
            // 下面的遍历是从1开始的，我们已经把数组元素数为0的情况单独拿出来了
            // 这里是把数组元素为1的情况单独拿出来：元素数为1，那么直接加入到result中
            // 同时，这个数组也可以作为我们开始遍历处理数组元素的起点，，请好好体会这个一箭双雕的处理
            result.push_back(intervals[0]);

            for (int i = 1; i < intervals.size(); i++) {
                // 如果i-1的右边界大于等于i的左边界，那么二者是重叠的
                if (result.back()[1] >= intervals[i][0]) { // 发现重叠区间
                    // 合并区间，只更新右边界就好，因为result.back()的左边界一定是最小值，因为我们按照左边界排序的
                    result.back()[1] = max(result.back()[1], intervals[i][1]);
                    // 这里以result数组里的结果为基准，遇到交叉区间就吸收进来（更新右边界，然后舍弃i这个交叉区间）
                } else {
                    result.push_back(intervals[i]); // 区间不重叠
                }
            }
            return result;
        }
    };








    return 0;

}
