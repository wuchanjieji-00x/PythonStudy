
#include <algorithm>
#include <vector>
using namespace std;

// 452. 用最少数量的箭引爆气球




int main() {

    // 版本1：用右边界排序
    // 贪心
    // 局部最优：当气球出现重叠，一起射，所用弓箭最少。全局最优：把所有气球射爆所用弓箭最少。
    // 时间复杂度：O(nlog n)，因为有一个快排
    // 空间复杂度：O(1)，有一个快排，最差情况(倒序)时，需要n次递归调用。因此确实需要O(n)的栈空间
    class Solution {
    private:
        static bool cmp(const vector<int>& a, const vector<int>& b) {
            return a[0] < b[0];
        }
    public:
        int findMinArrowShots(vector<vector<int>>& points) {
            // 下面的遍历是从i=1开始的，所以这里把气球数为0的情况单独拿出来
            if (points.size() == 0) return 0;
            sort(points.begin(), points.end(), cmp);

            // 这里是按照题意，上面我们把数组为0的情况单独拿出来，为0就是0支箭
            // 那么数组不为0呢？那就至少需要一支箭，所以这里初始化为1
            int result = 1; // points 不为空至少需要一支箭
            // 那为什么i要从1开始遍历呢？因为我们要判断当前气球的左边界和上一个气球的右边界是否重叠
            // 所以至少需要两个i，或者说至少需要两个气球
            // 也正是因为这样，我们才会把i=0的情况单独拿出来
            for (int i = 1; i < points.size(); i++) {
                if (points[i][0] > points[i - 1][1]) {  // 气球i和气球i-1不挨着，注意这里不是>=
                    result++; // 需要一支箭
                }
                else {  // 气球i和气球i-1挨着
                    points[i][1] = min(points[i - 1][1], points[i][1]); // 更新重叠气球最小右边界
                    // 相当于遇到区间重叠的气球后，我们就更新i的右边界。那怎么更新呢？
                    // 我们应该取i和i-1的右边界中的较小值，为什么？
                    // 因为这样我们相当于把i和i-1这两个气球合并了，左边界不用管，我们只拿二者的最小右边界去和下一个i的左边界进行对比
                    // 如果下一个i的左边界在这个min右边界的范围内，那说明这三个气球都重叠，可以用一支箭射，就不用增加箭数了
                    // 如果下一个i的左边界不在这个min右边界的范围内，那就回到上面if的逻辑，需要增加一支箭
                    // 其实这样就把重叠的气球看成一个更新了右边界的新气球，再去向下遍历，又是两个气球比较边界是否有重叠的逻辑了

                }
            }
            return result;
        }
    };


    // 版本2：用左边界排序
    class Solution {
    public:
        // 按照区间左边界排序
        static bool cmp (const vector<int>& a, const vector<int>& b) {
            return a[0] < b[0]; // 左边界排序
        }
        int eraseOverlapIntervals(vector<vector<int>>& intervals) {
            if (intervals.size() == 0) return 0;
            sort(intervals.begin(), intervals.end(), cmp);

            int result = 1; // points 不为空至少需要一支箭
            for (int i = 1; i < intervals.size(); i++) {
                if (intervals[i][0] > intervals[i - 1][1]) {
                    result++; // 需要一支箭
                }
                else {  // 气球i和气球i-1挨着
                    intervals[i][1] = min(intervals[i - 1][1], intervals[i][1]); // 更新重叠气球最小右边界
                }
            }
            return result;
        }
    };







    return 0;

}
