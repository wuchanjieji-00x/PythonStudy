
#include <climits>
#include <vector>
using namespace std;

// 134. 加油站




int main() {

    // 解法1：暴力解法
    // for循环适合模拟从头到尾的遍历，而while循环适合模拟环形遍历
    // 时间复杂度：O(n^2)
    // 空间复杂度：O(1)
    class Solution {
    public:
        int canCompleteCircuit(vector<int>& gas, vector<int>& cost) {
            for (int i = 0; i < cost.size(); i++) {
                int rest = gas[i] - cost[i]; // 记录剩余油量
                int index = (i + 1) % cost.size();
                while (rest > 0 && index != i) { // 模拟以i为起点行驶一圈（如果有rest==0，那么答案就不唯一了）
                    rest += gas[index] - cost[index];
                    index = (index + 1) % cost.size();
                }
                // 如果以i为起点跑一圈，剩余油量>=0，返回该起始位置
                if (rest >= 0 && index == i) return i;
            }
            return -1;
        }
    };


    // 解法2：贪心
    // 版本1： 没看懂
    // 时间复杂度：O(n)
    // 空间复杂度：O(1)
    class Solution {
    public:
        int canCompleteCircuit(vector<int>& gas, vector<int>& cost) {
            int curSum = 0;
            int min = INT_MAX; // 从起点出发，油箱里的油量最小值
            for (int i = 0; i < gas.size(); i++) {
                int rest = gas[i] - cost[i];
                curSum += rest;
                if (curSum < min) {
                    min = curSum;
                }
            }
            if (curSum < 0) return -1;  // 情况1
            if (min >= 0) return 0;     // 情况2
            // 情况3
            for (int i = gas.size() - 1; i >= 0; i--) {
                int rest = gas[i] - cost[i];
                min += rest;
                if (min >= 0) {
                    return i;
                }
            }
            return -1;
        }
    };




    // 版本2：这才是正儿八经的贪心
    // 局部最优：当前累加rest[i]的和curSum一旦小于0，起始位置至少要是i+1，因为从i之前开始一定不行。全局最优：找到可以跑一圈的起始位置。
    // 时间复杂度：O(n)
    // 空间复杂度：O(1)
    class Solution {
    public:
        int canCompleteCircuit(vector<int>& gas, vector<int>& cost) {
            int curSum = 0;
            int totalSum = 0;
            int start = 0;
            for (int i = 0; i < gas.size(); i++) {
                // 开辟一个数组，用来记录每个位置的剩余油量，或者叫做代价油量
                curSum += gas[i] - cost[i];
                totalSum += gas[i] - cost[i];
                if (curSum < 0) {   // 当前累加rest[i]和 curSum一旦小于0
                    start = i + 1;  // 起始位置更新为i+1
                    curSum = 0;     // curSum从0开始
                }
            }
            if (totalSum < 0) return -1; // 说明怎么走都不可能跑一圈了
            return start;
        }
    };







    return 0;

}
