// #include "iostream"

#include <algorithm>
#include <vector>
using namespace std;


// 455.分发饼干



int main() {

    // 这里的局部最优就是大饼干喂给胃口大的，充分利用饼干尺寸喂饱一个，全局最优就是喂饱尽可能多的小孩。

    // 版本1
    // 大饼干先喂饱大胃口的孩子
    // 时间复杂度：O(nlogn)     快排O(nlog n)，遍历O(n)，加一起就是还是O(nlogn)
    // 空间复杂度：O(1)
    class Solution {
    public:
        int findContentChildren(vector<int>& g, vector<int>& s) {
            sort(g.begin(), g.end());
            sort(s.begin(), s.end());

            // 从代码中可以看出我用了一个 index 来控制饼干数组的遍历，
            // 遍历饼干并没有再起一个 for 循环，而是采用自减的方式，这也是常用的技巧
            int index = s.size() - 1; // 初始化为最大尺寸的饼干

            int result = 0;
            // 这里我们的策略是拿较大的饼干尽量去喂饱胃口较大的孩子
            // 所以在去遍历孩子的时候，我们将饼干的尺寸当成不变量，去找这个尺寸的饼干能够喂饱的孩子
            // 所以for循环遍历胃口，我们首先把最大尺寸的饼干拿出来，一旦可以喂饱一个孩子，
            // 我们就result++，并且index--，继续拿第二大尺寸的饼干去遍历剩余（i--）的孩子
            for(int i = g.size() - 1; i >= 0; i--) {  // 反向遍历胃口
                if (index >= 0 && g[i] <= s[index]) { // 如果饼干可以满足胃口，
                    result++; // 结果加1
                    index--; // 反向遍历饼干
                }
            }
        }
    };

    // 注意版本一的代码中，可以看出来，是先遍历的胃口，在遍历的饼干，那么可不可以 先遍历 饼干，在遍历胃口呢？
    // 不可以，为什么？
    // 因为如果孩子的最大胃口，最大尺寸的饼干都满足不了，那么我们将最大胃口最为不变量，会发现找不到合适的饼干，结果就是0，循环就退出了
    // 可以换个写法


    // 版本2
    // 小饼干先喂饱小胃口
    // 时间复杂度：O(nlogn)
    // 空间复杂度：O(1)
    class Solution {
    public:
        int findContentChildren(vector<int>& g, vector<int>& s) {
            sort(g.begin(),g.end());
            sort(s.begin(),s.end());
            int index = 0;
            for(int i = 0; i < s.size(); i++) { // 饼干
                if(index < g.size() && g[index] <= s[i]){ // 胃口
                    index++;
                }
            }
            return index;  // 这里用了优化，没有定义result数组
            // 胃口和饼干都是从小到大遍历，每一次遍历中，孩子胃口是是不变量，只有满足孩子胃口了，才会去评估下个孩子，index++
            // 那么这样index也可以表征胃口被满足的孩子个数
        }
    };
    // 版本2比版本1的优化点在于，我们从小到达遍历，先遍历饼干，在遍历胃口，这样就可以保证饼干尽可能的满足胃口，不会造成饼干太大孩子吃不完
    // 这样结果才是最优的。







    return 0;

}
