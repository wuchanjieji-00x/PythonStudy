// #include "iostream"
// #include <vector>
// #include <algorithm>
// using namespace std;
//
// // 第15题. 三数之和
//
//
//
//
// int main() {
//
//     // 解法1：
//     class Solution {
//     public:
//         vector<vector<int>> threeSum(vector<int>& nums) { // 接收一个一维向量，输出一个二维向量
//             vector<vector<int>> result; // 结果集，初始化为0
//             sort(nums.begin(), nums.end()); // 将nums升序排序
//
//             for (int i = 0; i < nums.size(); i++) { // 遍历nums
//                 if (nums[i] > 0) {
//                     return result;
//                 }
//
//                 if(i > 0 && nums[i] == nums[i - 1]) { // 对i去重。相当于跳过重复的i，只处理第一个i
//                     continue;
//                 }
//
//                 int left = i + 1; // left指针指向i下一个元素
//                 int right = nums.size() - 1; // right指针指向nums最右端
//                 while (right > left) {
//                     if ((nums[i] + nums[left] + nums[right]) > 0) right--;
//                     else if ((nums[i] + nums[left] + nums[right]) < 0) left++;
//                     else {
//                         result.push_back(vector<int> {nums[i], nums[left], nums[right]});
//
//                         // 至少先得到一个结果再去重
//                         while (right > left && nums[right] == nums[right - 1]) right--; // 对c去重，相当于跳过重复的c，只处理排序后的第一个c
//                         while (right > left && nums[left] == nums[left + 1]) left++; // 对b去重，相当于跳过重复的b，只处理排序后的最后一个b
//
//                         right--;
//                         left++;
//                     }
//
//                 }
//             }
//             return result;
//         }
//
//     };
//
//
//     // // leetcode官方
//     // class Solution {
//     // public:
//     //     vector<vector<int>> threeSum(vector<int>& nums) {
//     //         int n = nums.size();
//     //         sort(nums.begin(), nums.end());
//     //         vector<vector<int>> ans;
//     //         // 枚举 a
//     //         for (int first = 0; first < n; ++first) {
//     //             // 需要和上一次枚举的数不相同
//     //             if (first > 0 && nums[first] == nums[first - 1]) {
//     //                 continue;
//     //             }
//     //             // c 对应的指针初始指向数组的最右端
//     //             int third = n - 1;
//     //             int target = -nums[first];
//     //             // 枚举 b
//     //             for (int second = first + 1; second < n; ++second) {
//     //                 // 需要和上一次枚举的数不相同
//     //                 if (second > first + 1 && nums[second] == nums[second - 1]) {
//     //                     continue;
//     //                 }
//     //                 // 需要保证 b 的指针在 c 的指针的左侧
//     //                 while (second < third && nums[second] + nums[third] > target) {
//     //                     --third;
//     //                 }
//     //                 // 如果指针重合，随着 b 后续的增加
//     //                 // 就不会有满足 a+b+c=0 并且 b<c 的 c 了，可以退出循环
//     //                 if (second == third) {
//     //                     break;
//     //                 }
//     //                 if (nums[second] + nums[third] == target) {
//     //                     ans.push_back({nums[first], nums[second], nums[third]});
//     //                 }
//     //             }
//     //         }
//     //         return ans;
//     //     }
//     // };
//
//
//
//
//
//
//
//
//
//     return 0;
//
// }
