// #include "iostream"
// #include <vector>
// #include <algorithm>
//
// using namespace std;
//
// // 242.有效的字母异位词
//
//
//
//
// int main() {
//
//     // 解法1:哈希法:数组容器
//     // 时间复杂度: O(n)
//     // 空间复杂度: O(1)   空间上因为定义是的一个常量大小的辅助数组，所以空间复杂度为O(1)
//     class Solution {
//     public:
//         bool isAnagram(string s, string t) {
//             int hash[26] = {0};  // 注意这种数组初始化的方式
//             // 并不需要记住字符a的ASCII，只要求出一个相对数值就可以了
//             for (int i = 0; i < s.size(); i++) {
//                 hash[s[i] - 'a']++;
//             }
//
//             for (int i = 0; i < t.size(); i++) {
//                 hash[t[i] - 'a']--;
//             }
//
//             for (int i = 0; i < 26; i++) {
//                 // record数组如果有的元素不为零0，说明字符串s和t 一定是谁多了字符或者谁少了字符。
//                 if (hash[i] != 0) {
//                     return false;
//                 }
//             }
//             // record数组所有元素都为零0，说明字符串s和t是字母异位词
//             return true;
//         }
//     };
//
//
//
//     // 解法2：leetCode官方 哈希法：数组容器
//     class Solution {
//     public:
//         bool isAnagram(string s, string t) {
//             if (s.length() != t.length()) {
//                 return false;
//             }
//
//             vector<int> table(26,0);
//             for (auto& ch : s) {
//                 table[ch - 'a']++;
//             }
//
//             for (auto& ch : t) {
//                 table[ch - 'a']--;
//                 if (table[ch - 'a'] < 0) {
//                     return false;
//                 }
//             }
//             return true;
//         }
//     };
//
//
//     // 解法3：leetCode官方 排序法
//     // 思路：对字符串 s 和 t 分别排序，看排序后的字符串是否相等；
//     // 此外，如果 s 和 t 的长度不同，t 必然不是 s 的异位词。
//     class Solution {
//     public:
//         bool isAnagram(string s, string t) {
//             if (s.length() != t.length()) {
//                 return false;
//             }
//
//             sort(s.begin(), s.end());
//             sort(t.begin(), t.end());
//
//             return s == t;
//
//         }
//     };
//
//
//     return 0;
//
// }