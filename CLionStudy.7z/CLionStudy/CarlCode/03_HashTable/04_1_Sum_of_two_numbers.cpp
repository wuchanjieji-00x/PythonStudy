// #include <unordered_map>
//
// #include "iostream"
// #include <vector>
// using namespace std;
//
// // 1. 两数之和
//
//
//
//
// int main() {
//
//     // 解法1: 哈希法：map
//     class Solution {
//     public:
//         vector<int> twoSum(vector<int> & nums, int target) {
//             std::unordered_map<int, int>map;  // 定义一个hashmap容器用于存储数组的元素，容器自动去重
//             // 遍历当前元素，并在map中寻找是否有匹配的key
//             for(int i = 0; i < nums.size(); i++) {
//                 auto iter = map.find(target - nums[i]);
//                 // 找target - nums[i]这个key，如果找到，则返回这个键值对
//                 // iter是一个键值对，key:target - nums[i]，value:这个key在map里面对应的value
//                 // 如果在map中没有找到target-nums[i]这个key，则返回map.end()
//                 if (iter != map.end()) { // 如果这个键值对在map里面出现过，
//                     return {iter->second, i}; // 则返回这个键值对里的value（target-nums[i] 这个值在nums数组里的下标）和当前遍历的index
//                 }
//                 map.insert(pair<int, int>(nums[i], i)); // 将当前元素和其在数组中的下标插入map中。元素作为key，下标作为value
//             }
//
//             return {};
//         }
//     };
//
//
//
//     // 解法2：leetcode官方：hash法
//     // 时间复杂度：O(N)，其中 N 是数组中的元素数量。对于每一个元素 x，我们可以 O(1) 地寻找 target - x
//     // 空间复杂度：O(N)，其中 N 是数组中的元素数量。主要为哈希表的开销。
//     class Solution {
//     public:
//         vector<int> twoSum(vector<int> & nums, int target) {
//             unordered_map<int, int> hashTable;
//             for (int i = 0; i < nums.size(); i++) {
//                 auto it = hashTable.find(target - nums[i]);
//                 if (it != hashTable.end()) {
//                     return {it->second, i};
//                 }
//                 hashTable[nums[i]] = i; // 插入元素（键值对）：map的key是nums[i]，value是nums[i]在nums数组中的下标
//             }
//
//             return {};
//         }
//     };
//
//
//
//     return 0;
//
// }
