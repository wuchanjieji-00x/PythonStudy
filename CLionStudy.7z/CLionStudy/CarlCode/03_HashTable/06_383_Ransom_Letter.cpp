// #include "iostream"
//
// using namespace std;
//
//// 383. 赎金信
//
//
//
//
// int main() {
//
//     // 解法1：hashArray
//     class Solution {
//     public:
//         bool canConstruct(string ransomNote, string magazine) {
//             int hashtable[26] = {0};
//
//             if (ransomNote.size() > magazine.size()) {
//                 return false;
//             }
//             // 通过hashtable记录 magazine里各个字符出现次数
//             for(int i = 0; i < magazine.length(); i++) { // for (auto & m : magazine){hashtable[m - 'a']++}
//                 hashtable[magazine[i] - 'a']++;
//             }
//             // 遍历ransomNote，在record里对应的字符个数做--操作
//             for (int j = 0; j < ransomNote.length(); j++) { // for (auto & r : ransomNote){hasttable[r - 'a']--;}
//                 hashtable[ransomNote[j] - 'a']--;
//                 // 如果小于零说明ransomNote里出现的字符，magazine没有
//                 if (hashtable[ransomNote[j] - 'a'] < 0) { // if (hashtable[r - 'a'] < 0)
//                     return false;
//                 }
//             }
//             return true;
//         }
//     };
//
//
//
//
//
//
//
//
//
//     return 0;
//
// }
