// #include "iostream"
// #include <vector>
// #include <unordered_set>
//
// using namespace std;
//
//
// // 349. 两个数组的交集
// // 给定两个数组，编写一个函数来计算它们的交集
//
//
//
//  int main() {
//
//      // 解法1：哈希法：哈希set(可以无限存储、无序、去重的数据容器)
//      // 如果使用哈希集合存储元素，则可以在 O(1) 的时间内判断一个元素是否在集合中，从而降低时间复杂度。
//      class Solution {
//      public:
//          vector<int> intersection(vector<int>& nums1, vector<int>& nums2) {
//              unordered_set<int> result_set; // 存放结果，之所以用set是为了给结果集去重
//              unordered_set<int> nums_set(nums1.begin(), nums1.end()); // 将nums1的元素全部放入nums_set中，换容器并去重
//
//              for (int num : nums2) { // 遍历nums2向量
//                  // // 发现nums2的元素 在nums_set里又出现过
//                  if (nums_set.find(num) != nums_set.end()) { // 在nums_set中找到了nums2的元素
//                      result_set.insert(num); // 将num插入到result_set中，容器自动去重
//                  }
//              }
//
//              return vector<int>(result_set.begin(), result_set.end()); // 将result_set转换为vector输出
//          }
//      };
//
//
//
//      // 解法2：哈希法：哈希数组（有限存储、跨度小、无序，不去重的数据容器）
//      // 原数组的值，映射为哈希数组的下标
//      // 思路：增添了 数值范围：数组的元素值和数组长度都是 1000以内的
//      class Solution {
//      public:
//          vector<int> intersection(vector<int>& nums1, vector<int>& nums2) {
//              unordered_set<int> result_set; // 存放结果，之所以用set是为了给结果集去重
//              int hash[1005] = {0};
//
//              for (int num : nums1) {
//                  hash[num] = 1;
//              }
//
//              for (int num : nums2) {
//                  if (hash[num] == 1) {
//                      result_set.insert(num);
//                  }
//              }
//
//              return vector<int>(result_set.begin(), result_set.end());
//          }
//      };
//
//
//
//
//
//
//
//      return 0;
//
//  }