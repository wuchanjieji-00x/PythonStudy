


#include <vector>
using namespace std;

// 343. 整数拆分




int main() {

    // 动规
    // 时间复杂度：O(n^2)
    // 空间复杂度：O(n)
    class Solution {
    public:
        int integerBreak(int n) {
            vector<int> dp(n + 1);
            // dp[0]和dp[1]没有意义
            dp[2] = 1;
            for (int i = 3; i <= n ; i++) {
                for (int j = 1; j <= i / 2; j++) {
                    dp[i] = max(dp[i], max((i - j) * j, dp[i - j] * j));
                    // 这里不仅要取 (i - j) * j 和 dp[i - j] * j 中的较大值，还要每次进行对比后的较大值不断更新dp[i]
                }
            }
            return dp[n];
        }
    };





    // 贪心
    // 每次拆成n个3，如果剩下是4，则保留4，然后相乘，但是这个结论需要数学证明其合理性！
    // 时间复杂度：O(n)
    // 空间复杂度：O(1)
    class Solution {
    public:
        int integerBreak(int n) {
            if (n == 2) return 1;
            if (n == 3) return 2;
            if (n == 4) return 4;
            int result = 1;
            while (n > 4) {
                result *= 3;
                n -= 3;
            }
            result *= n;
            return result;
        }
    };








    return 0;

}
