
using namespace std;

// 1143.最长公共子序列

// 本题和上题的区别在于，我们要求的是子序列，元素可以不连续
// 所以我们可以逐个拿一个数组的元素，去遍历另一个数组的全部元素


int main() {

    //
    // 时间复杂度: O(n * m)，其中 n 和 m 分别为 text1 和 text2 的长度
    // 空间复杂度: O(n * m)
    class Solution {
    public:
        int longestCommonSubsequence(string text1, string text2) {
            vector<vector<int>> dp(text1.size() + 1, vector<int>(text2.size() + 1, 0));
            for (int i = 1; i <= text1.size(); i++) {
                for (int j = 1; j <= text2.size(); j++) {
                    if (text1[i - 1] == text2[j - 1]) {
                        // 如果s中的第i个字符和t中的第j个字符匹配，则当前的dp结果等于上两个字符的匹配dp结果加1
                        dp[i][j] = dp[i - 1][j - 1] + 1;
                    } else {
                        dp[i][j] = max(dp[i - 1][j], dp[i][j - 1]);  // 这个已经保证得到的子序列是最大的
                    }
                }
            }
            return dp[text1.size()][text2.size()];
        }
    };







    return 0;

}