
using namespace std;


// 392.判断子序列

// 字符串的一个子序列是原始字符串删除一些（也可以不删除）字符而不改变剩余字符相对位置形成的新字符串。（例如，"ace"是"abcde"的一个子序列，而"aec"不是）。

int main() {

    //
    // 时间复杂度：O(n × m)
    // 空间复杂度：O(n × m)
    class Solution {
    public:
        bool isSubsequence(string s, string t) {
            vector<vector<int>> dp(s.size() + 1, vector<int>(t.size() + 1, 0));
            for (int i = 1; i <= s.size(); i++) {
                for (int j = 1; j <= t.size(); j++) {
                    if (s[i - 1] == t[j - 1]) dp[i][j] = dp[i - 1][j - 1] + 1;
                    // 如果s中的第i个字符和t中的第j个字符匹配，则当前的dp结果等于上两个字符的匹配dp结果加1
                    else dp[i][j] = dp[i][j - 1];
                    // 相当于用当前s中的第i个字符去匹配t中的第j个字符，如果不匹配，则跳过t中的该字符，那么当前的dp就沿用s中的i字符和t中j-1字符的匹配的dp结果
                }
            }
            if (dp[s.size()][t.size()] == s.size()) return true;
            return false;
        }
    };







    return 0;

}