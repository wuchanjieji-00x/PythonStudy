
using namespace std;

// 115.不同的子序列
// 这道题目如果不是子序列，而是要求连续序列的，那就可以考虑用KMP。




int main() {

    // 动态规划
    // 时间复杂度: O(n * m)
    // 空间复杂度: O(n * m)
    class Solution {
    public:
        int numDistinct(string s, string t) {
            vector<vector<uint64_t>> dp(s.size() + 1, vector<uint64_t>(t.size() + 1));
            for (int i = 0; i < s.size(); i++) dp[i][0] = 1;
            for (int j = 1; j < t.size(); j++) dp[0][j] = 0;
            for (int i = 1; i <= s.size(); i++) {
                for (int j = 1; j <= t.size(); j++) {
                    if (s[i - 1] == t[j - 1]) {
                        dp[i][j] = dp[i - 1][j - 1] + dp[i - 1][j];
                    } else {
                        dp[i][j] = dp[i - 1][j];
                    }
                }
            }
            return dp[s.size()][t.size()];
        }
    };







    return 0;

}