
using namespace std;


// 121. 买卖股票的最佳时机



int main() {

    // 解法1：暴力枚举
    // 找最优间距了，但是时间复杂度太高，超时了
    // 时间复杂度：O(n^2)
    // 空间复杂度：O(1)
    class Solution {
    public:
        int maxProfit(vector<int>& prices) {
            int result = 0;
            for (int i = 0; i < prices.size(); i++) {
                for (int j = i + 1; j < prices.size(); j++){
                    result = max(result, prices[j] - prices[i]);
                }
            }
            return result;
        }
    };



    // 贪心
    // 因为股票就买卖一次，那么贪心的想法很自然就是取最左最小值，取最右最大值，那么得到的差值就是最大利润。
    // 时间复杂度：O(n)
    // 空间复杂度：O(1)
    class Solution {
    public:
        int maxProfit(vector<int>& prices) {
            int low = INT_MAX;
            int result = 0;
            for (int i = 0; i < prices.size(); i++) {
                low = min(low, prices[i]);  // 取最左最小价格
                result = max(result, prices[i] - low); // 直接取最大区间利润
            }
            return result;
        }
    };


    // 动态规划
    // 版本一
    // 时间复杂度：O(n)
    // 空间复杂度：O(n)
    /*
    dp[i][0] 表示第i天持有股票所得利润
    dp[i][1] 表示第i天不持有股票所得最大利润 （因为遍历到最后了，不持有股票的利润肯定比持有股票的利润大）
    */
    class Solution {
    public:
        int maxProfit(vector<int>& prices) {
            int len = prices.size();
            if (len == 0) return 0;
            vector<vector<int>> dp(len, vector<int>(2)); // 开辟二维数组，初始化每个元素的各个状态值都为0
            dp[0][0] -= prices[0]; // 只需要初始化第一个元素的持有股票的状态
            dp[0][1] = 0; // 这里其实不用，只不过在开辟dp的时候，没有进行初始化而已
            for (int i = 1; i < len; i++) { // 遍历数组，从第二个元素开始，第一个元素已经被初始化了
                // 今天不持有股票的利润 = max(昨天就不持有股票的利润, 昨天持有股票的利润 + 今天卖出的股票价格)
                // 要么延续昨天的状态，要么今天买入股票
                dp[i][0] = max(dp[i - 1][0], -prices[i]);
                // 今天持有股票的利润 = max(昨天就持有股票的利润, 昨天不持有股票的利润 - 今天买入的股票价格)
                // 要么延续昨天的状态，要么今天卖出股票
                dp[i][1] = max(dp[i - 1][1], prices[i] + dp[i - 1][0]);
            }
            return dp[len - 1][1]; // 本题中不持有股票状态所得金钱一定比持有股票状态得到的多！
        }
    };


    // 从递推公式可以看出，dp[i]只是依赖于dp[i - 1]的状态
    // 那么我们只需要记录 当前天的dp状态和前一天的dp状态就可以了，可以使用滚动数组来节省空间
    // 版本二
    // 时间复杂度：O(n)
    // 空间复杂度：O(1)
    class Solution {
    public:
        int maxProfit(vector<int>& prices) {
            int len = prices.size();
            vector<vector<int>> dp(2, vector<int>(2)); // 注意这里只开辟了一个2 * 2大小的二维数组
            dp[0][0] -= prices[0];
            dp[0][1] = 0;
            for (int i = 1; i < len; i++) {
                // i是奇数，dp[0]是上一天的状态，dp[1]是当天的状态
                // i是偶数，dp[0]是当天的状态，dp[1]是上一天的状态
                // 交替更新，交替依赖
                dp[i % 2][0] = max(dp[(i - 1) % 2][0], -prices[i]);
                dp[i % 2][1] = max(dp[(i - 1) % 2][1], prices[i] + dp[(i - 1) % 2][0]);
            }
            return dp[(len - 1) % 2][1];
        }
    };





    return 0;

}