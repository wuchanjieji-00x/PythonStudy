

#include <vector>
using namespace std;

// 416. 分割等和子集

// 题目要求把数组分成两个元素之和相等的子集，排除元素总和为奇数的不合法情况
// 问题转化为，求是否能在原数组中找到一个子集，使其元素和为原数组元素总和的一半
// 抽象为01背包问题，元素就是物品，元素的值就是元素的重量，也是元素的价值
// 问题就转化为：一个可装sum/2重量的背包，是否可以装重量为sum/2的物品，使其价值等于sum/2



int main() {


    //
    // 时间复杂度：O(n^2)
    // 空间复杂度：O(n)，虽然dp数组大小为一个常数，但是大常数
    class Solution {
    public:
        bool canPartition(pmr::vector<int>& nums) {
            int sum = 0;

            // dp[i]中的i表示背包内总和
            // 题目中说：每个数组中的元素不会超过 100，数组的大小不会超过 200
            // 总和不会大于20000，背包最大只需要其中一半，所以10001大小就可以了

            // 因为元素的值的总和在这里抽象成背包所能承受的最大重量
            // 但我们只需要假设一个sum/2的背包就行了，所以dp数组大小为sum/2+1
            vector<int> dp(10001, 0);
            for (int i = 0; i < nums.size(); i++) {
                sum += nums[i];
            }
            // 也可以使用库函数一步求和
            // int sum = accumulate(nums.begin(), nums.end(), 0);
            if (sum % 2 == 1) return false; // 如果数组元素的总和为奇数，那么不可能分成两个总和相等的子集
            int target = sum / 2;
            // 问题转化为，能不能将数组元素放入背包，使得背包内总和为sum/2
            // 此时背包内元素总和就是最大价值，元素的值就是元素的重量，也是元素的价值，
            // 那么就转化为01背包问题

            // 开始 01背包
            for(int i = 0; i < nums.size(); i++) { // 遍历物品
                // 倒序遍历背包
                for(int j = target; j >= nums[i]; j--) { // 每一个元素一定是不可重复放入，所以从大到小遍历
                    dp[j] = max(dp[j], dp[j - nums[i]] + nums[i]);
                }
            }
            // 集合中的元素正好可以凑成总和target
            if (dp[target] == target) return true;
            return false;
        }
    };






    return 0;

}
