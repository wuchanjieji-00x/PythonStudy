
#include <vector>
using namespace std;

// 63. 不同路径 II




int main() {

    // 动规
    // 时间复杂度：O(n × m)，n、m 分别为obstacleGrid 长度和宽度
    // 空间复杂度：O(n × m)
    // 其实只要考虑到，遇到障碍dp[i][j]保持0就可以了。也有一些小细节，例如：初始化的部分，很容易忽略了障碍之后应该都是0的情况
    class Solution {
    public:
        int uniquePathsWithObstacles(vector<vector<int>>& obstacleGrid) {
            int m = obstacleGrid.size(); // 行数
            int n = obstacleGrid[0].size(); // 列数
            if (obstacleGrid[m - 1][n - 1] == 1 || obstacleGrid[0][0] == 1) //如果在起点或终点出现了障碍，直接返回0
                return 0;
            // dp[i][j]：在i j 位置，有多少条路径可以到达，初始值都为0
            vector<vector<int>> dp(m, vector<int>(n, 0));

            // 对第一行和第一列进行初始化，因为其没有上面进来的路径或左边进来的路径，不适用我们的递推公式
            // 没有遇到障碍物，第一行和第一列全部赋值为1
            // 遇到障碍物，立马停止赋值，所以障碍物之前都为1，障碍物之后（包括障碍物都不赋值，保持为0）
            for (int i = 0; i < m && obstacleGrid[i][0] == 0; i++) dp[i][0] = 1;
            for (int j = 0; j < n && obstacleGrid[0][j] == 0; j++) dp[0][j] = 1;
            // i和j都从1开始遍历，因为我们认为起点为[0,0]
            for (int i = 1; i < m; i++) {
                for (int j = 1; j < n; j++) {
                    if (obstacleGrid[i][j] == 1) continue;
                    dp[i][j] = dp[i - 1][j] + dp[i][j - 1];
                }
            }
            return dp[m - 1][n - 1]; // 这是二维数组的右下角的位置
        }
    };


    // 版本1的空间优化
    // 时间复杂度：O(n × m)，n、m 分别为obstacleGrid 长度和宽度
    // 空间复杂度：O(m)
    // 降成一维数组，没看懂
    class Solution {
    public:
        int uniquePathsWithObstacles(vector<vector<int>>& obstacleGrid) {
            if (obstacleGrid[0][0] == 1)
                return 0;
            vector<int> dp(obstacleGrid[0].size());
            for (int j = 0; j < dp.size(); ++j)
                if (obstacleGrid[0][j] == 1)
                    dp[j] = 0;
                else if (j == 0)
                    dp[j] = 1;
                else
                    dp[j] = dp[j-1];

            for (int i = 1; i < obstacleGrid.size(); ++i)
                for (int j = 0; j < dp.size(); ++j){
                    if (obstacleGrid[i][j] == 1)
                        dp[j] = 0;
                    else if (j != 0)
                        dp[j] = dp[j] + dp[j-1];
                }
            return dp.back();
        }
    };





    return 0;

}
