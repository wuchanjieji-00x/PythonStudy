#include <vector>
using namespace std;






int main() {

    //
    // 版本一
    // 时间复杂度: O(n * √n)
    // 空间复杂度: O(n)
    class Solution {
    public:
        int numSquares(int n) {
            vector<int> dp(n + 1, INT_MAX);
            dp[0] = 0;
            for (int i = 0; i <= n; i++) { // 遍历背包
                for (int j = 1; j * j <= i; j++) { // 遍历物品
                    dp[i] = min(dp[i - j * j] + 1, dp[i]);
                }
            }
            return dp[n];
        }
    };



    // 同样我在给出先遍历物品，在遍历背包的代码，一样的可以AC的。
    // 版本二
    class Solution {
    public:
        int numSquares(int n) {
            vector<int> dp(n + 1, INT_MAX);
            dp[0] = 0;
            for (int i = 1; i * i <= n; i++) { // 遍历物品
                for (int j = i * i; j <= n; j++) { // 遍历背包
                    dp[j] = min(dp[j - i * i] + 1, dp[j]);
                }
            }
            return dp[n];
        }
    };





    return 0;

}