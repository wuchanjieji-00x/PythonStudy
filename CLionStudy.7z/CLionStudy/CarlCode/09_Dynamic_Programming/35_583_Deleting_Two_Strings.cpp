
using namespace std;

// 583. 两个字符串的删除操作




int main() {

    // 动规1
    // 时间复杂度: O(n * m)
    // 空间复杂度: O(n * m)
    class Solution {
    public:
        int minDistance(string word1, string word2) {
            vector<vector<int>> dp(word1.size() + 1, vector<int>(word2.size() + 1));
            // 初始化
            for (int i = 0; i <= word1.size(); i++) dp[i][0] = i;
            for (int j = 0; j <= word2.size(); j++) dp[0][j] = j;
            for (int i = 1; i <= word1.size(); i++) {
                for (int j = 1; j <= word2.size(); j++) {
                    if (word1[i - 1] == word2[j - 1]) {
                        dp[i][j] = dp[i - 1][j - 1];
                    } else {
                        dp[i][j] = min(dp[i - 1][j] + 1, dp[i][j - 1] + 1);
                    }
                }
            }
            return dp[word1.size()][word2.size()];
        }
    };



    // 动规2
    // 只要求出两个字符串的最长公共子序列长度即可，
    // 那么除了最长公共子序列之外的字符都是必须删除的，最后用两个字符串的总长度减去两个最长公共子序列的长度就是删除的最少步数。
    // 时间复杂度: O(n * m)
    // 空间复杂度: O(n * m)
    class Solution {
    public:
        int minDistance(string word1, string word2) {
            vector<vector<int>> dp(word1.size()+1, vector<int>(word2.size()+1, 0));
            for (int i=1; i<=word1.size(); i++){
                for (int j=1; j<=word2.size(); j++){
                    if (word1[i-1] == word2[j-1]) dp[i][j] = dp[i-1][j-1] + 1;
                    else dp[i][j] = max(dp[i-1][j], dp[i][j-1]);
                }
            }
            return word1.size()+word2.size()-dp[word1.size()][word2.size()]*2;
        }
    };







    return 0;

}