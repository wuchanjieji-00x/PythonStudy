
#include <vector>
using namespace std;

// 509. 斐波那契数




int main() {


    // 解法1；动态规划
    // 版本1
    // 时间复杂度：O(n)
    // 空间复杂度：O(n)
    class Soution {
    public:
        int fib(int N) {
            if (N <= 1) return N;
            vector<int> dp(N + 1);
            dp[0] = 1;
            dp[1] = 1;
            for (int i = 2; i <= N; i++) {
                dp[i] = dp[i - 1] + dp[i - 2];
            }
            return dp[N];
        }
    };


    // 版本2
    // 状态压缩
    // 我们只需要维护两个数值就可以了，不需要记录整个序列。因为我们最后输出的是第N个fib数字，不是序列
    // 时间复杂度：O(n)
    // 空间复杂度：O(1)
    class Solution {
    public:
        int fib(int N) {
            if (N <= 1) return N;
            int dp[2];
            dp[0] = 0;
            dp[1] = 1;
            for (int i = 2; i <= N; i++) {
                int sum = dp[0] + dp[1];
                dp[0] = dp[1];
                dp[1] = sum;
            }
            return dp[1];
        }
    };



    // 解法2：递归
    // 时间复杂度：O(2^n)
    // 空间复杂度：O(n)，算上了编程语言中实现递归的系统栈所占空间
    class Solution {
    public:
        int fib(int N) {
            if (N < 2) return N;
            return fib(N - 1) + fib(N - 2);
        }
    };









    return 0;

}