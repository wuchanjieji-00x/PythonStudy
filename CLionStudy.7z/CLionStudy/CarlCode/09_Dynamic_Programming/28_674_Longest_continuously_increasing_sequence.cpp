
using namespace std;

// 674. 最长连续递增序列

// 不连续递增的子序列跟前0-i 个状态有关，连续递增的子序列只跟前一个状态有关


// dp[i]：以下标i为结尾的连续递增的子序列长度为dp[i]
// 注意这里的定义，一定是以下标i为结尾，并不是说一定以下标0为起始位置

int main() {

    // 动规
    // 时间复杂度：O(n)
    // 空间复杂度：O(n)
    class Solution {
    public:
        int findLengthOfLCIS(vector<int>& nums) {
            if (nums.size() == 0) return 0;
            int result = 1;
            vector<int> dp(nums.size() ,1); // 每个元素给一个状态位，全部初始化为1，意为只有自己的状态
            for (int i = 1; i < nums.size(); i++) {
                if (nums[i] > nums[i - 1]) { // 连续记录  // 当前元素的状态只和前一个元素的状态有关
                    dp[i] = dp[i - 1] + 1;
                }
                if (dp[i] > result) result = dp[i];
            }
            return result;
        }
    };




    // 贪心
    // 遇到nums[i] > nums[i - 1]的情况，count就++，否则count为1，记录count的最大值就可以了。
    // 时间复杂度：O(n)
    // 空间复杂度：O(1)
    class Solution {
    public:
        int findLengthOfLCIS(vector<int>& nums) {
            if (nums.size() == 0) return 0;
            int result = 1; // 连续子序列最少也是1
            int count = 1;
            for (int i = 1; i < nums.size(); i++) {
                if (nums[i] > nums[i - 1]) { // 连续记录
                    count++;
                } else { // 不连续，count从头开始
                    count = 1;
                }
                if (count > result) result = count;
            }
            return result;
        }
    };










    return 0;

}