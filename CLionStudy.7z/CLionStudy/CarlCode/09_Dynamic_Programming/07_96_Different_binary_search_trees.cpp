

#include <vector>
using namespace std;

// 96.不同的二叉搜索树




int main() {

    // 动规
    // 时间复杂度：$O(n^2)$
    // 空间复杂度：$O(n)$
    class Solution {
    public:
        int numTrees(int n) {
            // 这里的 n 表示问题的规模或范围，而 +1 的原因是为了能够正确处理边界情况。
            // 通常在动态规划中，会将数组的大小设置为问题规模加一，以包含所有的可能情况或状态。
            vector<int> dp(n + 1);
            // 特殊情况只有n=0的情况，这时对应的时一个空二叉树，那也是二叉搜索树
            // n=1的情况不用初始化，为什么？因为也适用递推公式
            dp[0] = 1;
            // n=0的情况已经单独处理了，所以从1开始遍历
            for (int i = 1; i <= n; i++) {
                for (int j = 1; j <= i; j++) {
                    dp[i] += dp[j - 1] * dp[i - j];
                    // dp[i]：n=i时对应的BST的个数，那么就等于其左子树的个数 * 右子树的个数
                    // 这里的j是去从小到大遍历i的，意为将1到i逐个作为根节点时得到的BST个数
                }
            }
            return dp[n];
        }
    };







    return 0;

}
