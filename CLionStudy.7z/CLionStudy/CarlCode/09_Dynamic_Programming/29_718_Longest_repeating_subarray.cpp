
using namespace std;

// 718. 最长重复子数组
// 注意题目中说的子数组，其实就是连续子序列。




int main() {

    // 动规
    // 版本一：二维数组
    // 时间复杂度：O(n × m)，n 为A长度，m为B长度
    // 空间复杂度：O(n × m)
    class Solution {
    public:
        int findLength(vector<int>& nums1, vector<int>& nums2) {
            vector<vector<int>> dp (nums1.size() + 1, vector<int>(nums2.size() + 1, 0));
            int result = 0;
            for (int i = 1; i <= nums1.size(); i++) {
                for (int j = 1; j <= nums2.size(); j++) {
                    if (nums1[i - 1] == nums2[j - 1]) {
                        dp[i][j] = dp[i - 1][j - 1] + 1;
                    }
                    if (dp[i][j] > result) result = dp[i][j];
                }
            }
            return result;
        }
    };



    
    // 动规
    // 版本二：滚动数组
    // 时间复杂度：O(n × m)，n 为A长度，m为B长度
    // 空间复杂度：O(m)
    class Solution {
    public:
        int findLength(vector<int>& A, vector<int>& B) {
            vector<int> dp(vector<int>(B.size() + 1, 0));
            int result = 0;
            for (int i = 1; i <= A.size(); i++) {
                for (int j = B.size(); j > 0; j--) {
                    if (A[i - 1] == B[j - 1]) {
                        dp[j] = dp[j - 1] + 1;
                    } else dp[j] = 0; // 注意这里不相等的时候要有赋0的操作
                    if (dp[j] > result) result = dp[j];
                }
            }
            return result;
        }
    };







    return 0;

}