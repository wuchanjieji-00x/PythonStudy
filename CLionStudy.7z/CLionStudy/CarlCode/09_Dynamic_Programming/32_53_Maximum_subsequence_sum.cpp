
using namespace std;


// 53. 最大子序和

// dp[i]：包括下标i（以nums[i]为结尾）的最大连续子序列和为dp[i]。

int main() {

    // 动规
    // 思路：如果元素i之前的连续子序列的和为正，就保留，否则就从nums[i]往后开始计算子数组的和
    // 时间复杂度：O(n) ：把数组遍历一遍
    // 空间复杂度：O(n) ：需要开辟一个数组dp，大小为n
    class Solution {
    public:
        int maxSubArray(vector<int>& nums) {
            if (nums.size() == 0) return 0;
            vector<int> dp(nums.size(), 0); // 这个0可不写
            dp[0] = nums[0]; // 只把dp[0]的初始值改为nums[0]，其他的都保持0
            int result = dp[0];
            for (int i = 1; i < nums.size(); i++) {
                dp[i] = max(dp[i - 1] + nums[i], nums[i]); // 状态转移公式
                if (dp[i] > result) result = dp[i]; // result 保存dp[i]的最大值
            }
            return result;
        }
    };







    return 0;

}