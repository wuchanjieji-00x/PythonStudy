
using namespace std;

// 122.买卖股票的最佳时机II

// 本题股票可以买卖多次了（注意只有一只股票，所以再次购买前要出售掉之前的股票）
// 也就是说，在上一题中，因为股票只能买卖一次，所以第i天买入的话，那么前一天肯定不买入，那么前一天的利润为0，
// 今天买入的话，利润就是 0 - prices[i]
// 但是本题中，股票可以多次买卖，而且只有一支股票，也就是说，今天要买入的话，那么昨天或者之前肯定是卖出的。
// 那么当考虑今天买入股票的时候，要么是第一次买入，昨天没持有股票；要么是之前已经买卖过，获得过利润（可正可负），
// 那么今天如果买入股票的话，利润就是 dp[i-1][1])- prices[i]

// dp[i][0] 表示第i天持有股票所得利润。
// dp[i][1] 表示第i天不持有股票所得最多利润
// dp[i][1] 肯定大于 dp[i][0]


int main() {

    //
    // 时间复杂度：O(n)
    // 空间复杂度：O(n)
    class Solution {
    public:
        int maxProfit(vector<int>& prices) {
            int len = prices.size();
            vector<vector<int>> dp(len, vector<int>(2, 0));
            dp[0][0] -= prices[0];
            dp[0][1] = 0;
            for (int i = 1; i < len; i++) {
                // 第i天持有股票所得利润 = max(昨天就持有股票的利润保持到今天，今天买入股票（昨天肯定是卖出了，同时获得利润了）)
                dp[i][0] = max(dp[i - 1][0], dp[i - 1][1] - prices[i]); // 注意这里是和121. 买卖股票的最佳时机唯一不同的地方。
                // 这正是因为本题的股票可以买卖多次！ 所以买入股票的时候，可能会有之前买卖的利润即：dp[i - 1][1]，所以dp[i - 1][1] - prices[i]。

                // 第i天不持有股票所得最多利润 = max(昨天就不持有股票的利润保持到今天，今天卖出股票（昨天肯定是持有了）)
                dp[i][1] = max(dp[i - 1][1], dp[i - 1][0] + prices[i]);
            }
            return dp[len - 1][1];  // dp[i][1] 肯定大于 dp[i][0]
        }
    };



    // 滚动数组优化
    // 版本二
    // 时间复杂度：O(n)
    // 空间复杂度：O(1)
    class Solution {
    public:
        int maxProfit(vector<int>& prices) {
            int len = prices.size();
            vector<vector<int>> dp(2, vector<int>(2)); // 注意这里只开辟了一个2 * 2大小的二维数组
            dp[0][0] -= prices[0];
            dp[0][1] = 0;
            for (int i = 1; i < len; i++) {
                dp[i % 2][0] = max(dp[(i - 1) % 2][0], dp[(i - 1) % 2][1] - prices[i]);
                dp[i % 2][1] = max(dp[(i - 1) % 2][1], prices[i] + dp[(i - 1) % 2][0]);
            }
            return dp[(len - 1) % 2][1];
        }
    };








    return 0;

}