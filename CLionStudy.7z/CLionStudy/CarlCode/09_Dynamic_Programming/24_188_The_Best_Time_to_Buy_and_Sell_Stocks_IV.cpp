
using namespace std;

// 188.买卖股票的最佳时机IV
// 在上一题的基础上，将j的下标抽象成j



int main() {

    //
    // 时间复杂度: O(n * k)，其中 n 为 prices 的长度
    // 空间复杂度: O(n * k)
    class Solution {
    public:
        int maxProfit(int k, vector<int>& prices) {

            if (prices.size() == 0) return 0;
            // 每一个元素有一个不操作的状态，和，k次买入卖出状态，所以总的状态数就是2k+1
            vector<vector<int>> dp(prices.size(), vector<int>(2 * k + 1, 0));
            for (int j = 1; j < 2 * k; j += 2) {
                // j为奇数时，定义为第k次买入股票状态
                // j为偶数时，定义为第k次卖出股票状态
                // 这里只用初始化买入股票的状态，卖出股票的状态的初始化就是0
                dp[0][j] = -prices[0];
            }
            for (int i = 1;i < prices.size(); i++) {
                // 第i天的状态转移方程
                // 因为有k次，每一次又对应：第j次买入状态和第j次卖出状态
                for (int j = 0; j < 2 * k - 1; j += 2) {
                    // 当j=2k-2时，根据下面的递推公式已经计算到了2k的状态了
                    dp[i][j + 1] = max(dp[i - 1][j + 1], dp[i - 1][j] - prices[i]);
                    dp[i][j + 2] = max(dp[i - 1][j + 2], dp[i - 1][j + 1] + prices[i]);
                }
            }
            return dp[prices.size() - 1][2 * k]; // 第k次卖出股票后的利润
        }
    };







    return 0;

}