
using namespace std;

// 300.最长递增子序列  （LIS）
// 子序列是由数组派生而来的序列，删除（或不删除）数组中的元素而不改变其余元素的顺序
// 只能选择删除或保留原数组的元素，不能改变原数组的顺序

// dp[i]表示i之前包括i的以nums[i]结尾的最长递增子序列的长度

int main() {

    //
    // 时间复杂度: O(n^2)
    // 空间复杂度: O(n)
    class Solution {
    public:
        int lengthOfLIS(vector<int>& nums) {
            if (nums.size() <= 1) return nums.size();
            vector<int> dp(nums.size(), 1); // 每一个i，对应的dp[i]（即最长递增子序列）起始大小至少都是1
            int result = 0;
            for (int i = 1; i < nums.size(); i++) {
                for (int j = 0; j < i; j++) { // 当前的状态和0-i之间的状态有关，我们要遍历0-i之间的元素，找到最大值
                    if (nums[i] > nums[j]) dp[i] = max(dp[i], dp[j] + 1);  // dp[j]++可以吗？

                    // 不可以
                    // dp[i]++ 的使用是不正确的，因为它会在每次满足条件时增加 dp[i]，而实际上我们需要的是在所有满足条件的 j 中找到最大的 dp[j] 并加1
                    // 这才是状态转移的思想，请好好体会

                    // dp数组中，dp[i]全部初始化为1
                    // 对于一个i,用j遍历i之前（不包括i）的所有元素，遇到比nums[i]小的元素，dp[i]++
                    // 遇到比nums[i]小的元素，dp[i]不变，因为max一直在比较dagn
                }
                if (dp[i] > result) result = dp[i]; // 取长的子序列
            }
            return result;
        }
    };







    return 0;

}