#include <vector>
#include <cmath>
using namespace std;

// 494.目标和




int main() {

    //
    class Solution {
    public:
        int findTargetSumWays(vector<int>& nums, int target) {
            int sum = 0;
            for (int i = 0; i < nums.size(); i++) sum += nums[i];
            if (abs(target) > sum) return 0; // 此时没有方案,给的目标值比所有元素的和都大，注意元素都是非负整数，那肯定没有方案
            if ((target + sum) % 2 == 1) return 0; // 此时没有方案。也就是说要分出来的子集的和不能被2整除，因为要分出来两个子集，且和相等
            int bagSize = (target + sum) / 2;
            vector<int> dp(bagSize + 1, 0);
            dp[0] = 1;
            for (int i = 0; i < nums.size(); i++) {
                for (int j = bagSize; j >= nums[i]; j--) {
                    dp[j] += dp[j - nums[i]];
                }
            }
            return dp[bagSize];
        }
    };


    return 0;

}