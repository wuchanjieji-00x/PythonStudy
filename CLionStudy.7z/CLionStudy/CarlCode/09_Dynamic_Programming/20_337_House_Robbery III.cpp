
using namespace std;

// 337.打家劫舍 III

 // Definition for a binary tree node.
  struct TreeNode {
      int val;
      TreeNode *left;
      TreeNode *right;
      TreeNode() : val(0), left(nullptr), right(nullptr) {}
      TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
      TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 };
 


int main() {

    // 动态规划
    // 时间复杂度: O(n)
    // 空间复杂度: O(n)
    class Solution {
    public:
        int rob(vector<int>& nums)  {
            if (nums.size() == 0) return 0;
            if (nums.size() == 1) return nums[0];
            if (nums.size() == 2) return max(nums[0], nums[1]);
            vector<int> dp(nums,size());
            dp[0] = nums[0];
            dp[1] = max (nums[0], nums[1]);
            for (int i = 2; i < nums.size(); i++) {
                dp[i] = max(dp[i - 2] + nums[i], dp[i - 1]);
            } 
            return dp[nums.size() - 1];
        }
    };


    // 暴力递归
    class Solution {
    public:
        int rob(TreeNode* root) {
            if (root == NULL) return 0;
            if (root->left == NULL && root->right == NULL) return root->val;
            // 偷父节点
            int val1 = root->val;
            if (root->left) val1 += rob(root->left->left) + rob(root->left->right); // 跳过root->left，相当于不考虑左孩子了
            if (root->right) val1 += rob(root->right->left) + rob(root->right->right); // 跳过root->right，相当于不考虑右孩子了
            // 不偷父节点
            int val2 = rob(root->left) + rob(root->right); // 考虑root的左右孩子
            return max(val1, val2);
        }
    };




    // 记忆化递推
    // 时间复杂度：O(n)
    // 空间复杂度：O(log n)，算上递推系统栈的空间
    class Solution {
    public:
        unordered_map<TreeNode* , int> umap; // 记录计算过的结果
        int rob(TreeNode* root) {
            if (root == NULL) return 0;
            if (root->left == NULL && root->right == NULL) return root->val;
            if (umap[root]) return umap[root]; // 如果umap里已经有记录则直接返回
            // 偷父节点
            int val1 = root->val;
            if (root->left) val1 += rob(root->left->left) + rob(root->left->right); // 跳过root->left
            if (root->right) val1 += rob(root->right->left) + rob(root->right->right); // 跳过root->right
            // 不偷父节点
            int val2 = rob(root->left) + rob(root->right); // 考虑root的左右孩子
            umap[root] = max(val1, val2); // umap记录一下结果
            return max(val1, val2);
        }
    };


    // 动态规划
    // 时间复杂度：O(n)，每个节点只遍历了一次
    // 空间复杂度：O(log n)，算上递推系统栈的空间
    class Solution {
    public:
        int rob(TreeNode* root) {
            vector<int> result = robTree(root);
            return max(result[0], result[1]);
        }
        // 长度为2的数组，0：不偷，1：偷
        vector<int> robTree(TreeNode* cur) {
            if (cur == NULL) return vector<int>{0, 0};
            vector<int> left = robTree(cur->left);
            vector<int> right = robTree(cur->right);
            // 偷cur，那么就不能偷左右节点。
            int val1 = cur->val + left[0] + right[0];
            // 不偷cur，那么可以偷也可以不偷左右节点，则取较大的情况
            int val2 = max(left[0], left[1]) + max(right[0], right[1]);
            return {val2, val1};
        }
    };






    return 0;

}