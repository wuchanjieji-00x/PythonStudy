

#include <vector>
using namespace std;

// 1049.最后一块石头的重量II

// 本题其实就是尽量让石头分成重量相同的两堆，相撞之后剩下的石头最小，这样就化解成01背包问题了。
// 那我们可以尝试将这些石头分成来重量尽量相同的两堆。我们取tarfet=sum/2
// 如果sum是偶数，那么我们取出的和剩下的重量相等，如果是奇数，那我们取出的石头重量一定小于剩下的石头重量
// 那么问题抽象为我们要取出尽量接近于sum/2重量的石头，可以取多少个
// 问题抽象为01背包问题
// 石头就是物品，石头的重量就是物品的重量，也是物品的价值
// 我们要从数组里取元素，填满承重为sum/2的背包，计算其最大价值，也即dp[target]


int main() {

    //
    // 时间复杂度：O(m × n) , m是石头总重量（准确的说是总重量的一半），n为石头块数
    // 空间复杂度：O(m)
    class Solution {
    public:
        int lastStoneWeightII(vector<int>& stones) {
            vector<int> dp(15001, 0); // 物品0-i填满承重为sum/2的背包所能获得的最大价值
            int sum = 0;
            for (int i = 0; i < stones.size(); i++) sum += stones[i];
            int target = sum / 2;  // dp数组的最后一个元素的下标
            for (int i = 0; i < stones.size(); i++) {
                for (int j = target; j >= stones[i]; j--) {
                    dp[j] = max(dp[j], dp[j - stones[i]] + stones[i]);
                }
            }

            return sum - dp[target] - dp[target]; // 相撞之后的值 = 剩余石头的重量 - 我们背包取出的石头的重量
            // 因为target是向下取整，所以肯定小于等于sum - target
        }
    };








    return 0;

}
