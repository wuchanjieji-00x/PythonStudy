#include <climits>
#include <vector>
using namespace std;

// 377. 组合总和 Ⅳ




int main() {

    //
    class Solution {
    public:
        int combinationSum4(vector<int>& nums, int target) {
            vector<int> dp(target + 1, 0);
            dp[0] = 1;
            for (int i = 0; i <= target; i++) { // 遍历背包
                for (int j = 0; j < nums.size(); j++) { // 遍历物品
                    if (i - nums[j] >= 0 && dp[i] < INT_MAX - dp[i - nums[j]]) {
                        dp[i] += dp[i - nums[j]];
                    }
                }
            }
            return dp[target];
        }
    };








    return 0;

}
