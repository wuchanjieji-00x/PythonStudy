
using namespace std;

// 123.买卖股票的最佳时机III
// 最多可以完成 两笔 交易。
// 注意：你不能同时参与多笔交易（你必须在再次购买前出售掉之前的股票）。



/*  画一张时序图就明白了
下面的情况分析和状态定义也是遵循了时序图的顺序
dp[i][0]: 不操作（状态一）
          这个状态是从prices[0]开始，到发生第一次买入股票动作的前一天  

dp[i][1]: 达到第一次持有股票状态（状态二）   并不是说 第i天一定买入股票，有可能 第 i-1天 就买入了，那么 dp[i][1] 延续买入股票的这个状态。
          要么延续昨天的状态，要么今天第一次买入股票，取二者max
          情况1：第i天发生第一次买入股票的动作，那么dp[i][1] = dp[i-1][0] - prices[i] ，这可以理解为第一次买入股票
          情况2：第i天没有操作，而是沿用前一天第一次持有股票的状态，那么前一天肯定是第一次买入股票的状态，即：dp[i][1] = dp[i - 1][1]，也就是说第一次买入股票发生在第i天之前，我们只是延续了这个状态。

dp[i][2]: 达到第一次不持有股票状态（状态三）
          要么延续昨天的状态，要么今天第一次卖出股票，取二者max
          情况1：第i天发生第一次卖出股票的动作，那么前一天的状态肯定是第一次持有股票的状态，那么dp[i][2] = dp[i-1][1] + prices[i] ，这可以理解为第一次卖出股票
          情况2：第i天没有操作，而是沿用前一天第一次卖出股票的状态，即：dp[i][2] = dp[i - 1][2]，也就是说第一次卖出股票发生在第i天之前，我们只是延续了这个状态。
          

dp[i][3]: 达到第二次持有股票状态（状态四）
          要么延续昨天的状态，要么今天第二次买入股票，取二者max
          情况1：第i天发生第二次买入股票的动作，那么前一天肯定是第一次不持有股票的状态，那么dp[i][3]=dp[i-1][2] - prices[i]
          情况2：第i天没有操作，第二次买入股票的动作已经发生过了，那么第i天的前一天肯定是第二次持有股票的状态，那么 dp[i][3] = dp[i-1][3]

dp[i][4]: 达到第一次不持有股票状态（状态五）
          要么延续昨天的状态，要么今天第二次卖出股票，取二者max
          情况1：第i天发生第二次卖出股票的动作，那么前一天肯定是第二次持有股票的状态，那么dp[i][4]=dp[i-1][3] + prices[i]
          情况2：第i天没有操作，第二次卖出股票的动作已经发生过了，那么第i天的前一天肯定是第二次不持有股票的状态，那么 dp[i][4] = dp[i-1][4]
 
*/


int main() {

    //
    // 版本一
    // 时间复杂度：O(n)
    // 空间复杂度：O(n × 5)
    class Solution {
    public:
        int maxProfit(vector<int>& prices) {
            if (prices.size() == 0) return 0;
            vector<vector<int>> dp(prices.size(), vector<int>(5, 0)); // 每个元素对应的状态有5个，全部初始化为0
            dp[0][1] = -prices[0]; // 这里只需要初始化第一次买入状态和第二次买入状态，其他的状态都可以初始化为0，不用重复初始化了
            dp[0][3] = -prices[0];
            for (int i = 1; i < prices.size(); i++) {
                dp[i][0] = dp[i - 1][0];
                dp[i][1] = max(dp[i - 1][1], dp[i - 1][0] - prices[i]);
                dp[i][2] = max(dp[i - 1][2], dp[i - 1][1] + prices[i]);
                dp[i][3] = max(dp[i - 1][3], dp[i - 1][2] - prices[i]);
                dp[i][4] = max(dp[i - 1][4], dp[i - 1][3] + prices[i]);
            }
            return dp[prices.size() - 1][4];
        }
    };



    // 力扣空间优化
    // 版本二
    // 时间复杂度：O(n)
    // 空间复杂度：O(1)
    class Solution {
    public:
        int maxProfit(vector<int>& prices) {
            if (prices.size() == 0) return 0;
            vector<int> dp(5, 0);
            dp[1] = -prices[0];
            dp[3] = -prices[0];
            for (int i = 1; i < prices.size(); i++) {
                dp[1] = max(dp[1], dp[0] - prices[i]);
                dp[2] = max(dp[2], dp[1] + prices[i]);
                dp[3] = max(dp[3], dp[2] - prices[i]);
                dp[4] = max(dp[4], dp[3] + prices[i]);
            }
            return dp[4];
        }
    };





    // 其实我们可以不设置，‘0. 没有操作’ 这个状态，因为没有操作，手上的现金自然就是0
    // 版本三 
    class Solution {
    public:
        int maxProfit(vector<int>& prices) {
            if (prices.size() == 0) return 0;
            vector<vector<int>> dp(prices.size(), vector<int>(5, 0));
            dp[0][1] = -prices[0];
            dp[0][3] = -prices[0];
            for (int i = 1; i < prices.size(); i++) {
                dp[i][1] = max(dp[i - 1][1], 0 - prices[i]);
                dp[i][2] = max(dp[i - 1][2], dp[i - 1][1] + prices[i]);
                dp[i][3] = max(dp[i - 1][3], dp[i - 1][2] - prices[i]);
                dp[i][4] = max(dp[i - 1][4], dp[i - 1][3] + prices[i]);
            }
            return dp[prices.size() - 1][4];
        }
    };








    return 0;

}