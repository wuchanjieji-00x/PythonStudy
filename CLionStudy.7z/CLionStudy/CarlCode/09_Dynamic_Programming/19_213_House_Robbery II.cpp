
using namespace std;

// 213.打家劫舍II




int main() {

    //
    // 注意注释中的情况二情况三，以及把198.打家劫舍的代码抽离出来了
    // 时间复杂度: O(n)
    // 空间复杂度: O(n)
    class Solution {
    public:
        int rob(vector<int>& nums) {
            if (nums.size() == 0) return 0;
            if (nums.size() == 1) return nums[0];
            int result1 = robRange(nums, 0, nums.size() - 2); // 情况二
            int result2 = robRange(nums, 1, nums.size() - 1); // 情况三
            return max(result1, result2);
        }
        // 198.打家劫舍的逻辑
        int robRange(vector<int>& nums, int start, int end) {
            if (end == start) return nums[start];
            vector<int> dp(nums.size());
            dp[start] = nums[start];
            dp[start + 1] = max(nums[start], nums[start + 1]);
            for (int i = start + 2; i <= end; i++) {
                dp[i] = max(dp[i - 2] + nums[i], dp[i - 1]);
            }
            return dp[end];
        }
    };







    return 0;

}
