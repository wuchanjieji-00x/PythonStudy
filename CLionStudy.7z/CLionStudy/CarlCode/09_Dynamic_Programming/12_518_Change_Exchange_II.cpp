#include <vector>
using namespace std;

// 518.零钱兑换II




int main() {

    //
    class Solution {
    public:
        int change(int amount, vector<int>& coins) {
            vector<int> dp(amount + 1, 0);
            dp[0] = 1;
            for (int i = 0; i < coins.size(); i++) { // 遍历物品
                for (int j = coins[i]; j <= amount; j++) { // 遍历背包
                    dp[j] += dp[j - coins[i]];
                }
            }
            return dp[amount];
        }
    };







    return 0;

}
