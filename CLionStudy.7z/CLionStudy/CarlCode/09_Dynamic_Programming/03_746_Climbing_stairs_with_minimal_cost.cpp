
#include <vector>
using namespace std;

// 746. 使用最小花费爬楼梯




int main() {

    // 版本1
    // 时间复杂度：O(n)
    // 空间复杂度：O(n)
    class Solution {
    public:
        int minCostClimbingStairs(vector<int>& cost) {
            vector<int> dp(cost.size() + 1);
            dp[0] = 0; // 默认第一步都是不花费体力的
            dp[1] = 0;
            for (int i = 2; i <= cost.size(); i++) {
                dp[i] = min(dp[i - 1] + cost[i - 1], dp[i - 2] + cost[i - 2]);
            }
            return dp[cost.size()];
        }
    };



    // 优化空间复杂度，因为dp[i]就是由前两位推出来的，那么也不用dp数组了
    // 版本2
    // 时间复杂度：O(n)
    // 空间复杂度：O(1)
    class Solution {
    public:
        int minCostClimbingStairs(vector<int>& cost) {
            int dp0 = 0;
            int dp1 = 0;
            for (int i = 2; i <= cost.size(); i++) {
                int dpi = min(dp1 + cost[i - 1], dp0 + cost[i - 2]);
                dp0 = dp1; // 记录一下前两位
                dp1 = dpi;
            }
            return dp1;
        }
    };





    return 0;

}
