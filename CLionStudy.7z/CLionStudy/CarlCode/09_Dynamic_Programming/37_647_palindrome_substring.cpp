
using namespace std;


// 647. 回文子串
// 元素连续



int main() {


    // 动规
    // 时间复杂度：O(n^2)
    // 空间复杂度：O(n^2)
    class Solution {
    public:
        int countSubstrings(string s) {
            vector<vector<bool>> dp(s.size(), vector<bool>(s.size(), false));
            int result = 0;
            for (int i = s.size() - 1; i >= 0; i--) {  // 注意遍历顺序
                for (int j = i; j < s.size(); j++) {
                    if (s[i] == s[j]) {
                        if (j - i <= 1) { // 情况一 和 情况二
                            result++;
                            dp[i][j] = true;
                        } else if (dp[i + 1][j - 1]) { // 情况三
                            result++;
                            dp[i][j] = true;
                        }
                    }
                }
            }
            return result;
        }
    };


    // 优化版
    // 时间复杂度：O(n^2)
    // 空间复杂度：O(n^2)
    class Solution {
    public:
        int countSubstrings(string s) {
            vector<vector<bool>> dp(s.size(), vector<bool>(s.size(), false));
            int result = 0;
            for (int i = s.size() - 1; i >= 0; i--) {
                for (int j = i; j < s.size(); j++) {
                    if (s[i] == s[j] && (j - i <= 1 || dp[i + 1][j - 1])) {
                        result++;
                        dp[i][j] = true;
                    }
                }
            }
            return result;
        }
    };



    // 动态规划的空间复杂度是偏高的，我们再看一下双指针法。
    // 时间复杂度：O(n^2)
    // 空间复杂度：O(1)
    class Solution {
    public:
        int countSubstrings(string s) {
            int result = 0;
            for (int i = 0; i < s.size(); i++) {
                result += extend(s, i, i, s.size()); // 以i为中心
                result += extend(s, i, i + 1, s.size()); // 以i和i+1为中心
            }
            return result;
        }
        int extend(const string& s, int i, int j, int n) {
            int res = 0;
            while (i >= 0 && j < n && s[i] == s[j]) {
                i--;
                j++;
                res++;
            }
            return res;
        }
    };






    return 0;

}