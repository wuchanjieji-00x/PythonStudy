
#include <vector>
using namespace std;

// 62.不同路径




int main() {

    // 图论：深搜
    // 机器人走过的路径可以抽象为一棵二叉树，而叶子节点就是终点！
    // 此时问题就可以转化为求二叉树叶子节点的个数
    // 深搜当然是超时了，顺便分析了一下使用深搜的时间复杂度，就可以看出为什么超时了。
    class Solution {
    private:
        int dfs(int i, int j, int m, int n) {
            if (i > m || j > n) return 0; // 越界了
            if (i == m && j == n) return 1; // 找到一种方法，相当于找到了叶子节点
            return dfs(i + 1, j, m, n) + dfs(i, j + 1, m, n);
        }
    public:
        int uniquePaths(int m, int n) {
            return dfs(1, 1, m, n);
        }
    };




    // 动规：版本1，二维数组
    // 时间复杂度：O(m × n)
    // 空间复杂度：O(m × n)
    class Solution {
    public:
        int uniquePaths(int m, int n) {
            vector<vector<int>> dp(m, vector<int>(n, 0));
            // 初始化m=0,n=0的情况
            for (int i = 0; i < m; i++) dp[i][0] = 1;
            for (int j = 0; j < n; j++) dp[0][j] = 1;
            // m和n都是从1开始遍历
            // 从左到右，从上到下
            for (int i = 1; i < m; i++) {
                for (int j = 1; j < n; j++) {
                    dp[i][j] = dp[i - 1][j] + dp[i][j - 1]; // 递推方程，状态转移方程
                }
            }
            return dp[m - 1][n - 1]; // 我们是把start点认为是[0,0]
        }
    };

    // 动规：版本2，一维数组
    class Solution {
    public:
        int uniquePaths(int m, int n) {
            vector<int> dp(n);
            for (int i = 0; i < n; i++) dp[i] = 1;
            for (int j = 1; j < m; j++) {
                for (int i = 1; i < n; i++) {
                    dp[i] += dp[i - 1];
                }
            }
            return dp[n - 1];
        }
    };




    // 数论
    // 时间复杂度：O(m)
    // 空间复杂度：O(1)
    class Solution {
    public:
        int uniquePaths(int m, int n) {
            long long numerator = 1; // 分子
            int denominator = m - 1; // 分母
            int count = m - 1;
            int t = m + n - 2;
            while (count--) {
                numerator *= (t--);
                while (denominator != 0 && numerator % denominator == 0) {
                    numerator /= denominator;
                    denominator--;
                }
            }
            return numerator;
        }
    };







    return 0;

}
