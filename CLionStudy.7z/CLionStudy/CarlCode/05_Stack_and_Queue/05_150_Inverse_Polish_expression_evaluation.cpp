// #include "iostream"
// #include <vector>
// #include <stack>
//
// using namespace std;
//
// // 150. 逆波兰表达式求值
// // 逆波兰表达式：是一种后缀表达式，所谓后缀就是指运算符写在后面。  RPN（后缀表达式）
// // 平常使用的算式则是一种中缀表达式，如 ( 1 + 2 ) * ( 3 + 4 ) 。
// // 该算式的逆波兰表达式写法为 1 2 + 3 4 + *
// // 思路：适合用栈操作运算：遇到数字则入栈；遇到运算符则取出栈顶两个数字进行计算，并将结果压入栈中
//
// // 其实逆波兰表达式相当于是二叉树中的后序遍历。大家可以把运算符作为中间节点，按照后序遍历的规则画出一个二叉树
//
//
//
// int main() {
//
//     // 解法1：
//     // 时间复杂度: O(n)
//     // 空间复杂度: O(n)
//     class Solution {
//     public:
//         int evalPRN(vector<string>& tokens) { // 通常情况下，"tokens" 是一个用于存储被分割或拆分后的字符串的容器
//             // RPN（后缀表达式）
//             // 力扣修改了后台测试数据，需要用longlong
//             stack<long long> stk;
//             for (int i = 0; i < tokens.size(); i++) {
//                 if (tokens[i] == "+" || tokens[i] == "-" || tokens[i] == "*" || tokens[i] == "/") {
//                     long long num1 = stk.top();
//                     stk.pop();
//                     long long num2 = stk.top();
//                     stk.pop();
//                     if (tokens[i] == "+") stk.push(num2 + num1);  // 注意这里的运算顺序，栈顶元素在操作符右侧
//                     if (tokens[i] == "-") stk.push(num2 - num1);
//                     if (tokens[i] == "*") stk.push(num2 * num1);
//                     if (tokens[i] == "/") stk.push(num2 / num1);
//                 }else {
//                     stk.push(stoll(tokens[i])); // C++的标准函数stoll来将字符串转换为长整型
//                 }
//
//             }
//             int ans = stk.top(); // 栈里只有一个元素，就是最终结果
//             stk.pop(); // 手动释放内存。把栈里最后一个元素弹出（其实不弹出也没事)
//             return ans;
//         }
//
//     };
//
//
//
//
//
//
//
//
//     return 0;
//
// }