// #include "iostream"
// #include <queue>
//
// using namespace std;
//
// // 225. 用队列实现栈
//
//
//
//
// int main() {
//
//     // 解法1：用一个queue模拟stack
//     // 时间复杂度: pop为O(n)，其他为O(1)
//     // 空间复杂度: O(n)
//     class MyStack {
//     public:
//         queue<int> que;
//
//         /** Initialize your data structure here. */
//         MyStack() {
//
//         }
//
//         /** Push element x onto stack. */
//         void push(int x) {
//             que.push(x);
//         }
//
//         /** Removes the element on top of the stack and returns that element. */
//         int pop() {
//             int size = que.size();
//             size--;   // 最后一个元素的下标
//             // 将queue最后一个元素之前（不包括最后一个元素）的元素全部出队，然后在队尾依次入队，这样队首元素就是模拟栈的栈顶元素
//             while (size--) { // 将队列头部的元素（除了最后一个元素外） 重新添加到队列尾部
//                 que.push(que.front());
//                 que.pop();
//             }
//             int ans = que.front(); // 此时弹出的元素顺序就是栈的顺序了
//             que.pop();  // 这里执行的是模拟栈的pop操作，所以用变量接收模拟栈栈顶元素之后，将其弹出
//             return ans;
//         }
//
//         /* Get the top element.
//          * Can not use back() directly.
//          */
//         int top() {
//             int size = que.size();
//             size--;
//             while (size--) {
//                 que.push(que.front());
//                 que.pop();
//             }
//             int ans = que.front(); // 用变量接收模拟栈栈顶元素
//             que.push(que.front()); // 将获取完的元素也重新添加到队列尾部，保证数据结构没有变化
//             que.pop(); // 弹出模拟栈栈顶元素，保证数据结构没有变化
//             return ans;
//         }
//
//         bool empty() {
//             return que.empty();
//         }
//
//     };
//
//
//
//
//
//
//
//
//
//     return 0;
//
// }