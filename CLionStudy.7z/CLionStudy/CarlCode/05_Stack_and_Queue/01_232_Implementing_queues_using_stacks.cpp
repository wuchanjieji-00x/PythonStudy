// #include "iostream"
// #include <stack>
//
// using namespace std;
//
// // 232.用栈实现队列
//
//
//
//
// int main() {
//
//     // 解法1：用两个栈：一个输入栈，一个输出栈，模拟队列
//     // 时间复杂度: push和empty为O(1), pop和peek为O(n)
//     // 空间复杂度: O(n)
//     class MyQueue {
//     public:
//         stack<int> stIn;
//         stack<int> stOut;
//
//         /** Initialize your data structure here. */
//         // 构造函数，初始化用
//         MyQueue(){
//
//         }
//
//         // push(x) -- 将一个元素放入队列的尾部。
//         // 用栈模拟队列的push操作
//         /** Push element x to the back of queue. */
//         void push(int x) {
//             stIn.push(x);
//         }
//
//         // pop() -- 从队列首部移除元素
//         // 用栈实现队列的pop操作
//         /** Removes the element from in front of queue and returns that element. */
//         int pop() {
//             // 只有当stOut为空的时候，再从stIn里导入数据（导入stIn全部数据）
//             if (stOut.empty()) {
//                 while(!stIn.empty()) {
//                     stOut.push(stIn.top());
//                     stIn.pop();
//                 }
//             }
//
//             int result = stOut.top(); // 如果stOut不为空，直接从stOut里弹出栈顶元素，直至stOut为空，再将stIn的元素全部导入stOut
//             stOut.pop(); // 因为这里执行的是pop操作，所以用变量接收栈顶元素并返回出去之后，要弹出栈顶元素，不保留在栈里
//             return result;
//         }
//
//         // peek() -- 返回队列首部的元素。
//         // 用栈模拟队列的peek操作
//         /** Get the front element. */
//         int peek() {
//             int ans = this->pop(); // 直接使用已有的pop函数
//             stOut.push(ans); // 这里执行的是peek操作，只读栈顶元素，所以要将弹出的栈顶元素重新压入stOut
//             return ans;
//
//         }
//
//         // empty() -- 返回队列是否为空。
//         // 用栈模拟队列的Empty操作
//         bool empty() {
//             return stIn.empty() && stOut.empty(); // 两个模拟栈都为空，实际的queue才为空
//         }
//
//     };
//
//     return 0;
//
// }