// #include "iostream"
// #include <vector>
// #include <unordered_map>
// #include <queue>
//
//
// using namespace std;
//
// // 347.前 K 个高频元素
// // 思路：首先统计元素出现的频率，这一类的问题可以使用map来进行统计
// // 然后是对频率进行排序，这里我们可以使用一种容器适配器就是优先级队列。
//
//
//
//
// int main() {
//
//     // 解法1：用小顶堆，因为要统计最大前k个元素，只有小顶堆每次将最小的元素弹出，最后小顶堆里积累的才是前k个最大元素
//     class Solution {
//     public:
//         // 小顶堆：左大于右就会建立小顶堆
//         class myComparion {
//         public:
//             bool operator()(const pair<int, int>& lhs, const pair<int, int>& rhs) {
//                 // 这里的second指的是键值对的第二个元素，value，记录的是元素出现的频率。
//                 // 我们是按照频率来排序的，所以是第二个元素，也就是value，降序排列
//                 return lhs.second > rhs.second;
//             }
//         };
//
//         vector<int> topKFrequent(vector<int>& nums, int k) {
//             unordered_map<int, int> umap;
//             // 统计每个元素出现的频率
//             for ( int i = 0; i < nums.size(); ++i) {
//                 umap[nums[i]]++; // 生成键值对，并累加value(频率)
//             }
//
//             // 对频率排序
//             // 定义一个小顶堆，大小为k
//             priority_queue<pair<int, int>, vector<pair<int, int>>, myComparion> pq;
//
//             // 用固定大小为k的小顶堆，扫面所有频率的数值
//             for (unordered_map<int, int> :: iterator it = umap.begin(); it != umap.end(); ++it) {
//                 pq.push(*it); // it是个指针变量
//                 if (pq.size() > k) { // 如果堆的大小大于了K，则队列弹出，保证堆的大小一直为k
//                     pq.pop();
//                 }
//             }
//
//             // 找出前K个高频元素，因为小顶堆先弹出的是最小的，所以倒序来输出到数组
//             vector<int> ans(k);
//             for (int i = k - 1; i >= 0; --i) {
//                     ans[i] = pq.top().first; // 我们存入队列的是键值对，我们只需要返回前K个高频的元素（键），即键值对的第一个元素
//                     pq.pop();
//             }
//             return ans;
//
//         }
//     };
//
//
//
//
//
//
//
//
//     return 0;
//
// }
