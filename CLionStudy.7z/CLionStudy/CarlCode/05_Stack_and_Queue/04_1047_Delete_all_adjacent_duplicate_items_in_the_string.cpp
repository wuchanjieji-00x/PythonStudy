// #include "iostream"
// #include <stack>
// #include <algorithm>
//
// using namespace std;
//
// // 1047. 删除字符串中的所有相邻重复项
//
// // stack的经典问题
//
//
//
//
// int main() {
//
//     // 解法1：
//     // 时间复杂度: O(n)
//     // 空间复杂度: O(n),主要是pop操作
//     class SOlution {
//     public:
//         string removeDuplicates(string s) {
//             stack <char> st; // 创建一个栈容器适配器用于接收遍历过的字符
//             for (char ch : s) { // 遍历字符串
//                 if (st.empty() || ch != st.top()) { // 如果栈为空栈，或者，当前遍历的字符和栈顶元素不相等，
//                     st.push(ch); // 则将当前遍历的字符入栈
//                 }else { // 否则，栈顶元素和当前遍历的字符相等，则将栈顶元素出栈
//                     st.pop();
//                 }
//             }
//
//             string ans = ""; // 创建一个字符串容器，用于存储最终结果
//             // 遍历栈，将栈顶元素添加到字符串容器中，然后出栈
//             // 将栈中元素放到ans字符串汇总
//             while (!st.empty()) { // 防止字符串的元素全部都是相邻相同元素，那么最后栈是空的，如：aabbccc
//                 ans += st.top();
//                 st.pop(); // 实际出栈
//             }
//
//             // 因为从栈里弹出的元素是倒序的,此时字符串需要反转一下
//             reverse(ans.begin(), ans.end());
//             return ans;
//         }
//
//     };
//
//
//     // 解法2：当然可以拿字符串直接作为栈，这样省去了栈还要转为字符串的操作。
//     // 时间复杂度: O(n)
//     // 空间复杂度: O(1)，返回值不计空间复杂度
//     class Solution {
//     public:
//         string removeDuplicates(string s) {
//             string ans;
//             for (char ch : s) {
//                 if (ans.empty() || ch != ans.back()){
//                     ans.push_back(ch); // 记得这里是在字符串后方加入字符，不是在栈中加入字符
//                 }else {
//                     ans.pop_back();
//                 }
//             }
//             return ans;
//         }
//
//     };
//
//
//     return 0;
//
// }