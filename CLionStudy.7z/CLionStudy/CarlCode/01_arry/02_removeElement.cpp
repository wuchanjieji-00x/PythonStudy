// #include "iostream"
// #include <vector>
// using namespace std;
//
//
//
//
//
//
// int main() {
//
//     // // 解法1：暴力解法：
//     // // 时间复杂度：O(n^2); 空间复杂度：O(1)
//     // // 这个题目暴力的解法就是两层for循环，一个for循环遍历数组元素 ，第二个for循环更新数组。
//     // class Solution {
//     // public:
//     //     int removeElement(vector<int>& nums, int val) {
//     //         int size = nums.size();
//     //         for (int i = 0; i < size; i++) { // 遍历数组元素
//     //             if (nums[i] == val) { // 发现需要移除的元素，就将其后面的数组元素集体向前移动一位
//     //                 for (int j = i +1; j < size; j++) {
//     //                     nums[j - 1] = nums[j];
//     //                 }
//     //             }
//     //             i--; // 因为下标i以后的数值都向前移动了一位，所以i也向前移动一位
//     //             size--; // 此时数组的大小-1
//     //         }
//     //         return size;
//     //     }
//     // };
//
//
//     // // 解法2：双指针法：
//     // // 时间复杂度：O(n); 空间复杂度：O(1)
//     // // 这个题目的双指针解法就是两个指针，一个指针指向当前需要移除的元素，另一个指针指向当前需要移动的元素。
//     // // 当需要移除的元素和需要移动的元素相等时，将需要移除的元素向后移动一位，当需要移除的元素和需要移动的元素不相等时，将需要移除的元素和需要移动的元素交换位置。
//     // class Solution {
//     // public:
//     //     int removeElement(vector<int>& nums, int val) {
//     //         int slowIndex = 0;
//     //         for (int fastIndex = 0; fastIndex < nums.size(); fastIndex++) {
//     //             if (val != nums[fastIndex]) {
//     //                 nums[slowIndex++] = nums[fastIndex]; // 先赋值，后递增
//     //             }
//     //         }
//     //         return slowIndex;
//     //     }
//     // };
//
//
//
//     // // 解法3：库函数 vector.erase()
//     // class Solution {
//     // public:
//     //     int removeElement(vector<int>& nums, int val) {
//     //         nums.erase(remove(nums.begin(), nums.end(), val), nums.end());
//     //         return nums.size();
//     //     }
//     // };
//     // // 解法3.1
//     // class Solution {
//     // public:
//     //     int removeElement(vector<int>&nums , int val) {
//     //         int size = nums.size();
//     //         for (int i = 0; i < size; i++) {
//     //             if (nums[i] == val) {
//     //                 nums.erase(nums.begin() + i);
//     //                 size--;
//     //             }
//     //         }
//     //            return size;
//     //     }
//     // };
//
//
//     // 测试：
//     Solution s1;
//     vector<int> v1 = {0, 1, 2, 3, 3, 0, 4, 2};
//     int newSize = s1.removeElement(v1, 3);
//     cout << newSize << endl;
//
//
//
//
//
//
//
//
//     return 0;
//
// }