// #include "iostream"
// #include <vector>
// using namespace std;
//
//
// // 这道题目的前提是数组为有序数组，同时题目还强调数组中无重复元素，
// // 因为一旦有重复元素，使用二分查找法返回的元素下标可能不是唯一的，这些都是使用二分法的前提条件，
// // 当大家看到题目描述满足如上条件的时候，可要想一想是不是可以用二分法了。
//
//
//
//
// int main() {
//
//
//     // 方法1: 左闭右闭[left,right] 循环不变量
//     class Solution {
//     public:
//         int search(vector<int>& nums, int target) {
//             int left = 0;
//             int right = nums.size() - 1; // 定义target在左闭右闭的区间里，[left, right]
//
//             while (left <= right) { // 当left==right，区间[left, right]依然有效，所以用 <=
//                 int middle = left + ((right - left) / 2); // 防止溢出 等同于(left + right)/2
//                 if (nums[middle] > target) {
//                     right = middle - 1; // target 在左区间，所以[left, middle - 1]
//                 }else if(nums[middle] < target) {
//                     left = middle + 1; // target 在右区间，所以[middle + 1, right]
//                 }else { // nums[middle] == target
//                     return middle; // 数组中找到目标值，直接返回下标
//                 }
//             }
//             return -1; // 未找到目标值
//         }
//     };
//
//     // 测试
//     Solution s1;  // 创建解决方案实例
//     vector<int> vector1 = {1,2,3,4,5};  // 声明并初始化一个升序排列的向量
//     int target_index = s1.search(vector1, 5); // 使用search方法查找目标值3的索引
//     cout << target_index << endl; // 输出目标值的索引
//
//
//     // // 方法2: 左闭右开[left,right) 循环不变量
//     // class Solution {
//     // public:
//     //     int search(vector<int>& nums, int target) {
//     //         int left = 0;
//     //         int right = nums.size();
//     //         while (left < right) {
//     //             int middle = left + ((right - left) / 2);
//     //             if (nums[middle] > target) {
//     //                 right = middle;
//     //             }else if (nums[middle] < target) {
//     //                 left = middle + 1;
//     //             }else {
//     //                 return middle;
//     //             }
//     //         }
//     //         return -1;
//     //     }
//     // };
//     //
//     // // 测试
//     // Solution s1;  // 创建解决方案实例
//     // vector<int> vector1 = {1,2,3,4,5};  // 声明并初始化一个升序排列的向量
//     // int target_index = s1.search(vector1, 5); // 使用search方法查找目标值3的索引
//     // cout << target_index << endl; // 输出目标值的索引
//
//
//     return 0;
//
// }
