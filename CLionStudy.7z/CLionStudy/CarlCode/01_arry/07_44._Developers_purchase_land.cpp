// #include "iostream"
// #include <vector>
// #include <climits>
//
// using namespace std;
//
//
//
//
//
//
// int main() {
//
//     // // 解法1：暴力解法：
//     // // 思路：前缀和的思路，先统计好，前n行的和 q[n]，如果要求矩阵 a行 到 b行 之间的总和，那么就 q[b] - q[a - 1]就好
//     // // 本题也可以使用 前缀和的思路来求解，先将 行方向，和 列方向的和求出来，这样可以方便知道划分的两个区间的和
//     // // 时间复杂度： O(n^2)
//     // int n, m;
//     // cin >> n >> m; // 接收用户输入的行数和列数
//     //
//     // int sum = 0;
//     // vector<vector<int>> vec(n, vector<int>(m, 0)); // 定义一个二维向量，接收每个单独区块的权值
//     //
//     // for (int i = 0; i < n; i++) {
//     //     for (int j = 0; j < m; j++) {
//     //         cin >> vec[i][j]; // 接收用户输入的每个单独区块的权值
//     //         sum += vec[i][j]; // 计算区块权值总和
//     //     }
//     // }
//     //
//     // // 统计横向
//     // vector<int> horizontal(n, 0);
//     // for (int i = 0; i < n; i++) {
//     //     for (int j = 0; j < m; j++) {
//     //         horizontal[i] += vec[i][j]; // 计算每一行的权值总和
//     //     }
//     // }
//     //
//     // // 统计纵向
//     // vector<int> vertical(m, 0);
//     // for (int j = 0; j < m; j++) {
//     //     for (int i = 0; i < n; i++) {
//     //         vertical[j] += vec[i][j]; // 计算每一列的权值总和
//     //     }
//     // }
//     //
//     // int result = INT_MAX; // 给最后的输出赋予最大值，因为题目要求最小值
//     // int horizontalCut = 0; // 横切线
//     // for (int i = 0; i < n; i++) {
//     //     horizontalCut += horizontal[i]; // 计算每一行的横切线
//     //     result = min(result, abs(sum - horizontalCut - horizontalCut)); // 计算横切线上方和下方（A和B）之间的差值
//     // } // 逐行的往下切，找到A和B区域权值总和之差的最小值
//     //
//     // int verticalCut = 0; // 纵切线
//     // for (int j = 0; j < m; j++) {
//     //     verticalCut += vertical[j]; // 计算每一列的纵切线
//     //     result = min (result, abs(sum - verticalCut - verticalCut)); // 计算纵切线上方和下方（A和B）之间的差值
//     // } // 找到遍历横切线找到的最小值之后，逐列的往右切，找到A和B区域权值总4和之差的最小值
//     // cout << result << endl;
//
//
//
//     // // 解法2：其实本题可以在暴力求解的基础上，优化一下，就不用前缀和了，
//     // // 在行向遍历的时候，遇到行末尾就统一一下， 在列向遍历的时候，遇到列末尾就统计一下。
//     // // 时间复杂度也是 O(n^2)
//     // int n, m;
//     // cin >> n >> m; // 接收用户输入的行数和列数
//     //
//     // int sum = 0;
//     // vector<vector<int>> vec(n, vector<int>(m, 0)); // 定义一个二维向量，接收每个单独区块的权值
//     //
//     // for (int i = 0; i < n; i++) {
//     //     for (int j = 0; j < m; j++) {
//     //         cin >> vec[i][j]; // 接收用户输入的每个单独区块的权值
//     //         sum += vec[i][j]; // 计算区块权值总和
//     //     }
//     // }
//     //
//     // int result = INT_MAX;
//     // int countI = 0; // 统计遍历过的行
//     // for (int i = 0; i < n; i++) {
//     //     for (int j = 0; j < m; j++) {
//     //         countI += vec[i][j]; // 累加每一行的权值
//     //         // 遍历到行末尾时候开始统计。因为这一行的下面就是横切线的一种可能
//     //         if (j == m - 1) {
//     //             result = min(result, abs(sum - countI - countI));
//     //         }
//     //     }
//     // }
//     //
//     // int countJ = 0; // 统计遍历过的列
//     // for (int j = 0; j < m; j++) {
//     //     for (int i = 0; i < n; i++) {
//     //         countJ += vec[i][j]; // 累加每一列的权值
//     //         // 遍历到列末尾时候开始统计。因为这一列的右边就是竖切线的一种可能
//     //         if (i == n - 1) {
//     //             result = min(result, abs(sum - countJ - countJ));
//     //         }
//     //     }
//     // }
//     //
//     // cout << result << endl;
//
//
//     //
//     // // 个人优化：在横切或竖切的时候，因为一定要分出两个都含有区块的区域，
//     // // 所以，横切线永远切不到最后一行，竖切线永远切不到最后一列，
//     // // 所以，在切的时候，i < n - 1 或 j < m - 1
//     int n, m;
//     cin >> n >> m; // 接收用户输入的行数和列数
//
//     int sum = 0;
//     vector<vector<int>> vec(n, vector<int>(m, 0)); // 定义一个二维向量，接收每个单独区块的权值
//
//     for (int i = 0; i < n; i++) {
//         for (int j = 0; j < m; j++) {
//             cin >> vec[i][j]; // 接收用户输入的每个单独区块的权值
//             sum += vec[i][j]; // 计算区块权值总和
//         }
//     }
//
//     int result = INT_MAX;
//     int countI = 0;
//     for (int i = 0; i < n - 1; i++) { // 优化点
//         for (int j = 0; j < m; j++) {
//             countI += vec[i][j];
//             if (j == m - 1) {
//                 result = min(result, abs(sum - countI - countI));
//             }
//         }
//     }
//
//     int countJ = 0;
//     for (int j = 0; j < m - 1; j++) { // 优化点
//         for (int i = 0; i < n; i++) {
//             countJ += vec[i][j];
//             if (i == n - 1) {
//                 result = min(result, abs(sum - countJ - countJ));
//             }
//         }
//     }
//
//     cout << result << endl;
//
//
//
//
//
//
//
//
//
//
//
//
//
//     // testcase
//     // input :3 3 1 2 3 2 1 3 1 2 3
//     // output : 0
//     // input: 4 4 1 2 3 6 2 1 3 6 3 1 2 6 1 2 3 6
//     // output: 0
//
//
//
//
//     return 0;
//
// }
