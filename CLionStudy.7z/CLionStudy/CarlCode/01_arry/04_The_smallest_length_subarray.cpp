// #include "iostream"
// #include <vector>
// #include <limits>
// #include <cstdint>
// using namespace std;
//
//
// // 209.长度最小的子数组
//
//
// int main() {
//
//     // // 解法1：暴力解法
//     // // 时间复杂度：O(n^2)  空间复杂度：O(1)
//     // // 思路：这道题目暴力解法当然是两个for循环，然后不断的寻找符合条件的子序列，时间复杂度很明显是O(n^2)
//     // class Solution {
//     // public:
//     //     int minSubArrayLen(int s, vector<int>& nums) {
//     //         int result = INT32_MAX; // 最终的结果  // INT32_MAX 是C++中的一个宏定义，表示有符号32位整数的最大值。
//     //         int sum = 0; // 子序列的数值之和
//     //         int subLength = 0; // 子序列的长度
//     //         for (int i = 0; i < nums.size(); i++) { // 设置子序列起点为i
//     //             sum = 0;
//     //             for (int j = i; j < nums.size(); j++) { // 设置子序列终止位置为j
//     //                 sum += nums[j];
//     //                 if (sum >= s) { // 一旦发现子序列和超过了s，更新result
//     //                     subLength = j - i + 1; // 取子序列的长度
//     //                     result = result < subLength ? result : subLength; // 取最小的子数组长度
//     //                     break; // 因为我们是找符合条件最短的子序列，所以一旦符合条件就break
//     //                 }
//     //             }
//     //         }
//     //         // 如果result没有被赋值的话，就返回0，说明没有符合条件的子序列
//     //         return result == INT32_MAX ? 0 : result;
//     //     }
//     // };
//
//
//
//     // // 解法2：滑动窗口，也可以叫做双指针法
//     // // 时间复杂度：O(n)  空间复杂度：O(1)
//     // // 思路：
//     // // 1. 设置两个指针，一个指向子序列的起始位置，一个指向子序列的终止位置。
//     // // 2. 移动终止指针，直到子序列的和大于等于s。
//     // // 3. 移动起始指针，直到子序列的和小于s。
//     // // 4. 重复步骤2和步骤3，直到终止指针到达数组末尾。
//     // // 滑动窗口的精妙之处在于根据当前子序列和大小的情况，不断调节子序列的起始位置。从而将O(n^2)暴力解法降为O(n)。
//     // class Solution {
//     // public:
//     //     int minSubArrayLen(int s, vector<int>& nums) {
//     //         int result = INT32_MAX;
//     //         int sum = 0;  // 滑动窗口数值之和
//     //         int i = 0;  // 滑动窗口起始位置
//     //         int subLength = 0; // 滑动窗口的长度
//     //
//     //         for (int j = 0; j < nums.size(); j++) {
//     //             sum += nums[j];
//     //             // 注意这里使用while，每次更新 i（起始位置），并不断比较子序列是否符合条件
//     //             while (sum >= s) {
//     //                 subLength = j - i + 1; // 取子序列的长度
//     //                 result = result < subLength ? result : subLength;
//     //                 sum -= nums[i++]; // 这里体现出滑动窗口的精髓之处，不断变更i（子序列的起始位置）
//     //             }
//     //         }
//     //         // 如果result没有被赋值的话，就返回0，说明没有符合条件的子序列
//     //         return result == INT32_MAX ? 0 : result;
//     //     }
//     // };
//
//
//     // test
//     Solution s1;
//     vector<int> v1 = {2, 3, 1, 2, 4, 3};
//     int subArraySize = s1.minSubArrayLen(7, v1);
//     cout << subArraySize << endl;
//
//     return 0;
//
// }
