// #include "iostream"
// #include <vector>
// #include <algorithm>
//
// using namespace std;
//
//
//
//
//
//
// int main() {
//
//     // // 解法1：暴力排序
//     // // 时间复杂度：O(nlogn) /  O(n + nlog n)
//     // // 最直观的想法，莫过于：每个数平方之后，排个序
//     // class Solution {
//     // public:
//     //     vector<int> sortedSquares(vector<int>& A) {
//     //         for (int i = 0; i < A.size(); i++) {
//     //             A[i] *= A[i];
//     //         }
//     //         sort(A.begin(), A.end());
//     //         return A;
//     //     }
//     // };
//
//
//     // // 解法2：双指针法
//     // // 时间复杂度：O(n)
//     // class Solution {
//     // public:
//     //     vector<int> sortedSquares(vector<int>& A) {
//     //         int k = A.size() - 1;
//     //         vector<int> result(A.size());
//     //         for (int i = 0, j = A.size() - 1; i <= j;) {  // 注意这里要i <= j，因为最后要处理两个元素(数组元素数目是奇数的情况)
//     //             if (A[i] * A[i] > A[j] * A[j]) {
//     //                 result[k--] = A[i] * A[i];
//     //                 i++;
//     //             } else {
//     //                 result[k--] = A[j] * A[j];
//     //                 j--;
//     //             }
//     //         }
//     //         return result;
//     //     }
//     // };
//
//
//
//
//
//
//     // test
//     Solution s1;
//     vector<int> v1 = {-7, -3, 2, 3, 11};
//     vector<int> newVec = s1.sortedSquares(v1);
//     for (int i = 0; i < newVec.size(); i++) {
//         cout << newVec[i] << " ";
//     }
//
//
//
//     return 0;
//
// }
