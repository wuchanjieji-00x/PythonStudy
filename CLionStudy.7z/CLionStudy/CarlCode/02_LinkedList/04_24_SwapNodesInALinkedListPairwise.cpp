// #include "iostream"
//
// using namespace std;
//
// // 24. 两两交换链表中的节点
// // 给定一个链表，两两交换其中相邻的节点，并返回交换后的链表
// // 你不能只是单纯的改变节点内部的值，而是需要实际的进行节点交换
//
//
//
//
// int main() {
//
//     // // 解法1：
//     // // 时间复杂度：O(n)
//     // // 空间复杂度：O(1)
//     // class Solution {
//     // public:
//     //     struct ListNode {
//     //         int val;
//     //         ListNode *next;
//     //         ListNode() : val(0), next(nullptr) {}
//     //         ListNode(int x) : val(x), next(nullptr) {}
//     //         ListNode(int x, ListNode *next) : val(x), next(next) {}
//     //     };
//     //     ListNode* swapPairs(ListNode* head) {
//     //         ListNode* dummyHead = new ListNode(0); // 设置一个虚拟头结点
//     //         dummyHead->next = head; // 将虚拟头结点指向head，这样方便后面做删除操作
//     //         ListNode* cur = dummyHead;
//     //
//     //         // 1.防止head是空 2.对于长度为偶数的链表，只遍历到最后一个元素；对于长度为奇数的链表，只遍历到倒数第二个元素
//     //         // while的判断条件：先判断cur->next != nullptr，为了防止cur->next为空时，再判断cur->next->next就会操作空指针了
//     //         while (cur->next != nullptr && cur->next->next != nullptr) {
//     //             ListNode* temp1 = cur->next;
//     //             ListNode* temp2 = cur->next->next->next;
//     //
//     //             cur->next = cur->next->next; // 按反转后的顺序串起链表
//     //             cur->next->next = temp1;
//     //             cur->next->next->next = temp2;
//     //         }
//     //         ListNode* result = dummyHead->next;
//     //         delete dummyHead;
//     //         return  result;
//     //     }
//     //
//     // };
//
//
//     // 解法2：解法1的优化版
//     class Solution {
//     public:
//         struct ListNode {
//             int val;
//             ListNode *next;
//             ListNode() : val(0), next(nullptr) {}
//             ListNode(int x) : val(x), next(nullptr) {}
//             ListNode(int x, ListNode *next) : val(x), next(next) {}
//         };
//         ListNode* swapPairs(ListNode* head) {
//             ListNode* dummyHead = new ListNode(0); // 设置一个虚拟头结点
//             dummyHead->next = head; // 将虚拟头结点指向head，这样方便后面做删除操作
//             ListNode* cur = dummyHead;
//
//             while (cur->next != nullptr && cur->next->next != nullptr) {
//                 // 操作链表节点时，要先把被操作的节点的左边的线的地址提前保存一下，否则就被孤立了
//                 ListNode* temp1 = cur->next; // 把地址提前给临时指针，后面可以任意操作内存地址
//                 ListNode* temp2 = cur->next->next;
//
//                 // 先串头尾，再串中间的
//                 cur->next = temp2;
//                 temp1->next = temp2->next;
//                 temp2->next = temp1;
//                 cur = temp1;
//
//             }
//             ListNode* ans = dummyHead->next; // 我们要返回的是head
//             delete dummyHead;
//             return ans;
//
//         }
//     };
//
//
//     return 0;
//
// }