// #include "iostream"
//
// struct ListNode;
// using namespace std;
//
// // 206.反转链表
//
// // 反转一个单链表
//
//
//
// int main() {
//
//     // 解法1：双指针法
//     // 时间复杂度: O(n)      空间复杂度: O(1)
//     class Solution {
//     public:
//         struct ListNode {
//             int val;
//             ListNode *next;
//             ListNode() : val(0), next(nullptr) {}
//             ListNode(int x) : val(x), next(nullptr) {}
//             ListNode(int x, ListNode *next) : val(x), next(next) {}
//         };
//         ListNode* reverseList(ListNode* head) {
//             ListNode* temp;  // 保存cur的下一个节点
//             ListNode* cur = head;
//             ListNode* pre = nullptr;
//
//             while(cur) {
//                 temp = cur->next; // 保存一下 cur的下一个节点，因为接下来要改变cur->next
//                 cur->next = pre; // 翻转操作
//                 // 更新pre 和 cur指针
//                 pre = cur;
//                 cur = temp;
//             }
//             return pre;
//         }
//     };
//
//
//     // // 解法2：递归
//     // // 时间复杂度: O(n), 要递归处理链表的每个节点
//     // // 空间复杂度: O(n), 递归调用了 n 层栈空间
//     // // 思路：递归法相对抽象一些，但是其实和双指针法是一样的逻辑，同样是当cur为空的时候循环结束，不断将cur指向pre的过程。
//     // class Solution {
//     // public:
//     //     struct ListNode {
//     //         int val;
//     //         ListNode *next;
//     //         ListNode() : val(0), next(nullptr) {}
//     //         ListNode(int x) : val(x), next(nullptr) {}
//     //         ListNode(int x, ListNode *next) : val(x), next(next) {}
//     //     };
//     //     ListNode* reverse(ListNode* pre, ListNode* cur) {
//     //         if (cur == nullptr) {
//     //             return pre;
//     //         }
//     //         ListNode* temp = cur->next;
//     //         cur->next = pre;
//     //         // 可以和双指针法的代码进行对比，如下递归的写法，其实就是做了这两步
//     //         // pre = cur;
//     //         // cur = temp;
//     //         return reverse(cur, temp);
//     //     }
//     //     ListNode* reverseList(ListNode* head) {
//     //         // 和双指针法初始化是一样的逻辑
//     //         // ListNode* cur = head;
//     //         // ListNode* pre = NULL;
//     //         return reverse(nullptr, head);
//     //     }
//     // };
//
//
// // // test
// //     // 打印链表
// //     void printListNode(){
// //         ListNode* cur = head;
// //         while (cur->next != nullptr) {
// //             cout << cur->next->val << " ";
// //             cur = cur->next;
// //         }
// //         cout << endl;
// //     }
// //
// //
// //     ListNode* obj = new ListNode(1,2,3,4,5);
// //     obj->printLinkedList()
//
//
//
//
//
//
//     return 0;
//
// }
