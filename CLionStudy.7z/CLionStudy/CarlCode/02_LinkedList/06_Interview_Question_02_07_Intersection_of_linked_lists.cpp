// #include "iostream"
//
// using namespace std;
//
// // 面试题 02.07. 链表相交
// // 同：160.链表相交
//
// // 给你两个单链表的头节点 headA 和 headB ，请你找出并返回两个单链表相交的起始节点。如果两个链表没有交点，返回 null 。
//
//
//
//
// int main() {
//
//     // 解法1：
//     // 时间复杂度：O(n + m)
//     // 空间复杂度：O(1)
//     class Solution {
//     public:
//         struct ListNode {
//             int val;
//             ListNode *next;
//             ListNode() : val(0), next(nullptr) {}
//             ListNode(int x) : val(x), next(nullptr) {}
//             ListNode(int x, ListNode *next) : val(x), next(next) {}
//         };
//         ListNode* getIntersectionNode(ListNode* headA, ListNode* headB) {
//             ListNode* curA = headA;
//             ListNode* curB = headB;
//
//             int lenA = 0, lenB = 0;
//             // 求链表A的长度
//             while (curA != nullptr) {
//                 lenA++;
//                 curA = curA->next;
//             }
//
//             // 求链表B的长度
//             while (curB != nullptr) {
//                 lenB++;
//                 curB = curB->next;
//             }
//
//             curA = headA;
//             curB = headB;
//
//             // 让curA为最长链表的头，lenA为最长链表的长度
//             if (lenB > lenA) {
//                 swap (lenA, lenB);
//                 swap(curA , curB);
//             }
//
//             // 让curA和curB在同一起点上（末尾位置对齐）
//             int gap = lenA - lenB;
//             while (gap--) {
//                 curA = curA->next;
//             }
//
//             // curA和curB同时遍历，直到找到 intersection
//             while (curA != nullptr) {
//                 if (curA == curB) {
//                     return curA;
//                 }
//                 curA = curA->next;
//                 curB = curB->next;
//             }
//
//             return nullptr;
//
//         }
//     };
//
//
//     // 解法2：进阶版双指针
//     // 时间复杂度：O(m+n)，其中 m 和 n 是分别是链表 headA 和 headB 的长度。两个指针同时遍历两个链表，每个指针遍历两个链表各一次。
//     // 空间复杂度：O(1)
//     // 思路和算法：见leetcode的官方题解。
//     class Solution {
//     public:
//         struct ListNode {
//             int val;
//             ListNode *next;
//             ListNode() : val(0), next(nullptr) {}
//             ListNode(int x) : val(x), next(nullptr) {}
//             ListNode(int x, ListNode *next) : val(x), next(next) {}
//         };
//         ListNode *getIntersectionNode(ListNode *headA, ListNode *headB) {
//             if (headA == nullptr || headB == nullptr) {
//                 return nullptr;
//             }
//             ListNode *pA = headA, *pB = headB;
//             while (pA != pB) {
//                 pA = pA == nullptr ? headB : pA->next;
//                 pB = pB == nullptr ? headA : pB->next;
//             }
//             return pA;
//         }
//     };
//
//
//
//
//
//
//
//
//
//
//
//     return 0;
//
// }