// #include "iostream"
//
// using namespace std;
//
// // 142.环形链表II
// // 判断链表是否环
// // 如果有环，如何找到这个环的入口
//
//
// //理解：快指针和慢指针之间最大的差距就是链表的长度，而慢指针是一步一步往前走，快指针是两步走，二者一起动一步，两者之间的距离就减去1，
// // 快指针最晚最晚是在慢指针刚刚转一圈回到起点的时候追上慢指针
// // 所以快指针追上慢指针的时候，慢指针走的长度不可能超过链表的长度
//
//
// int main() {
//
//     // // 解法1：双指针，快慢指针
//     // // 时间复杂度: O(n)，快慢指针相遇前，指针走的次数小于链表长度，快慢指针相遇后，两个index指针走的次数也小于链表长度，总体为走的次数小于 2n
//     // // 空间复杂度: O(1)
//     //
//     // // Definition for singly-linked list.
//     // struct ListNode {
//     //     int val;
//     //     ListNode *next;
//     //     ListNode(int x) : val(x), next(NULL) {}
//     // };
//     // class Solution {
//     // public:
//     //     ListNode *detectCycle(ListNode *head) {
//     //         ListNode* fast = head;
//     //         ListNode* slow = head;
//     //         while (fast != nullptr && fast->next != nullptr) {
//     //             slow = slow->next;
//     //             fast = fast->next->next;
//     //
//     //             // 快慢指针相遇，此时从head 和 相遇点，同时查找直至相遇
//     //             if (slow == fast) { // 是否有环
//     //                 ListNode* index1 = fast;
//     //                 ListNode* index2 = head;
//     //                 while (index1 != index2) {
//     //                     index1 = index1->next;
//     //                     index2 = index2->next;
//     //                 }
//     //                 return index1;  // 有环则返回环的入口的地址
//     //             }
//     //         }
//     //         return nullptr; // 没有环
//     //     }
//     // };
//
//
//
//     // 解法2：双指针，快慢指针,优化版
//     // 思路：从相遇点到入环点的距离加上 n−1 圈的环长，恰好等于从链表头部到入环点的距离。
//     // 因此，当发现 slow 与 fast 相遇时，我们再额外使用一个指针 ptr。起始，它指向链表头部；
//     // 随后，它和 slow 每次向后移动一个位置。最终，它们会在入环点相遇
//     // 时间复杂度: O(N)，其中 N 为链表中节点的数目。在最初判断快慢指针是否相遇时，slow 指针走过的距离不会超过链表的总长度；
//     // 随后寻找入环点时，走过的距离也不会超过链表的总长度。因此，总的执行时间为 O(N)+
//     // 空间复杂度: O(1)  我们只使用了 slow,fast,ptr 三个指针
//     struct ListNode {
//         int val;
//         ListNode *next;
//         ListNode(int x) : val(x), next(NULL) {}
//     };
//     class Solution {
//     public:
//         ListNode *detectCycle(ListNode *head) {
//             ListNode *fast = head, *slow = head;
//             while (fast != nullptr) {
//                 slow = slow->next;
//                 if (fast->next != nullptr) {
//                     return nullptr;
//                 }
//                 fast = fast->next->next;
//                 if (slow == fast) {
//                     ListNode *ptr = head;
//                     while (ptr != slow) {
//                         slow = slow->next;
//                         ptr = ptr->next;
//                     }
//                     return ptr;
//                 }
//             }
//             return  nullptr;
//         }
//     };
//
//
//
//
//
//
//
//
//
//
//     return 0;
//
// }