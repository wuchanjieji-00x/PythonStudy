// #include "iostream"
//
// using namespace std;
//
// // 19.删除链表的倒数第N个节点
// // 给你一个链表，删除链表的倒数第 n 个结点，并且返回链表的头结点。
//
// /
//
//
// int main() {
//
//     // // 解法1：双指针法
//     // 思路：定义双指针，快指针指向head，慢指针指向dummy，快指针先走n步，这样双指针之间的固定窗口长度就是n+1
//     // 然后快慢指针一起走，当快指针到达末尾时，慢指针指向倒数第n个节点的前一个节点，之后就是简单的删除节点的操作
//     // // 时间复杂度: O(n)
//     // // 空间复杂度: O(1)
//     // class Solution {
//     // public:
//     //     struct ListNode {
//     //         int val;
//     //         ListNode *next;
//     //         ListNode() : val(0), next(nullptr) {}
//     //         ListNode(int x) : val(x), next(nullptr) {}
//     //         ListNode(int x, ListNode *next) : val(x), next(next) {}
//     //     };
//     //     ListNode* removeNthFromEnd(ListNode* head, int n) {
//     //         ListNode* dummyHead = new ListNode(0);
//     //         dummyHead->next = head;
//     //         ListNode* fast = dummyHead;
//     //         ListNode* slow = dummyHead;
//     //
//     //         while (n-- && fast != nullptr) {
//     //             fast = fast->next;
//     //         }
//     //
//     //         fast = fast->next;
//     //
//     //         while (fast != nullptr) {
//     //             fast = fast->next;
//     //             slow = slow->next;
//     //         }
//     //         // slow->next = slow->next->next; //
//     //         ListNode* temp = slow->next;
//     //         slow->next = temp->next;
//     //         delete temp;
//     //
//     //         return dummyHead->next;
//     //     }
//
//
//
//     // 解法2：优化版双指针法
//     class Solution {
//     public:
//         struct ListNode {
//             int val;
//             ListNode *next;
//             ListNode() : val(0), next(nullptr) {}
//             ListNode(int x) : val(x), next(nullptr) {}
//             ListNode(int x, ListNode *next) : val(x), next(next) {}
//         };
//         ListNode* removeNthFromEnd(ListNode* head, int n) {
//             ListNode* dummyHead = new ListNode(0, head);
//             ListNode* fast = head;
//             ListNode* slow = dummyHead;
//
//             for(int i = 0; i < n; i++) {
//                 fast = fast->next;
//             }
//
//             while (fast) {
//                 fast = fast->next;
//                 slow = slow->next;
//             }
//             // slow->next = slow->next->next; //
//             ListNode* temp = slow->next;
//             slow->next = temp->next;
//             ListNode* ans = dummyHead->next;
//
//             delete temp;
//             delete dummyHead;
//
//             return ans;
//         }
//
//
//     };
//
//
//
//
//
//
//
//
//
//     return 0;
//
// }
