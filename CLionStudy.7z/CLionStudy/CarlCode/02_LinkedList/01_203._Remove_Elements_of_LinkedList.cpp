// #include "iostream"
// #include <list>
//
// using namespace std;
//
//
// // 单链表
// struct ListNode {
//     int val;  // 节点上存储的元素
//     ListNode *next;  // 指向下一个节点的指针
//     ListNode(int x) : val(x), next(NULL) {}  // 节点的构造函数
// };
//
//
//
// int main() {
//
//     // // 解法1：直接使用原来的链表来进行移除节点操作
//     // 时间复杂度: O(n)   空间复杂度: O(1)
//     // class Solution {
//     // public:
//     //     ListNode* removeElements(ListNode* head, int val) { // 注意这里不是if,排除次头节点的值等于val，又要删除一次头节点
//     //         while (head != nullptr && head->val == val) {  // 头节点不是空指针，且，头节点
//     //             ListNode* tmp = head;
//     //             head = head-> next;
//     //             delete tmp;
//     //         }
//     //
//     //         ListNode* cur = head; //让当前指针变量指向头节点，这样当前指针变量中的指针才指向头节点的下一个节点
//     //         while (cur != nullptr && cur->next != nullptr) {
//     //             if (cur->next->val == val) {
//     //                 ListNode* tmp = cur->next;
//     //                 cur->next = cur->next->next;
//     //                 delete tmp;
//     //             }else {
//     //                 cur = cur->next;
//     //             }
//     //         }
//     //         return head;
//     //     }
//     // };
//
//
//
//     // 解法2：设置一个虚拟头结点再进行移除节点操作
//     // 时间复杂度: O(n)   空间复杂度: O(1)
//     class Solution {
//     public:
//         ListNode* removeElements(ListNode* head, int val) {
//             ListNode* dummyHead = new ListNode(0); // 创建一个虚拟的头结点
//             dummyHead->next = head; // 让虚拟的头结点指向头结点
//             ListNode* cur = dummyHead; // 让当前指针变量指向虚拟的头结点
//
//             while (cur->next != nullptr) { // 循环判断当前指针变量的下一个节点是否为空 // 当前指针变量指向的不是最后一个节点
//                 if (cur->next->val == val) { // 如果下一个节点的值等于val，则删除下一个节点
//                     ListNode* tmp = cur->next; // 保存下一个节点的地址到临时指针变量
//                     cur->next = cur->next->next; // 当前指针变量指向下下个节点
//                     delete tmp; // 释放内存
//                 }else { // 如果下一个节点的值不等于val，则当前指针变量指向下一个节点
//                     cur = cur->next; // 当前指针变量指向下一个节点
//                 }
//             }
//             head = dummyHead->next; // 将虚拟头节点的下一个节点地址赋值给头结点
//             delete dummyHead; // 释放内存 // 删除虚拟头结点
//             return head; // 返回头结点
//         }
//     };
//
//
//     return 0;
//
// }
