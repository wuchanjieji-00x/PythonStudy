// #include "iostream"
// #include  "deque"
//
// using namespace std;
//
// // deque：双端队列，支持在两端高效地插入和删除元素。
// // C++中deque是stack和queue默认的底层实现容器
// // deque是可以两边扩展的，而且deque里元素并不是严格的连续分布的
// /*
//  * 常用操作
//  */
//
//
//
//
// int main() {
//
//
//
//
//
//
//
//
//
//     return 0;
//
// }