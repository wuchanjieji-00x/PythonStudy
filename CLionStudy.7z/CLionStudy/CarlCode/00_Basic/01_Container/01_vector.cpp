// #include "iostream"
// #include "vector"
//
// using namespace std;
//
// // vector：动态数组，可以在运行时调整大小。
//
//
// /*
//  *常用操作：
//  *push_back(value) ：将value添加到vector末尾
//  */
//
//
//
// int main() {
//
//
//
//
//
//
//
//
//
//     return 0;
//
// }
