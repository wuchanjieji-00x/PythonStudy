// // #include "iostream"
//
// #include <stack>
// using namespace std;
//
// // 538.把二叉搜索树转换为累加树
//
// // 从树中可以看出累加的顺序是右中左，所以我们需要反中序遍历这个二叉树，然后顺序累加就可以了
//
// // 二叉树的定义
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     // 构造函数，用于初始化节点
//     // 三种方式用于构建一个节点
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     // 在创建一个node的时候，需要传入一个int类型的值，作为节点的值, 初始化节点的左右子树为nullptr
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
//
// int main() {
//
//     // 递归
//     class Solution {
//     private:
//         int pre = 0; // 记录前一个节点的数值
//         void traversal(TreeNode* cur) { // 右中左遍历
//             if (cur == nullptr) return;
//             traversal(cur->right);
//             cur->val += pre;
//             pre = cur->val;
//             traversal(cur->left);
//         }
//     public:
//         TreeNode* convertBST(TreeNode* root) {
//             pre = 0;
//             traversal(root);
//             return root;
//         }
//     };
//
//
//
//     // 迭代
//     // 迭代法其实就是中序模板题
//     class Solution {
//     private:
//         int pre; // 记录前一个节点的数值
//         void traversal(TreeNode* root) {
//             stack<TreeNode*> st;
//             TreeNode* cur = root;
//             while (cur != nullptr || !st.empty()) {
//                 if (cur != nullptr) {
//                     st.push(cur);
//                     cur = cur->right;   // 右
//                 } else {
//                     cur = st.top();     // 中
//                     st.pop();
//                     cur->val += pre;
//                     pre = cur->val;
//                     cur = cur->left;    // 左
//                 }
//             }
//         }
//     public:
//         TreeNode* convertBST(TreeNode* root) {
//             pre = 0;
//             traversal(root);
//             return root;
//         }
//     };
//
//
//
//
//
//     return 0;
//
// }