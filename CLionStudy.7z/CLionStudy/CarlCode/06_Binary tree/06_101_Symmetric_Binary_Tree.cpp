// #include <queue>
// #include <stack>
//
// #include "iostream"
//
// using namespace std;
//
// // 101. 对称二叉树
//
// // 100.相同的树(opens new window)
// // 572.另一个树的子树
//
//
// // Definition for a binary tree node.
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
// int main() {
//
//     // 解法1：递归
//     class Solution {
//     public:
//         bool compare(TreeNode* left, TreeNode* right) {
//             // 首先排除空节点的情况
//             if (left == nullptr && right != nullptr) return false;
//             else if (left != nullptr && right == nullptr) return false;
//             else if (left == nullptr && right == nullptr) return true;
//             // 排除了空节点，再排除数值不相同的情况
//             else if (left->val != right->val) return false;
//
//             // 此时就是：左右节点都不为空，且数值相同的情况
//             // 此时才进入递归，判断左、右子树是否对称   // 此时才做递归，做下一层的判断
//             bool outside = compare(left->left, right->right); // 左子树：左、 右子树：右
//             bool inside = compare(left->right, right->left); // 左子树：右、 右子树：左
//             bool isSame = outside && inside;    // 左右子树都对称，才是对称二叉树  // 左子树：中、 右子树：中 （逻辑处理）
//             return isSame;
//
//         }
//
//         bool isSymmetric(TreeNode* root) {
//             if (root == nullptr) return true;
//             return compare(root->left, root->right);
//         }
//     };
//
//
//
//     // 解法2：迭代
//     // 如下的条件判断和递归的逻辑是一样的。
//     class Solution {
//     public:
//         bool isSymmetric(TreeNode* root) {
//             if (root == nullptr) return true;
//             queue<TreeNode*> que;
//             que.push(root->left); // 将左子树头结点加入队列
//             que.push(root->right); // 将右子树头结点加入队列
//
//             while (!que.empty()) { // 接下来就要判断这两个树是否相互翻转
//                 TreeNode* leftNode = que.front(); que.pop();
//                 TreeNode* rightNode = que.front(); que.pop();
//                 if (leftNode == nullptr && rightNode == nullptr) { // 左节点为空、右节点为空，此时说明是对称的
//                     continue;
//                 }
//
//                 if (leftNode == nullptr || rightNode == nullptr || leftNode->val != rightNode->val) {
//                     return false; // 左右一个节点不为空，或者都不为空但数值不相同，返回false
//                 }
//
//                 que.push(leftNode->left); // 加入左节点左孩子
//                 que.push(rightNode->right); // 加入右节点右孩子
//                 que.push(leftNode->right); // 加入左节点右孩子
//                 que.push(rightNode->left); // 加入右节点左孩子
//             }
//             return true; // 如果二叉树只有根节点一个节点，返回true.因为二叉树只有一个节点的话，不会进while循环
//         }
//     };
//
//
//     // 解法3：栈
//     // 容器改成栈就可以。因为不用区分左和右相比还是右和左相比
//     class Solution {
//     public:
//         bool isSymmetric(TreeNode* root) {
//             if (root == nullptr) return true;
//             stack<TreeNode*> st; // 这里改成了栈
//             st.push(root->left);
//             st.push(root->right);
//             while (!st.empty()) {
//                 TreeNode* rightNode = st.top(); st.pop();
//                 TreeNode* leftNode = st.top(); st.pop();
//                 if (!leftNode && !rightNode) {
//                     continue;
//                 }
//                 if ((!leftNode || !rightNode || (leftNode->val != rightNode->val))) {
//                     return false;
//                 }
//                 st.push(leftNode->left);
//                 st.push(rightNode->right);
//                 st.push(leftNode->right);
//                 st.push(rightNode->left);
//             }
//             return true;
//         }
//     };
//
//
//     return 0;
//
// }
