// // #include "iostream"
// #include <queue>
// #include <vector>
// using namespace std;
//
// // 108.将有序数组转换为二叉搜索树
// // 将一个按照升序排列的有序数组，转换为一棵高度平衡二叉搜索树
// // 本题中，一个高度平衡二叉树是指一个二叉树每个节点 的左右两个子树的高度差的绝对值不超过 1。
//
// // 不断中间分割，然后递归处理左区间，右区间，也可以说是分治。
// // 本质就是寻找分割点，分割点作为当前节点，然后递归左区间和右区间。
//
//
// // 二叉树的定义
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     // 构造函数，用于初始化节点
//     // 三种方式用于构建一个节点
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     // 在创建一个node的时候，需要传入一个int类型的值，作为节点的值, 初始化节点的左右子树为nullptr
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
// int main() {
//
//     // 递归
//     class Solution {
//     private:
//         // 循环不变量，左闭右闭区间
//         // nums为什么使用引用？ 如果不用引用的话，每一层递归的时候都要重复copy原数组的内存空间到其他地方去操作
//         // 使用引用的话，相当于引用了原数组，所以不需要重复copy
//         TreeNode* traversal(vector<int>& nums, int left, int right) {
//             if (left > right) return nullptr;
//             int mid = left + ((right - left) / 2);  // 防止操作越界
//             TreeNode* root = new TreeNode(nums[mid]);
//             root->left = traversal(nums, left, mid - 1);
//             root->right = traversal(nums, mid + 1, right);
//             return root;
//         }
//     public:
//         TreeNode* sortedArrayToBST(vector<int>& nums) {
//             // 注意：在调用traversal的时候传入的left和right为什么是0和nums.size() - 1，因为定义的区间为左闭右闭。
//             TreeNode* root = traversal(nums, 0, nums.size() - 1);
//             return root;
//         }
//     };
//
//
//
//     // 迭代
//     // 迭代法可以通过三个队列来模拟，一个队列放遍历的节点，一个队列放左区间下标，一个队列放右区间下标。模拟的就是不断分割的过程
//     class Solution {
//     public:
//         TreeNode* sortedArrayToBST(vector<int>& nums) {
//             if (nums.size() == 0) return nullptr;
//
//             TreeNode* root = new TreeNode(0);   // 初始根节点
//             queue<TreeNode*> nodeQue;           // 放遍历的节点
//             queue<int> leftQue;                 // 保存左区间下标
//             queue<int> rightQue;                // 保存右区间下标
//             nodeQue.push(root);                 // 根节点入队列
//             leftQue.push(0);                    // 0为左区间下标初始位置
//             rightQue.push(nums.size() - 1);     // nums.size() - 1为右区间下标初始位置
//
//             while (!nodeQue.empty()) {
//                 TreeNode* curNode = nodeQue.front();
//                 nodeQue.pop();
//                 int left = leftQue.front(); leftQue.pop();
//                 int right = rightQue.front(); rightQue.pop();
//                 int mid = left + ((right - left) / 2);
//
//                 curNode->val = nums[mid];       // 将mid对应的元素给中间节点
//
//                 if (left <= mid - 1) {          // 处理左区间
//                     curNode->left = new TreeNode(0);
//                     nodeQue.push(curNode->left);
//                     leftQue.push(left);
//                     rightQue.push(mid - 1);
//                 }
//
//                 if (right >= mid + 1) {         // 处理右区间
//                     curNode->right = new TreeNode(0);
//                     nodeQue.push(curNode->right);
//                     leftQue.push(mid + 1);
//                     rightQue.push(right);
//                 }
//             }
//             return root;
//         }
//     };
//
//
//
//
//
//
//
//
//
//     return 0;
//
// }
