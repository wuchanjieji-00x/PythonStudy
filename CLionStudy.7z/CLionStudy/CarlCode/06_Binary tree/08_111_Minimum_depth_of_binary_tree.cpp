// #include <queue>
//
// #include "iostream"
//
//
// using namespace std;
//
// // 111.二叉树的最小深度
//
// // 本题依然是前序遍历和后序遍历都可以，前序求的是深度，后序求的是高度。
// // 假设高度和深度都是从1开始的
//
// // Definition for a binary tree node.
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
//
// // Definition for a Node.
// class Node {
// public:
//     int val;
//     vector<Node*> children;
//
//     Node() {}
//
//     Node(int _val) {
//         val = _val;
//     }
//
//     Node(int _val, vector<Node*> _children) {
//         val = _val;
//         children = _children;
//     }
// };
//
// int main() {
//
//     // 解法1：递归
//     // 后序遍历：求高度
//     // 求二叉树的最小深度和求二叉树的最大深度的差别主要在于处理左右孩子不为空的逻辑
//     class Solution {
//     public:
//         int getDepth(TreeNode* node) {
//             if (node == nullptr) return 0;
//             int leftDepth = getDepth(node->left); // 左
//             int rightDepth = getDepth(node->right); // 右
//
//             // 中
//             // 当一个左子树为空，右不为空，这时并不是最低点
//             if (node->left == nullptr && node->right != nullptr) {
//                 return rightDepth + 1;
//             }
//             // 当一个右子树为空，左不为空，这时并不是最低点
//             if (node->left != nullptr && node->right == nullptr) {
//                 return leftDepth + 1;
//             }
//
//             int result = min(leftDepth, rightDepth) + 1;
//             return result;
//         }
//
//
//     };
//
//     // 解法2：递归
//     // 前序遍历：求深度
//     // 没看懂？？？
//     class Solution {
//     private:
//         int result;
//         void getdepth(TreeNode* node, int depth) {
//             // 函数递归终止条件
//             if (node == nullptr) {
//                 return;
//             }
//             // 中，处理逻辑：判断是不是叶子结点
//             if (node -> left == nullptr && node->right == nullptr) {
//                 result = min(result, depth);
//             }
//             if (node->left) { // 左
//                 getdepth(node->left, depth + 1);
//             }
//             if (node->right) { // 右
//                 getdepth(node->right, depth + 1);
//             }
//             return ;
//         }
//
//     public:
//         int minDepth(TreeNode* root) {
//             if (root == nullptr) {
//                 return 0;
//             }
//             result = INT_MAX;
//             getdepth(root, 1);
//             return result;
//         }
//     };
//
//
//
//     // 解法3：迭代
//     // 层序遍历：求深度
//     // 需要注意的是，只有当左右孩子都为空的时候，才说明遍历到最低点了。如果其中一个孩子不为空则不是最低点
//     class Solution {
//     public:
//         int minDepth(TreeNode* root) {
//             if (root == nullptr) return 0;
//             int depth = 0;
//             queue<TreeNode*> que;
//             que.push(root);
//             while (!que.empty()) {
//                 int size = que.size();
//                 depth++;
//                 for (int i = 0; i < size; i++) {
//                     TreeNode* node = que.front();
//                     que.pop();
//                     if (node->left == nullptr && node->right == nullptr) {
//                         return depth; // 当左右孩子都为空的时候，说明是最低点的一层了，退出
//                     }
//                     if (node->left) que.push(node->left);
//                     if (node->right) que.push(node->right);
//                 }
//             }
//             return depth;
//         }
//     };
//
//
//
//
//
//
//
//
//     return 0;
//
// }
