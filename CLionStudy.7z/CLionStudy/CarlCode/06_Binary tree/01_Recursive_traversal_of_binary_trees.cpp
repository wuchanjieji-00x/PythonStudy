// #include "iostream"
// #include <vector>
//
// using namespace std;
//
// // 二叉树的递归遍历
// /*
// 144.二叉树的前序遍历
// 145.二叉树的后序遍历
// 94.二叉树的中序遍历
// */
//
//
// // 二叉树的定义
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
// };
//
//
// int main() {
//
//     // 二叉树三种递归遍历方式：
//     class Solution {
//     public:
//         // 前序遍历（先序遍历）：中左右
//         void traversal_front(TreeNode* cur, vector<int>& vec) { // 确定递归函数的参数和返回值
//             // 我们只需要指向这个节点的指针，然后需要一个数组来存储这个节点的元素就可以了
//             if(cur == nullptr) return; // 确定终止条件
//             // 确定单层递归的逻辑 （我们调用的时候，传入的是root根节点的指针，是中）
//             vec.push_back(cur->val);  // 中
//             traversal_front(cur->left, vec); // 左
//             traversal_front(cur->right, vec); // 右
//         }
//
//         // 中序遍历：左中右
//         void traversal_mid(TreeNode* cur, vector<int>& vec) {
//             if(cur == nullptr) return;
//             traversal_mid(cur->left, vec); // 左
//             vec.push_back(cur->val); // 中
//             traversal_mid(cur->right, vec); // 右
//
//         }
//
//         // 后序遍历：左右中
//         void traversal_back(TreeNode* cur, vector<int>& vec) {
//             if(cur == nullptr) return;
//             traversal_back(cur->left, vec); // 左
//             traversal_back(cur->right, vec); // 右
//             vec.push_back(cur->val);    // 中
//         }
//
//
//         // 上述是自定义三种遍历方式，这里是封装。
//         // 输入二叉树的根节点，返回遍历结果
//
//         // 前序遍历的封装
//         vector<int> preorderTraversal(TreeNode* root) {
//             vector<int> result;
//             traversal_front(root, result); // 前序遍历
//             return result;
//         }
//
//         // 中序遍历的封装
//         vector<int> inorderTraversal(TreeNode* root) {
//             vector<int> result;
//             traversal_mid(root, result); // 中序遍历
//             return result;
//         }
//
//         // 后序遍历的封装
//         vector<int> postorderTraversal(TreeNode* root) {
//             vector<int> result;
//             traversal_back(root, result); // 后序遍历
//             return result;
//         }
//
//     };
//
//
//
//     return 0;
//
// }