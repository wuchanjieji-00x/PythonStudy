// // #include "iostream"
// #include <algorithm>
// #include <stack>
// #include <unordered_map>
// #include <vector>
// using namespace std;
//
// // 501.二叉搜索树中的众数
// // 给定一个有相同值的二叉搜索树（BST），找出 BST 中的所有众数（出现频率最高的元素）
//
//
// // 二叉树的定义
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     // 构造函数，用于初始化节点
//     // 三种方式用于构建一个节点
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     // 在创建一个node的时候，需要传入一个int类型的值，作为节点的值, 初始化节点的左右子树为nullptr
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
//
// int main() {
//
//     // 递归：假如是是普通二叉树
//     // 如果不是二叉搜索树，最直观的方法一定是把这个树都遍历了，用map统计频率，把频率排个序，最后取前面高频的元素的集合。
//     class Solution {
//     private:
//         void searchBST(TreeNode* cur, unordered_map<int, int>& map) {
//             if (cur == nullptr) return;
//             // cur不是空节点
//             map[cur->val]++;  // 统计元素频率    // 创建一个key:节点的值，这个key对应的value原本是0，记录的是这个key出现的次数
//             searchBST(cur->left, map);
//             searchBST(cur->right, map);
//             return; // 可以省略
//         }
//
//         bool static cmp (const pair<int, int>&a, const pair<int, int>& b) {
//                 return a.second > b.second;
//         }
//
//     public:
//         vector<int> findMode(TreeNode* root) {
//             unordered_map<int, int> map; // key:元素，value:出现频率
//             vector<int> result;
//             if (root == nullptr) return result;
//             searchBST(root, map);
//
//             vector<pair<int, int>> vec(map.begin(), map.end());
//             sort(vec.begin(), vec.end(), cmp); // 给频率排个序
//             result.push_back(vec[0].first);
//             for (int i = 1; i < vec.size(); i++) {
//                 // 取最高的放到result数组中，可能不止一个，如果有多个，那么频率一定相等，且都在vec前方连续排列
//                 if (vec[i].second == vec[0].second) result.push_back(vec[i].first);
//                 else break;  // 注意体会这里用break的想法[6，6，6，5，4，4，3，1]
//             }
//             return result;
//         }
//     };
//
//
//
//     // 递归：BST,,划重点
//     // 既然是搜索树，它中序遍历就是有序的。
//     class Solution {
//     private:
//         int maxCount = 0; // 最大频率
//         int count = 0; // 统计频率
//         TreeNode* pre = nullptr;
//         vector<int> result;
//         void searchBST(TreeNode* cur) {
//             if (cur == nullptr) return ;
//
//             // 中序遍历
//             searchBST(cur->left);       // 左
//             // 中
//             if (pre == nullptr) { // 第一个节点
//                 count = 1;
//             } else if (pre->val == cur->val) { // 与前一个节点数值相同
//                 count++;
//             } else { // 与前一个节点数值不同
//                 count = 1;
//             }
//             pre = cur; // 更新上一个节点
//
//             if (count == maxCount) { // 如果和最大值相同，放进result中
//                 result.push_back(cur->val);
//             }
//
//             if (count > maxCount) { // 如果计数大于最大值频率
//                 maxCount = count;   // 更新最大频率
//                 result.clear();     // 很关键的一步，不要忘记清空result，之前result里的元素都失效了
//                 result.push_back(cur->val);
//             }
//
//             searchBST(cur->right);      // 右
//             return ;
//         }
//
//     public:
//         vector<int> findMode(TreeNode* root) {
//             count = 0;
//             maxCount = 0;
//             pre = nullptr; // 记录前一个节点
//             result.clear();
//
//             searchBST(root);
//             return result;
//         }
//     };
//
//
//     // 迭代：BST
//     // 只要把中序遍历转成迭代，中间节点的处理逻辑完全一样。
//     class Solution {
//     public:
//         vector<int> findMode(TreeNode* root) {
//             stack<TreeNode*> st;
//             TreeNode* cur = root;
//             TreeNode* pre = nullptr;
//             int maxCount = 0; // 最大频率
//             int count = 0; // 统计频率
//             vector<int> result;
//             while (cur != nullptr || !st.empty()) {
//                 if (cur != nullptr) { // 指针来访问节点，访问到最底层
//                     st.push(cur); // 将访问的节点放进栈
//                     cur = cur->left;                // 左
//                 } else {
//                     cur = st.top();
//                     st.pop();                       // 中
//                     if (pre == nullptr) { // 第一个节点
//                         count = 1;
//                     } else if (pre->val == cur->val) { // 与前一个节点数值相同
//                         count++;
//                     } else { // 与前一个节点数值不同
//                         count = 1;
//                     }
//                     if (count == maxCount) { // 如果和最大值相同，放进result中
//                         result.push_back(cur->val);
//                     }
//
//                     if (count > maxCount) { // 如果计数大于最大值频率
//                         maxCount = count;   // 更新最大频率
//                         result.clear();     // 很关键的一步，不要忘记清空result，之前result里的元素都失效了
//                         result.push_back(cur->val);
//                     }
//                     pre = cur;
//                     cur = cur->right;               // 右
//                 }
//             }
//             return result;
//         }
//     };
//
//
//
//
//
//
//     return 0;
//
// }
