// #include <queue>
//
// #include "iostream"
//
// using namespace std;
//
//
// // 222.完全二叉树的节点个数
//
//
//
// // Definition for a binary tree node.
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
//
// // Definition for a Node.
// class Node {
// public:
//     int val;
//     vector<Node*> children;
//
//     Node() {}
//
//     Node(int _val) {
//         val = _val;
//     }
//
//     Node(int _val, vector<Node*> _children) {
//         val = _val;
//         children = _children;
//     }
// };
//
//
// int main() {
//
//
//
//     // 1. 按照普通二叉树的逻辑
//
//     // 解法1.1：递归
//     // 后序遍历：左右中
//     class Solution {
//     private:
//         int getNodesNum(TreeNode* cur) {
//             if (cur == nullptr) {
//                 return 0;
//             }
//             int leftNum = getNodesNum(cur->left);
//             int rightNum = getNodesNum(cur->right);
//             int treeNum = leftNum + rightNum + 1;
//             return treeNum;
//         }
//     public:
//         int countNodes(TreeNode* root) {
//             return getNodesNum(root);
//         }
//     };
//
//
//     // 解法1.2：迭代
//     // 层序遍历
//     // 只要模板少做改动，加一个变量result，统计节点数量就可以了
//     // 时间复杂度：O(n)
//     // 空间复杂度：O(n)
//     class Solution {
//     public:
//         int countNodes(TreeNode* root) {
//             queue<TreeNode*> que;
//             if (root != nullptr) que.push(root);
//             int result = 0;
//             while (!que.empty()) {
//                 int size = que.size();
//                 // result += size; // 这个是直接加一层的元素的总数
//                 for (int i = 0; i < size; i++) {
//                     TreeNode* cur = que.front();
//                     que.pop();
//                     result++; // 逐个加元素
//                     if (cur->left != nullptr) que.push(cur->left);
//                     if (cur->right != nullptr) que.push(cur->right);
//                 }
//             }
//             return result;
//         }
//     };
//
//
//     // 2. 按照完全二叉树的性质
//     // 完全二叉树只有两种情况，情况一：就是满二叉树，情况二：最后一层叶子节点没有满。
//     // 对于情况一，可以直接用 2^树深度 - 1 来计算，注意这里根节点深度为1。
//     // 对于情况二，分别递归左孩子，和右孩子，递归到某一深度一定会有左孩子或者右孩子为满二叉树，然后依然可以按照情况1来计算
//     // 在完全二叉树中，如果递归向左遍历的深度等于递归向右遍历的深度，那说明就是满二叉树
//     class Solution {
//     public:
//         int countNodes(TreeNode* root) {
//             if (root == nullptr) return 0;
//             TreeNode* left = root->left;
//             TreeNode* right = root->right;
//             int leftDepth = 0, rightDepth = 0; // 这里初始为0是有目的的，为了下面求指数方便
//             // 这里相当于多了一步，完全二叉树肯定包含满二叉树，遇到满二叉树用公式求，简单点
//             while (left) {  // 求左子树深度
//                 left = left->left;
//                 leftDepth++;
//             }
//             while (right) { // 求右子树深度
//                 right = right->right;
//                 rightDepth++;
//             }
//             if (leftDepth == rightDepth) {
//                 return (2 << leftDepth) - 1; // 注意(2<<1) 相当于2^2，所以leftDepth初始为0
//             }
//
//             // 这是完全二叉树中的非满二叉树的部分，还是按照普通二叉树的方法计算节点数
//             int leftTreeNum = countNodes(root->left);       // 左
//             int rightTreeNum = countNodes(root->right);     // 右
//             int result = leftTreeNum + rightTreeNum + 1;    // 中
//             return result;
//             // return countNodes(root->left) + countNodes(root->right) + 1;  // 这是精简版
//         }
//     };
//
//
//
//
//
//     return 0;
//
// }