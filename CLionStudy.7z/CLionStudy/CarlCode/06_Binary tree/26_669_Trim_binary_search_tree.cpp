// // #include "iostream"
//
// using namespace std;
//
// // 669. 修剪二叉搜索树
//
// // 二叉树的定义
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     // 构造函数，用于初始化节点
//     // 三种方式用于构建一个节点
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     // 在创建一个node的时候，需要传入一个int类型的值，作为节点的值, 初始化节点的左右子树为nullptr
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
//
// int main() {
//
//     // 递归，版本1
//     class Solution {
//     public:
//         TreeNode* trimBST(TreeNode* root, int low, int high) {
//             if (root == nullptr) return nullptr;
//             if (root->val < low) {
//                 TreeNode* right = trimBST(root->right, low, high); // 寻找符合区间[low, high]的节点
//                 return right;
//             }
//             if (root->val > high) {
//                 TreeNode* left = trimBST(root->left, low, high); // 寻找符合区间[low, high]的节点
//                 return left;
//             }
//
//             // 这里对应的是root->val在[L，R]区间内
//             root->left = trimBST(root->left, low, high); // root->left接入符合条件的左孩子
//             root->right = trimBST(root->right, low, high); // root->right接入符合条件的右孩子
//             return root;
//         }
//
//     };
//
//
//     // 版本1精简版
//     class Solution {
//     public:
//         TreeNode* trimBST(TreeNode* root, int low, int high) {
//             if (root == nullptr) return nullptr;
//             if (root->val < low) return trimBST(root->right, low, high);
//             if (root->val > high) return trimBST(root->left, low, high);
//             root->left = trimBST(root->left, low, high);
//             root->right = trimBST(root->right, low, high);
//             return root;
//         }
//     };
//
//
//
//     // 迭代
//     // 没看懂！！！！
//     class Solution {
//     public:
//         TreeNode* trimBST(TreeNode* root, int L, int R) {
//             if (!root) return nullptr;
//
//             // 处理头结点，让root移动到[L, R] 范围内，注意是左闭右闭
//             while (root != nullptr && (root->val < L || root->val > R)) {
//                 if (root->val < L) root = root->right; // 小于L往右走
//                 else root = root->left; // 大于R往左走
//             }
//             TreeNode *cur = root;
//             // 此时root已经在[L, R] 范围内，处理左孩子元素小于L的情况
//             while (cur != nullptr) {
//                 while (cur->left && cur->left->val < L) {
//                     cur->left = cur->left->right;
//                 }
//                 cur = cur->left;
//             }
//             cur = root;
//
//             // 此时root已经在[L, R] 范围内，处理右孩子大于R的情况
//             while (cur != nullptr) {
//                 while (cur->right && cur->right->val > R) {
//                     cur->right = cur->right->left;
//                 }
//                 cur = cur->right;
//             }
//             return root;
//         }
//     };
//
//
//
//
//
//
//
//
//     return 0;
//
// }
