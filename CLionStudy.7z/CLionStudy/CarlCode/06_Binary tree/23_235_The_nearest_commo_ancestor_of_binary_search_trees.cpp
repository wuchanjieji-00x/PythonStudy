// // #include "iostream"
//
// using namespace std;
//
// // 235. 二叉搜索树的最近公共祖先
// // 当我们从上向下去递归遍历，第一次遇到 cur节点是数值在[q, p]区间中，那么cur就是 q和p的最近公共祖先。
//
// // 对于二叉搜索树的最近祖先问题，其实要比普通二叉树公共祖先问题 (opens new window)简单的多。
// // 不用使用回溯，二叉搜索树自带方向性，可以方便的从上向下查找目标区间，遇到目标区间内的节点，直接返回。
//
//
// // 二叉树的定义
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     // 构造函数，用于初始化节点
//     // 三种方式用于构建一个节点
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     // 在创建一个node的时候，需要传入一个int类型的值，作为节点的值, 初始化节点的左右子树为nullptr
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
// int main() {
//
//     // 递归，版本1
//     class Solution {
//     private:
//         TreeNode* traversal(TreeNode* cur, TreeNode* p, TreeNode* q) {
//             if (cur == nullptr) return nullptr;
//
//             // 需要注意的是此时不知道p和q谁大，所以两个都要判断
//
//             // 如果当前节点的值大于p和q，那么说明p和q都在当前节点的左子树中，那么递归的去左子树中寻找
//             if (cur->val > p->val && cur->val > q->val) {
//                 TreeNode* left = traversal(cur->left, p, q);
//                 if (left != nullptr) return left; // 在这里调用递归函数的地方，把递归函数的返回值left，直接return
//             }
//
//             // 如果当前节点的值小于p和q，那么说明p和q都在当前节点的右子树中，那么递归的去右子树中寻找
//             if (cur->val < p->val && cur->val < q->val) {
//                 TreeNode* right = traversal(cur->right, p, q);
//                 if (right != nullptr) return right; // 在这里调用递归函数的地方，把递归函数的返回值right，直接return
//             } // 为什么直接return呢？因为这是BST，只可能有一条路径，我们只要遍历一条边就可以了，得到值就返回去，不需要在中间去做逻辑处理了
//
//             // 如果当前节点的值在p和q之间，那么说明p和q都在当前节点的左右子树中，那么当前节点就是最近公共祖先
//             return cur;
//         }
//
//     public:
//         TreeNode* lowestCommonAncestor(TreeNode* root, TreeNode* p, TreeNode* q) {
//             return traversal(root, p, q);
//         }
//     };
//
//
//     // 递归，版本1精简版
//     class Solution {
//     public:
//         TreeNode* lowestCommonAncestor(TreeNode* root, TreeNode* p, TreeNode* q) {
//             if (root->val > p->val && root->val > q->val) {
//                 return lowestCommonAncestor(root->left, p, q);
//             } else if (root->val < p->val && root->val < q->val) {
//                 return lowestCommonAncestor(root->right, p, q);
//             } else return root;
//         }
//     };
//
//
//
//     // 迭代
//     class Solution {
//     public:
//         TreeNode* lowestCommonAncestor(TreeNode* root, TreeNode* p, TreeNode* q) {
//             while(root) {
//                 if (root->val > p->val && root->val > q->val) {
//                     root = root->left;
//                 } else if (root->val < p->val && root->val < q->val) {
//                     root = root->right;
//                 } else return root;
//             }
//             return nullptr;
//         }
//     };
//
//
//
//
//
//
//
//     return 0;
//
// }