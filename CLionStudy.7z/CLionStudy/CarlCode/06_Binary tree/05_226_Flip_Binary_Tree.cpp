// #include <queue>
// #include <stack>
//
// #include "iostream"
//
// using namespace std;
//
// // 226.翻转二叉树
//
//
//
// // Definition for a binary tree node.
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
//
// int main() {
//
//     // 解法1：递归：前序遍历
//     class Solution {
//     public:
//         TreeNode* invertTree(TreeNode* root) {
//             if (root == nullptr) return root;
//             swap (root->left, root->right); // 中
//             invertTree(root->left); // 左
//             invertTree(root->right); // 右
//             return root;  // 每一个节点都返回一个节点指针
//         }
//     };
//
//     // 解法2：递归：后序遍历
//     class Solution {
//     public:
//         TreeNode* invertTree(TreeNode* root) {
//             if (root == nullptr) return root;
//             swap (root->left, root->right); // 中
//             invertTree(root->right); // 右
//             invertTree(root->left); // 左
//             return root;  // 每一个节点都返回一个节点指针
//         }
//     };
//
//
//
//     // 解法3：迭代：前序遍历
//     class Solution {
//     public:
//         TreeNode* invertTree(TreeNode* root) {
//             if (root == nullptr)  return root;
//             stack<TreeNode*> st;
//             st.push(root);
//             while (!st.empty()) {
//                 TreeNode* cur = st.top(); // 中
//                 st.pop();
//                 swap(cur->left, cur->right);
//                 if(cur->right) st.push(cur->right); // 右
//                 if(cur->left) st.push(cur->left); // 左
//             }
//         }
//     };
//
//
//     // 解法4：统一迭代：前序遍历
//
//     // 解法5：广度优先遍历：层序遍历
//     class Solution {
//     public:
//         TreeNode* invertTree(TreeNode* root) {
//             queue<TreeNode*> que;
//             if (root != nullptr) que.push(root);
//             while (!que.empty()) {
//                 int size = que.size();
//                 for (int i = 0; i < size; i++) {
//                     TreeNode* cur = que.front();
//                     que.pop();
//                     swap(cur->left, cur->right);
//                     if (cur->left) que.push(cur->left);
//                     if (cur->right) que.push(cur->right);
//                 }
//             }
//         }
//     };
//
//
//
//     // 解法6：统一迭代：中序遍历  没看懂？？？
//     class Solution {
//     public:
//         TreeNode* invertTree(TreeNode* root) {
//             stack<TreeNode*> st;
//             if (root != NULL) st.push(root);
//             while (!st.empty()) {
//                 TreeNode* node = st.top();
//                 if (node != NULL) {
//                     st.pop();
//                     if (node->right) st.push(node->right);  // 右
//                     st.push(node);                          // 中
//                     st.push(NULL);
//                     if (node->left) st.push(node->left);    // 左
//
//                 } else {
//                     st.pop();
//                     node = st.top();
//                     st.pop();
//                     swap(node->left, node->right);          // 节点处理逻辑
//                 }
//             }
//             return root;
//         }
//     };
//
//     return 0;
//
// }
