// // #include "iostream"
//
// #include <cstddef>
// using namespace std;
//
// // 700.二叉搜索树中的搜索
// // 二叉搜索树（BST）是一个有序树：
// // 若它的左子树不空，则左子树上所有结点的值均小于它的根结点的值；
// // 若它的右子树不空，则右子树上所有结点的值均大于它的根结点的值；
// // 它的左、右子树也分别为二叉搜索树
//
//
// // 二叉树的定义
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     // 构造函数，用于初始化节点
//     // 三种方式用于构建一个节点
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     // 在创建一个node的时候，需要传入一个int类型的值，作为节点的值, 初始化节点的左右子树为nullptr
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
// int main() {
//
//     // 递归，版本1
//     class Solution {
//     public:
//         TreeNode* searchBST(TreeNode* root, int val) {
//             if (root == nullptr || root->val == val) return root;
//             TreeNode* result = nullptr;
//             // TreeNode* root = new TreeNode(0) // 注意这里两种创建节点指针的方式
//
//             // 很多录友写递归函数的时候 习惯直接写 searchBST(root->left, val)，却忘了 递归函数还有返回值。
//             // 递归函数的返回值是什么 ? 是 左子树如果搜索到了val，要将该节点返回
//             // 如果不用一个变量将其接住，那么返回值不就没了
//             // 这一点需要理解？？？？
//
//             // 递归函数本身是有返回值的，所以在进行根节点的左右子树的递归中，每个递归函数都需要变量去接收返回值
//             if (root->val > val) result = searchBST(root->left, val);
//             if (root->val < val) result = searchBST(root->right, val);
//
//             return result;
//         }
//     };
//
//     // 递归，版本1的精简版
//     class Solution {
//     public:
//         TreeNode* searchBST(TreeNode* root, int val) {
//             if (root == nullptr || root->val == val) return root;
//             if (root->val > val) return searchBST(root->left, val);
//             if (root->val < val) return searchBST(root->right, val);
//             return nullptr;
//         }
//     };
//
//
//
//     // 迭代
//     class Solution {
//     public:
//         TreeNode* searchBST(TreeNode* root, int val) {
//             while (root != nullptr) {
//                 if (root->val > val) root = root->left;
//                 else if (root->val < val) root = root-> right;
//                 else return root;
//             }
//             return nullptr; // 如果在上述的过程中没有找到，那我们在这里返回空指针
//         }
//     };
//
//
//
//
//     return 0;
//
// }