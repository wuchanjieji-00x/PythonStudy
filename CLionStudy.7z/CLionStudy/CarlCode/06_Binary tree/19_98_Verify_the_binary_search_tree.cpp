// // #include "iostream"
//
// #include <climits>
// #include <stack>
// #include <vector>
// using namespace std;
//
// // 98.验证二叉搜索树
// // 一个二叉搜索树具有如下特征：
// // 节点的左子树只包含小于当前节点的数。
// // 节点的右子树只包含大于当前节点的数。
// // 所有左子树和右子树自身必须也是二叉搜索树。
//
//
// // 二叉树的定义
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     // 构造函数，用于初始化节点
//     // 三种方式用于构建一个节点
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     // 在创建一个node的时候，需要传入一个int类型的值，作为节点的值, 初始化节点的左右子树为nullptr
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
// int main() {
//
//     // 解法1：采用中序遍历将二叉树转化为数组，判断这个数组是不是递增数组
//     // 思路：要知道中序遍历下，输出的二叉搜索树节点的数值是有序序列。
//     // 有了这个特性，验证二叉搜索树，就相当于变成了判断一个序列是不是递增的了
//     class Solution {
//     private:
//         vector<int> vec;
//         void InorderTraveral(TreeNode* root) {
//             if (root == nullptr) return;
//             InorderTraveral(root->left);
//             vec.push_back(root->val);  // 将二叉搜索树转换为有序数组
//             InorderTraveral(root->right);
//         }
//
//     public:
//         bool isValidBST(TreeNode* root) {
//             vec.clear(); // 不加这句在leetcode上也可以过，但最好加上
//             InorderTraveral(root);
//             // 注意这里判断数组是否递增的写法
//             for (int i = 1; i < vec.size(); i++) {
//                 if (vec[i] <= vec[i - 1]) return false; // 注意要小于等于，搜索树里不能有相同元素
//             }
//         }
//     };
//
//
//     // 解法2：递归，不用数组，在遍历中比较
//     class Solution {
//     public:
//         long long maxVal = LONG_MIN; // 因为后台测试数据中有int最小值
//         bool isValidBST(TreeNode* root) {
//             if (root == nullptr) return true;
//
//             bool left = isValidBST(root->left);
//             // 中序遍历，验证遍历的元素是不是从小到大
//             if (maxVal < root->val) maxVal = root->val;
//             else return false;
//             bool right = isValidBST(root->right);
//
//             return left && right;
//         }
//     };
//
//
//     // 如果测试数据中有 longlong的最小值，怎么办？
//     // 不可能在初始化一个更小的值了吧。 建议避免 初始化最小值，如下方法取到最左面节点的数值来比较。
//
//     // 解法3：双指针    不理解？？？？？
//     // 一个指针进行遍历，一个指针指向当前指针的上一个节点
//     // 这里不进行初始化，根据中序遍历的顺序，逐个比较相邻两个节点，也是递增的思想
//     class Solution {
//     public:
//         // 这个pre指针一定要声明成一个全局变量，不能放进循环函数里，否则会一直被重新声明
//         TreeNode* pre = nullptr;  // // 用来记录前一个节点
//         bool isValidBST(TreeNode* root) {
//             if (root == nullptr) return true;
//
//             bool left = isValidBST(root->left);
//
//             if (pre != nullptr && pre->val >= root->val) return false;
//             pre = root;
//
//             bool right = isValidBST(root->right);
//
//             return left && right;
//         }
//     };
//
//
//
//     // 迭代
//     // 迭代法中序遍历稍加改动就可以了，
//     class Solution {
//     public:
//         bool isValidBST(TreeNode* root) {
//             stack<TreeNode*> st;
//             TreeNode* cur = root;
//             TreeNode* pre = nullptr; // 记录前一个节点
//             while (cur != nullptr || !st.empty()) {
//                 if (cur != nullptr) {
//                     st.push(cur);
//                     cur = cur->left;                // 左
//                 } else {
//                     cur = st.top();                 // 中
//                     st.pop();
//                     if (pre != nullptr && cur->val <= pre->val)
//                         return false;
//                     pre = cur; //保存前一个访问的结点
//
//                     cur = cur->right;               // 右
//                 }
//             }
//             return true;
//         }
//     };
//
//
//
//
//
//
//
//
//
//
//     return 0;
//
// }
