// #include <stack>
//
// #include "iostream"
//
// using namespace std;
//
// // 110.平衡二叉树
// // 一棵高度平衡二叉树定义为：一个二叉树每个节点 的左右两个子树的高度差的绝对值不超过1。
//
// // 二叉树节点的深度：指从根节点到该节点的最长简单路径边的条数
// // 二叉树节点的高度：指从该节点到叶子节点的最长简单路径边的条数。
// // 简单的说，深度是从上往下，高度是从下往上，假设都是从1开始计数
//
// // 求深度适合用前序遍历，而求高度适合用后序遍历。
// // 求深度可以从上到下去查 所以需要前序遍历（中左右）
// // 而高度只能从下到上去查，所以只能后序遍历（左右中）
//
// // Definition for a binary tree node.
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
//
// int main() {
//
//     // 解法1：递归
//     class Solution {
//     public:
//         int getHeight(TreeNode* node) { // 参数和返回值
//             if (node == nullptr) { // 递归终止条件
//                 return 0;
//             }
//
//             // 单层递归的逻辑
//             int leftHeight = getHeight(node->left);
//             if (leftHeight == -1) return -1;
//             int rightHeight = getHeight(node->right);
//             if (rightHeight == -1) return -1;
//             int result;
//             if (abs(leftHeight - rightHeight) > 1) {
//                 result = -1;
//             } else {
//                 return max(leftHeight, rightHeight) + 1; // 加1，因为当前节点的高度等于左右子树高度加上本身节点的一层高度
//             }
//             return result;
//
//         }
//
//         bool isBalanced(TreeNode* root) {
//             return getHeight(root) != -1;
//             // return getHeight(root) == -1 ? false : true;
//         }
//     };
//
//
//     // 解法2：迭代
//     // 没看明白？？？
//     class Solution {
//     private:
//         int getDepth(TreeNode* cur) {
//             stack<TreeNode*> st;
//             if (cur != nullptr) st.push(cur);
//             int depth = 0; // 记录深度
//             int result = 0;
//             while (!st.empty()) {
//                 TreeNode* node = st.top();
//                 if (node != nullptr) {
//                     st.pop();
//                     st.push(node);                          // 中
//                     st.push(nullptr);
//                     depth++;
//                     if (node->right) st.push(node->right);  // 右
//                     if (node->left) st.push(node->left);    // 左
//
//                 } else {
//                     st.pop();
//                     node = st.top();
//                     st.pop();
//                     depth--;
//                 }
//                 result = result > depth ? result : depth;
//             }
//             return result;
//         }
//
//     public:
//         bool isBalanced(TreeNode* root) {
//             stack<TreeNode*> st;
//             if (root == nullptr) return true;
//             st.push(root);
//             while (!st.empty()) {
//                 TreeNode* node = st.top();                       // 中
//                 st.pop();
//                 if (abs(getDepth(node->left) - getDepth(node->right)) > 1) {
//                     return false;
//                 }
//                 if (node->right) st.push(node->right);           // 右（空节点不入栈）
//                 if (node->left) st.push(node->left);             // 左（空节点不入栈）
//             }
//             return true;
//         }
//     };
//
//
//
//
//
//
//
//
//
//     return 0;
//
// }
