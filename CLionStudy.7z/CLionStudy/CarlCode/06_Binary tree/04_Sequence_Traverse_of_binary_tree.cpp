// #include <vector>
//
// #include "iostream"
// #include "queue"
// #include "algorithm"
//
// using namespace std;
//
// // 二叉树层序遍历
// // 二叉树的层序遍历，就是图论中的广度优先搜索在二叉树中的应用，需要借助队列来实现（此时又发现队列的一个应用了）
//
// // 二叉树的定义
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
// };
//
// // // Definition for a Node.
// // class Node {
// // public:
// //     int val;
// //     vector<Node*> children;
// //
// //     Node() {}
// //
// //     Node(int _val) {
// //         val = _val;
// //     }
// //
// //     Node(int _val, vector<Node*> _children) {
// //         val = _val;
// //         children = _children;
// //     }
// // };
//
// // 116 & 117
// struct Node {
//     int val;
//     Node *left;
//     Node *right;
//     Node *next;
// };
//
//
// int main() {
//
//     // //102.二叉树的层序遍历
//     // // 解法1 ： 这个解法是二叉树层序遍历的模板，划重点
//     // class Solution {
//     // public:
//     //     vector<vector<int>> levelOrder(TreeNode* root) { // 形参是root,返回值是一个二维数组
//     //         queue<TreeNode*> que; // 显性定义一个队列用于保存每一层的节点
//     //         if (root != nullptr) que.push(root); // 根节点入队
//     //         vector<vector<int>> result; // 定义一个二维数组用于保存每一层的节点
//     //         while(!que.empty()) { // 循环终止条件是队列为空，意味着叶子节点都被输出了，没有节点了// 如果队列不为空
//     //             int size = que.size();
//     //             // 从根节点看，第一层只有根节点一个节点；后续，再处理下一层的时候，一个节点出队，同时它的两个子节点入队
//     //             // 当把本层的节点全部弹出后，队列里的节点就是下一层的所有节点
//     //             vector<int> vec; // 定义一个一维数组，用于接收每一层的所有节点
//     //
//     //             // 这里一定要使用固定大小size，不要使用que.size()，因为que.size是不断变化的
//     //             for (int i = 0; i < size; i++) {
//     //                 // 遍历每一层
//     //                 // 一个节点出队，它的所有子节点入队（如果有的话），空节点不入队
//     //                 TreeNode* cur = que.front();
//     //                 que.pop();
//     //                 vec.push_back(cur->val);
//     //                 if (cur->left != nullptr) que.push(cur->left);
//     //                 if (cur->right != nullptr) que.push(cur->right);
//     //             }
//     //             result.push_back(vec); // 将目标这一层的节点作为一个vector添加到result二维数组中
//     //             // 再次回到while循环，queue里的是要遍历的下一层的所有节点
//     //         }
//     //         return result;
//     //     }
//     // };
//
//
//     // 解法2：递归法，没看懂
//
//
//
//     // // 107.二叉树的层次遍历 II
//     // // 思路：相对于102.二叉树的层序遍历，就是最后把result数组反转一下就可以了
//     // class Solution {
//     // public:
//     //     vector<vector<int>> levelOrderBottom(TreeNode* root) {
//     //         queue<TreeNode*> que;
//     //         if (root != NULL) que.push(root);
//     //         vector<vector<int>> result;
//     //         while (!que.empty()) {
//     //             int size = que.size();
//     //             vector<int> vec;
//     //             for (int i = 0; i < size; i++) {
//     //                 TreeNode* node = que.front();
//     //                 que.pop();
//     //                 vec.push_back(node->val);
//     //                 if (node->left) que.push(node->left);
//     //                 if (node->right) que.push(node->right);
//     //             }
//     //             result.push_back(vec);
//     //         }
//     //         reverse(result.begin(), result.end()); // 在这里反转一下数组即可
//     //         return result;
//     //
//     //     }
//     // };
//
//
//
//     // // 199.二叉树的右视图
//     // // 思路：层序遍历的时候，判断是否遍历到单层的最后面的元素，如果是，就放进result数组中，随后返回result就
//     // class Solution {
//     // public:
//     //     vector<int> rightSideView(TreeNode* root) { // 形参是root,返回值是一个一维数组。（因为输出的vector的每一个元素是二叉树每一层的最后一个元素）
//     //         queue<TreeNode*> que;
//     //         if (root != nullptr) que.push(root);
//     //         vector<int> result;
//     //         while (!que.empty()) { // 判断条件 !que.empty() 等同于 que
//     //             int size = que.size();
//     //             for (int i = 0; i < size; i++) {
//     //                 TreeNode* cur = que.front();
//     //                 que.pop();
//     //                 // 区别就在于，输出元素的时候，只输出每一层的最后一个节点的值
//     //                 if (i == size - 1) result.push_back(cur->val); // 将每一层的最后元素放入result数组中
//     //                 if (cur->left) que.push(cur->left); //判断条件 等同于 cur->left != nullptr
//     //                 if (cur->right) que.push(cur->right);
//     //             }
//     //         }
//     //         return result;
//     //     }
//     // };
//
//     //
//     // // 637.二叉树的层平均值
//     // // 本题就是层序遍历的时候把一层求个总和再取一个均值。
//     // class Solution {
//     // public:
//     //     vector<double> averageOfLevels(TreeNode* root) {
//     //         queue<TreeNode*> que;
//     //         if (root != nullptr) que.push(root);
//     //         vector<double> result;
//     //         while (!que.empty()) { // 如果队列不为空
//     //             int size = que.size();
//     //             double sum = 0;
//     //             for (int i = 0; i < size; i++) {
//     //                 TreeNode* cur = que.front();
//     //                 que.pop();
//     //                 sum += cur->val; // 计算当前层级的所有节点的值的和
//     //                 // 如果i指向的不是叶子节点，则将其左右节点入队（如果有的话）
//     //                 if (cur->left) que.push(cur->left); // 如果左节点不为空，则入队
//     //                 if (cur->right) que.push(cur->right);
//     //             }
//     //             result.push_back(sum / size); // 将每一层均值放进结果集
//     //         }
//     //         return result;
//     //     }
//     //
//     // };
//
//
//
//     // // 429.N叉树的层序遍历
//     // // 这道题依旧是模板题，只不过一个节点有N个孩子了
//     // class Solution {
//     // public:
//     //     vector<vector<int>> levelOrder(Node* root) {
//     //         queue<Node*> que;
//     //         if (root != nullptr) que.push(root)
//     //         vector<vector<int>> result;
//     //         while (!que.empty()) {
//     //             int size = que.size();
//     //             vector<int> vec;
//     //             for (int i = 0; i < size; i++) {
//     //                 Node* cur = que.front();
//     //                 que.pop();
//     //                 vec.push_back(cur->val);
//     //                 // 相比于模板，这里是针对N叉树，子节点数目不确定而已，但又需要遍历当前节点的所有子节点
//     //                 for (int j = 0; j < cur->children.size(); j++) {
//     //                     if (cur->children[j] != nullptr) que.push(cur->children[j]);
//     //                 }
//     //             }
//     //             result.push_back(vec);
//     //         }
//     //         return result;
//     //     }
//     // };
//
//
//
//     // // 515.在每个树行中找最大值
//     // // 思路：层序遍历，取每一层的最大值
//     // class Solution {
//     // public:
//     //     vector<vector<int>> largestValues(TreeNode* root) {
//     //         queue<TreeNode*> que;
//     //         if (root != nullptr) que.push(root);
//     //         vector<int> result;
//     //         while (!que.empty()) {
//     //             int size = que.size();
//     //             int maxValue = INT_MIN; // 取每一层的最大值
//     //             for (int i = 0; i < size; i++) {
//     //                 TreeNode* cur = que.front();
//     //                 que.pop();
//     //                 // maxValue = max(maxValue, cur->val);
//     //                 maxValue = cur->val > maxValue ?  cur->val : maxValue; // 三元运算符，逐个遍历并比较元素的值
//     //                 if (cur->left) que.push(cur->left);
//     //                 if (cur->right) que.push(cur->right);
//     //             }
//     //             result.push_back(maxValue); // 把最大值放进数组
//     //         }
//     //     }
//     // };
//
//
//
//     // // 116.填充每个节点的下一个右侧节点指针
//     // // 117.填充每个节点的下一个右侧节点指针II
//     // // 思路：本题依然是层序遍历，只不过在单层遍历的时候记录一下本层的头部节点，然后在遍历的时候让前一个节点指向本节点就可以了
//     // class Solution {
//     // public:
//     //     Node* connect(Node* root) {
//     //         queue<Node*> que;
//     //         if (root != NULL) que.push(root);
//     //         while (!que.empty()) {
//     //             int size = que.size();
//     //             // vector<int> vec;
//     //             Node* nodePre;
//     //             Node* node;
//     //             for (int i = 0; i < size; i++) {
//     //                 if (i == 0) {
//     //                     nodePre = que.front(); // 取出一层的头结点
//     //                     que.pop();
//     //                     node = nodePre; // 赋值给node,那nodePre呢？还是指向本层的头结点吗？还是已经是野指针了？
//     //                 } else {
//     //                     node = que.front();
//     //                     que.pop();
//     //                     nodePre->next = node; // 本层前一个节点next指向本节点
//     //                     nodePre = nodePre->next; // 指针往前走一步
//     //                 }
//     //                 if (node->left) que.push(node->left);
//     //                 if (node->right) que.push(node->right);
//     //             }
//     //             nodePre->next = NULL; // 本层最后一个节点指向NULL
//     //         }
//     //         return root;
//     //
//     //     }
//     // };
//
//
//     // // 104.二叉树的最大深度
//     // // 二叉树的深度为根节点到最远叶子节点的最长路径上的节点数
//     // // 叶子节点是指没有子节点的节点
//     // class Solution {
//     // public:
//     //     int maxDepth(TreeNode* root) {
//     //         if (root == nullptr) return 0;
//     //         int depth = 0;
//     //         queue<TreeNode*> que;
//     //         que.push(root);
//     //         while(!que.empty()) {
//     //             int size = que.size();
//     //             depth++; // 记录深度
//     //             for (int i = 0; i < size; i++) {
//     //                 TreeNode* cur = que.front();
//     //                 que.pop();
//     //                 if (cur->left) que.push(cur->left);
//     //                 if (cur->right) que.push(cur->right);
//     //             }
//     //         }
//     //         return  depth;
//     //     }
//     // };
//
//
//
//     // // 111.二叉树的最小深度
//     // // 思路：层序遍历，如果遇到叶子节点，则返回最小深度即可
//     // // 需要注意的是，只有当左右孩子都为空的时候，才说明遍历的最低点了。如果其中一个孩子为空则不是最低点
//     // class Solution {
//     // public:
//     //     int minDepth(TreeNode* root) {
//     //         if (root == NULL) return 0;
//     //         int depth = 0;
//     //         queue<TreeNode*> que;
//     //         que.push(root);
//     //         while(!que.empty()) {
//     //             int size = que.size();
//     //             depth++; // 记录最小深度
//     //             for (int i = 0; i < size; i++) {
//     //                 TreeNode* node = que.front();
//     //                 que.pop();
//     //                 if (node->left) que.push(node->left);
//     //                 if (node->right) que.push(node->right);
//     //                 if (!node->left && !node->right) { // 当左右孩子都为空的时候，说明是最低点的一层了，退出
//     //                     return depth; // 这个是在层序遍历的过程中，还没有走到最深的一层时，已经遇到一个叶子节点了，直接返回最小深度即可
//     //                 }
//     //             }
//     //         }
//     //         return depth; // 这个是针对所有叶子节点的深度一致的情况，层序遍历完输出结果
//     //     }
//     // };
//
//
//
//
//     return 0;
//
// }