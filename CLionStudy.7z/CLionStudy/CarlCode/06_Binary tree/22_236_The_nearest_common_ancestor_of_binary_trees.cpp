// // #include "iostream"
//
// using namespace std;
//
// // 236. 二叉树的最近公共祖先
//
// // 二叉树如何可以自底向上查找呢？
// // 回溯啊，二叉树回溯的过程就是从低到上。
// // 后序遍历（左右中）就是天然的回溯过程，可以根据左右子树的返回值，来处理中节点的逻辑。
//
// // 二叉树的定义
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     // 构造函数，用于初始化节点
//     // 三种方式用于构建一个节点
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     // 在创建一个node的时候，需要传入一个int类型的值，作为节点的值, 初始化节点的左右子树为nullptr
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
// int main() {
//
//     // 递归：后序遍历，回溯，左右中，从下往上遍历
//     class Solution{
//     public:
//         TreeNode* lowestCommonAncestor(TreeNode* root, TreeNode* p, TreeNode* q) {
//             // 如果遇到空节点就返回null
//             // 如果根节点就是null,那就是一颗空树，返回null
//             if (root == nullptr) return nullptr; // return root;
//             // 如果遇到p/q，返回p/q
//             // 如果根节点是p/q，返回根节点，二叉树就一个节点
//             if (root == p || root == q) return root;
//
//             // 在根节点的左右节点中找
//             TreeNode* left = lowestCommonAncestor(root->left, p, q);
//             TreeNode* right = lowestCommonAncestor(root->right, p, q);
//
//             // 根节点的左右子树中各找到一个，说明根节点才是最近祖先
//             if (left && right) return root;  // if (left != nullptr && right != nullptr)
//
//             // 如果左子树中没找到，右子树找到了，那么就返回右子树好了
//             if (left == nullptr && right != nullptr) return right;
//             // 对于左子树不为空，同理
//             else if (left != nullptr && right == nullptr) return left;
//             // 否则，就是在左右都没有找到，且我们在最上边已经对根节点做了处理了， 我们这里就返回null就好了
//             else { //  (left == NULL && right == NULL)
//                 return nullptr;
//             }
//         }
//     };
//
//
//
//     // 版本1精简版
//     class Solution {
//     public:
//         TreeNode* lowestCommonAncestor(TreeNode* root, TreeNode* p, TreeNode* q) {
//             if (root == q || root == p || root == nullptr) return root;
//             TreeNode* left = lowestCommonAncestor(root->left, p, q);
//             TreeNode* right = lowestCommonAncestor(root->right, p, q);
//             if (left != nullptr && right != nullptr) return root;
//             if (left == nullptr) return right;
//             return left;
//         }
//     };
//
//
//
//
//
//
//
//     return 0;
//
// }
