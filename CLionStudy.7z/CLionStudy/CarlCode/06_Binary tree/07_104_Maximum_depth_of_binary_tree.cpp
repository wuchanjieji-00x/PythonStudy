// #include <queue>
//
// #include "iostream"
//
// using namespace std;
//
//
// // 104.二叉树的最大深度
// // 二叉树的深度为根节点到最远叶子节点的最长路径上的节点数
// // 说明: 叶子节点是指没有子节点的节点
//
// // 559.n叉树的最大深度
//
// // Definition for a binary tree node.
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
//
// // Definition for a Node.
// class Node {
// public:
//     int val;
//     vector<Node*> children;
//
//     Node() {}
//
//     Node(int _val) {
//         val = _val;
//     }
//
//     Node(int _val, vector<Node*> _children) {
//         val = _val;
//         children = _children;
//     }
// };
//
//
// int main() {
//
//
//     // 解法1：递归：后序遍历：左右中
//     // 高度=深度 （假如二者都从0开始，或都从1开始）
//     // 求高度
//     class Solution {
//     public:
//         int getDepth(TreeNode* node) {
//             // 处理根节点
//             // 同样的处理方法处理根节点的左右子节点，同时递归，将左右子节点各看作根节点
//             // 然后在这三个节点的二叉树下输出最大深度
//             if (node == nullptr) {
//                 return 0;
//             }
//             int leftDepth = getDepth(node->left); // 左
//             int rightDepth = getDepth(node->right); // 右
//             int depth = max(leftDepth, rightDepth) + 1; // 中
//             return depth;
//
//         }
//
//         int maxDepth(TreeNode* root) {
//             return getDepth(root); // 调用函数传入根节点即可
//         }
//     };
//
//
//     // 解法2：递归：前序遍历：中左右
//     // 求深度
//     // 回溯过程，没看懂？？？
//     class Solution {
//     public:
//         int result;
//         void getdepth(TreeNode* node, int depth) {
//             result = depth > result ? depth : result; // 中
//
//             if (node->left == NULL && node->right == NULL) return ;
//
//             if (node->left) { // 左
//                 depth++;    // 深度+1
//                 getdepth(node->left, depth);
//                 depth--;    // 回溯，深度-1
//             }
//             if (node->right) { // 右
//                 depth++;    // 深度+1
//                 getdepth(node->right, depth);
//                 depth--;    // 回溯，深度-1
//             }
//             return ;
//         }
//         int maxDepth(TreeNode* root) {
//             result = 0;
//             if (root == NULL) return result;
//             getdepth(root, 1);
//             return result;
//         }
//     };
//
//
//     // 解法3：迭代法的模板
//     // 在二叉树中，一层一层的来遍历二叉树，记录一下遍历的层数就是二叉树的深度
//     class Solution {
//     public:
//         int maxDepth(TreeNode* root) {
//             // 首先对根节点单独处理
//             if (root == nullptr) return 0;
//             int depth = 0;
//             queue<TreeNode*> que;
//             que.push(root);
//             while (!que.empty()) {
//                 int size = que.size();
//                 depth++;
//                 for (int i = 0; i < size; i++) {
//                     TreeNode* cur = que.front();
//                     que.pop();
//                     if (cur->left) que.push(cur->left);
//                     if (cur->right) que.push(cur->right);
//                 }
//             }
//             return depth;
//         }
//     };
//
//
//
//     // 559.n叉树的最大深度
//     // 注意这里n个节点的遍历方式
//
//     // 解法1：递归：后序遍历：左右中
//     class Solution {
//     public:
//         int maxDepth(Node* root) {
//             if (root == 0) return 0;
//             int depth = 0;
//             for (int i = 0; i < root->children.size(); i++) {
//                 depth = max (depth, maxDepth(root->children[i]));
//             }
//             return depth + 1;
//         }
//     };
//
//     // 迭代：层序遍历
//     class Solution {
//     public:
//         int maxDepth(Node* root) {
//             queue<Node*> que;
//             if (root != nullptr) que.push(root);
//             int depth = 0;
//             while (!que.empty()) {
//                 int size = que.size();
//                 depth++; // 记录深度
//                 for (int i = 0; i < size; i++) {
//                     Node* node = que.front();
//                     que.pop();
//                     for (int j = 0; j < node->children.size(); j++) {
//                         if (node->children[j]) que.push(node->children[j]);
//                     }
//                 }
//             }
//             return depth;
//         }
//     };
//
//
//
//
//
//
//     return 0;
//
// }