// // #include "iostream"
//
// #include <vector>
// using namespace std;
//
// // 654.最大二叉树
//
// // 设计到构造二叉树，都采用前序遍历
// // 构造树一般采用的是前序遍历，因为先构造中间节点，然后递归构造左子树和右子树
//
// // 二叉树的定义
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     // 构造函数，用于初始化节点
//     // 三种方式用于构建一个节点
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     // 在创建一个node的时候，需要传入一个int类型的值，作为节点的值, 初始化节点的左右子树为nullptr
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
// int main() {
//
//     // 版本1：
//     class Solution {
//     public:
//         TreeNode* constructMaximumBinaryTree(vector<int>& nums) {
//             TreeNode* node = new TreeNode(0);
//             if (nums.size() == 1) {
//                 node->val = nums[0];
//                 return node;
//             }
//             // 找到数组中最大的值和对应的下标
//             int maxValue = 0;
//             int maxValueIndex = 0;
//             for (int i = 0; i < nums.size(); i++) {
//                 if (nums[i] > maxValue) {
//                     maxValue = nums[i];
//                     maxValueIndex = i;
//                 }
//             }
//             node->val = maxValue;
//             // 最大值所在的下标左区间 构造左子树
//             if (maxValueIndex > 0) {
//                 vector<int> newVec(nums.begin(), nums.begin() + maxValueIndex);
//                 node->left = constructMaximumBinaryTree(newVec);
//             }
//             // 最大值所在的下标右区间 构造右子树
//             if (maxValueIndex < (nums.size() - 1)) {
//                 vector<int> newVec(nums.begin() + maxValueIndex + 1, nums.end());
//                 node->right = constructMaximumBinaryTree(newVec);
//             }
//             // 一般情况来说：如果让空节点（空指针）进入递归，就不加if，如果不让空节点进入递归，就加if限制一下， 终止条件也会相应的调整
//             return node;
//         }
//     };
//
//
//     // 以上代码比较冗余，效率也不高，每次还要切割的时候每次都要定义新的vector（也就是数组），但逻辑比较清晰。
//
//     // 版本2
//     // 每次分隔不用定义新的数组，而是通过下标索引直接在原数组上操作。
//     class Solution {
//     private:
//         // 在左闭右开区间[left, right)，构造二叉树
//         TreeNode* traversal(vector<int>& nums, int left, int right) {
//             if (left >= right) return nullptr;
//
//             // 分割点下标：maxValueIndex
//             int maxValueIndex = left;
//             for (int i = left + 1; i < right; ++i) {
//                 if (nums[i] > nums[maxValueIndex]) maxValueIndex = i;
//             }
//
//             TreeNode* root = new TreeNode(nums[maxValueIndex]);
//
//             // 左闭右开：[left, maxValueIndex)
//             root->left = traversal(nums, left, maxValueIndex);
//
//             // 左闭右开：[maxValueIndex + 1, right)
//             root->right = traversal(nums, maxValueIndex + 1, right);
//
//             return root;
//         }
//     public:
//         TreeNode* constructMaximumBinaryTree(vector<int>& nums) {
//             return traversal(nums, 0, nums.size());
//         }
//     };
//
//     return 0;
//
// }
