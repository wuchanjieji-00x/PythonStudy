// // #include "iostream"
//
// #include <stack>
// #include <vector>
//
// using namespace std;
//
// // 112. 路径总和
//
//
// // Definition for a binary tree node.
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
// int main() {
//
//     // 递归
//     // 如果要搜索其中一条符合条件的路径，那么递归一定需要返回值，因为遇到符合条件的路径了就要及时返回。（本题的情况）
//     class Solution {
//     private:
//         bool traversal(TreeNode* cur, int count) {
//             if (!cur->left && !cur->right && count == 0) return true; // 遇到叶子节点，并且计数为0
//             if (!cur->left && !cur->right) return false; // 遇到叶子节点直接返回
//
//             if (cur->left) { // 左
//                 // 注意这里的思路，我们把count初始化为目标值，后续只用做递减，遍历到叶子节点后如果count为0，说明找到了一条符合题意的路径
//                 // 那这样处理，我们就不用去记录每一条路径上的节点的值了
//                 count -= cur->left->val; // 递归，处理节点;
//                 if (traversal(cur->left, count)) return true; // return可删除
//                 count += cur->left->val; // 回溯，撤销处理结果
//             }
//             if (cur->right) { // 右
//                 count -= cur->right->val; // 递归，处理节点;
//                 if (traversal(cur->right, count)) return true; // return可删除
//                 count += cur->right->val; // 回溯，撤销处理结果
//             }
//             return false; // return可删除
//         }
//
//     public:
//         bool hasPathSum(TreeNode* root, int sum) {
//             if (root == nullptr) return false;
//             return traversal(root, sum - root->val);
//         }
//     };
//
//
//     // 递归精简版
//     class Solution {
//     public:
//         bool hasPathSum(TreeNode* root, int sum) {
//             if (!root) return false;
//             if (!root->left && !root->right && sum == root->val) {
//                 return true;
//             }
//             return hasPathSum(root->left, sum - root->val) || hasPathSum(root->right, sum - root->val);
//         }
//     };
//
//
//
//     // 迭代
//     class solution {
//
//     public:
//         bool haspathsum(TreeNode* root, int sum) {
//             if (root == nullptr) return false;
//             // 此时栈里要放的是pair<节点指针，路径数值>
//             stack<pair<TreeNode*, int>> st;
//             st.push(pair<TreeNode*, int>(root, root->val));
//             while (!st.empty()) {
//                 pair<TreeNode*, int> node = st.top();
//                 st.pop();
//                 // 如果该节点是叶子节点了，同时该节点的路径数值等于sum，那么就返回true
//                 if (!node.first->left && !node.first->right && sum == node.second) return true;
//
//                 // 右节点，压进去一个节点的时候，将该节点的路径数值也记录下来
//                 if (node.first->right) {
//                     st.push(pair<TreeNode*, int>(node.first->right, node.second + node.first->right->val));
//                 }
//
//                 // 左节点，压进去一个节点的时候，将该节点的路径数值也记录下来
//                 if (node.first->left) {
//                     st.push(pair<TreeNode*, int>(node.first->left, node.second + node.first->left->val));
//                 }
//             }
//             return false;
//         }
//     };
//
//
//
//     // 113. 路径总和ii
//     // 给定一个二叉树和一个目标和，找到所有从根节点到叶子节点路径总和等于给定目标和的路径
//     // 113.路径总和ii要遍历整个树，找到所有路径，所以递归函数不要返回值！
//     // 那么记录路径的变量要是全局变量，要么是函数调用时设的变量，方法只做处理，不用返回值
//     // 113.路径总和ii要遍历整个树，找到所有路径，所以递归函数不要返回值！
//
//     // 递归
//     class solution {
//     private:
//         vector<vector<int>> result;
//         vector<int> path;
//         // 递归函数不需要返回值，因为我们要遍历整个树
//         void traversal(TreeNode* cur, int count) {
//             if (!cur->left && !cur->right && count == 0) { // 遇到了叶子节点且找到了和为sum的路径
//                 result.push_back(path);
//                 return;
//             }
//
//             if (!cur->left && !cur->right) return ; // 遇到叶子节点而没有找到合适的边，直接返回
//
//             if (cur->left) { // 左 （空节点不遍历）
//                 path.push_back(cur->left->val);
//                 count -= cur->left->val;
//                 traversal(cur->left, count);    // 递归
//                 count += cur->left->val;        // 回溯
//                 path.pop_back();                // 回溯
//             }
//             if (cur->right) { // 右 （空节点不遍历）
//                 path.push_back(cur->right->val);
//                 count -= cur->right->val;
//                 traversal(cur->right, count);   // 递归
//                 count += cur->right->val;       // 回溯
//                 path.pop_back();                // 回溯
//             }
//             return ; // 这个return可以省略
//         }
//
//     public:
//         vector<vector<int>> pathSum(TreeNode* root, int sum) {
//             result.clear();
//             path.clear();
//             if (root == NULL) return result;
//             path.push_back(root->val); // 把根节点放进路径
//             traversal(root, sum - root->val);
//             return result;
//         }
//     };
//
//     // 精简版（隐藏回溯逻辑）怎么写呢？因为我并没有把path传入到递归函数中啊，count倒是可以
//     // 那就把count写进参数列表中，pop操作不能省
//
//     return 0;
//
// }
