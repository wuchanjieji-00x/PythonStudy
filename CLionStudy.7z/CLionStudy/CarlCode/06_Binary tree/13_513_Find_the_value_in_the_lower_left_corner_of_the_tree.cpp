//
//
// #include <climits>
// #include <queue>
//
//
// using namespace std;
//
// // 513.找树左下角的值
//
//
// // Definition for a binary tree node.
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
// int main() {
//
//     // 解法1：递归
//     // 本题前中后序都可以，无所谓，因为中节点也没有处理逻辑
//     class Solution {
//     public:
//         int maxDepth = INT_MIN;
//         int result;
//         void traversal(TreeNode* root, int depth) {
//             // 递归终止条件:遍历到叶子节点的处理逻辑
//             if (root->left == NULL && root->right == NULL) {
//                 if (depth > maxDepth) {
//                     // 先找到左子树最大的深度对应的最左节点的值
//                     // 为什么能先找到左子树呢？因为后面的递归，左子树在前面，除非右子树的深度比我大，不然就用左子树的值
//                     // 为什么能先找到最大深度的最左节点呢？同理，后面的递归，左子树在前面
//                     maxDepth = depth;
//                     result = root->val;
//                 }
//                 return; // 递归终止
//             }
//             // 根节点左子树的递归逻辑
//             if (root->left) {
//                 depth++;
//                 traversal(root->left, depth);
//                 depth--; // 回溯
//             }
//             // 根节点右子树的递归逻辑
//             if (root->right) {
//                 depth++;
//                 traversal(root->right, depth);
//                 depth--; // 回溯
//             }
//             return; // 函数终止，可不写，因为我们是对全局变量做了处理，只用处理，不需要返回；下面的调用者会将全局变量返回出去
//         }
//         int findBottomLeftValue(TreeNode* root) {
//             traversal(root, 0);
//             return result;
//         }
//     };
//
//
//     // 解法1精简版
//     class Solution {
//     public:
//         int maxDepth = INT_MIN;
//         int result;
//         void traversal(TreeNode* root, int depth) {
//             if (root->left == nullptr && root->right == nullptr) {
//                 if (depth > maxDepth) {
//                     maxDepth = depth;
//                     result = root->val;
//                 }
//                 return;
//             }
//             if (root->left) {
//                 traversal(root->left, depth + 1); // 隐藏着回溯，因为只有进去的时候会改变depth的值，出来后，depth的值还是之前的
//             }
//             if (root->right) {
//                 traversal(root->right, depth + 1); // 隐藏着回溯
//             }
//             return;
//         }
//         int findBottomLeftValue(TreeNode* root) {
//             traversal(root, 0);
//             return result;
//         }
//     };
//
//
//
//     // 解法2：迭代
//     // 只需要记录最后一行第一个节点的数值就可以了。
//     class Solution {
//     public:
//         int findBottomLeftValue(TreeNode* root) {
//             queue<TreeNode*> que;
//             if (root != nullptr) que.push(root);
//             int result = 0;
//             while (!que.empty()) {
//                 int size = que.size();
//                 for (int i = 0; i < size; i++) {
//                     TreeNode* node = que.front();
//                     que.pop();
//                     if (i == 0) result = node->val; // 记录每一行第一个元素，即左下角元素；遍历一行，更新一次
//                     if (node->left) que.push(node->left);
//                     if (node->right) que.push(node->right);
//                 }
//             }
//             return result;
//         }
//     };
//
//     return 0;
//
// }