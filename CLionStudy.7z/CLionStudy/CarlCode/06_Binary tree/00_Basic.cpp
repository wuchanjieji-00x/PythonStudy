//
//
//
// // 二叉树的定义
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     // 构造函数，用于初始化节点
//     // 三种方式用于构建一个节点
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     // 在创建一个node的时候，需要传入一个int类型的值，作为节点的值, 初始化节点的左右子树为nullptr
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };

// // Definition for a Node.
// class Node {
// public:
//     int val;
//     vector<Node*> children;
//
//     Node() {}
//
//     Node(int _val) {
//         val = _val;
//     }
//
//     Node(int _val, vector<Node*> _children) {
//         val = _val;
//         children = _children;
//     }
// };

//
// // 二叉树上的每个节点本质上都是一个结构体，结构体中包括：元素值，左子树指针，右子树指针
//
//
//
// // 创建一个二叉树
// TreeNode *root = new TreeNode(1);
// root->left = new TreeNode(2);
// root->right = new TreeNode(3);
// root->left->left = new TreeNode(4);
// root->left->right = new TreeNode(5);
// root->right->left = new TreeNode(6);
// root->right->right = new TreeNode(7);


/* 递归
 * 1、确定递归函数的参数和返回值
 *
 * 2、递归终止条件:遍历到叶子节点的处理逻辑。这里面一定有return,作为递归的终止条件
 * 一般来说搜到叶子节点了，也就找到了满足条件的一条答案，把这个答案存放起来，并结束本层递归
 *
 * 如果递归是有返回值的，那么左右子树的递归结果一定需要一个变量接住
 * 3、根节点左子树的递归逻辑 （注意显式回溯和隐式回溯） // 左右顺序可颠倒，看题目要求
 * 3、根节点右子树的递归逻辑 （注意显式回溯和隐式回溯）
 *
 * 4、返回值：函数结束标志。分情况，
 * 如果递归函数不需要返回值，则这里不需要写，只做处理，正确终止递归即可、
 * 如果递归函数需要返回值，这里必须有return。return的逻辑也要分情况
 * A：如果返回值是随着遍历变化的值，需要记录，那我们要声明一个变量，在递归中不断更新，直至最后输出。在递归中不要return这个值
 * B：如果返回值是一个bool量，要么我们也定义一个变量去不断更新true或者false；
 * 要么每一次递归都返回一个bool值，然后最后的return给一个默认的false和true作为返回值
 *
 * 如果递归函数有返回值，如何区分要搜索一条边，还是搜索整个树呢？
 * 搜索一条边的写法：
 * if (递归函数(root->left)) return;
 * if (递归函数(root->right)) return;
 * 搜索整个树写法：
 * left = 递归函数(root->left);  // 左
 * right = 递归函数(root->right); // 右
 * left与right的逻辑处理;         // 中
 */


// 一提到二叉树遍历的迭代法，可能立刻想起使用栈来模拟深度遍历，使用队列来模拟广度遍历


// 在写递归函数的单层递归逻辑时：
// 分三个节点：根节点，根节点的左子树，根节点的右子树。遍历顺序就是三个节点的上下顺序
// 那么根节点的左右子树的处理直接交给递归函数，根节点的处理也就是中的处理逻辑就是所谓的单层递归逻辑中的重点逻辑
// 此时，就要根据遍历顺序把根节点看作不同的节点来处理，请体会这种感觉
// 比如，前序遍历：中左右，需要把根节点看作每一层的中节点来看
// 后序遍历：左右中，需要把根节点也看作每一层的中节点
// 中序遍历（左中右）或反中序遍历（右左中）：需要把根节点看作二叉树的最右侧叶子节点
