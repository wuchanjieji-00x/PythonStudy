// // #include "iostream"
//
// #include <Climits>
// #include <stack>
// #include <vector>
// using namespace std;
//
// // 530.二叉搜索树的最小绝对差
//
// // 二叉树的定义
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     // 构造函数，用于初始化节点
//     // 三种方式用于构建一个节点
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     // 在创建一个node的时候，需要传入一个int类型的值，作为节点的值, 初始化节点的左右子树为nullptr
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
//
// int main() {
//
//     // 注意是二叉搜索树，二叉搜索树可是有序的。
//     // 遇到在二叉搜索树上求什么最值啊，差值之类的，就把它想成在一个有序数组上求最值，求差值，这样就简单多了。
//
//     // 递归：新开辟一个数组，将BSR转化为数组
//     class Solution {
//     private:
//         vector<int> vec;
//         void traversal(TreeNode* root) {
//             if (root == nullptr) return;
//
//             traversal(root->left);
//             vec.push_back(root->val);  // 将二叉搜索树转换为有序数组
//             traversal(root->right);
//
//         }
//
//     public:
//         int getMinimumDifference(TreeNode* root) {
//             vec.clear();
//             traversal(root);
//
//             if (vec.size() < 2) return 0;  // 数组里只有一个元素，不存在差值。即二叉树只有一个根节点
//             // 将二叉树转化为递增数组后，那么任意节点的差值的最小值，肯定是相邻节点的差值的最小值
//             int result = INT_MAX;
//             for (int i = 1; i < vec.size(); i++) {
//                 result = min(result, vec[i] - vec[i - 1]);
//             }
//             return result;
//         }
//     };
//
//
//
//     // 递归：双指针
//     // 前序遍历BSR，节点值一定是递增的。那么任意节点的差值的最小值，肯定是相邻节点的差值的最小值
//     class Solution {
//     private:
//         int result = INT_MAX;
//         TreeNode* pre =nullptr;
//         void traversal(TreeNode* cur) {
//             if (cur == nullptr) return;
//
//             traversal(cur->left); // 左
//             if (pre != nullptr) { // 中
//                 result = min (result, cur->val - pre->val);
//             }
//             pre = cur; // 记录前一个   / 双指针精髓
//             traversal(cur->right); // 中
//         }
//
//     public:
//         int getMinimumDifference(TreeNode* root) {
//             traversal(root);
//             return result; // result被定义为全局变量，我们在私有方法中将其做了处理，这里直接返回即可
//         }
//     };
//
//
//
//     // 迭代：双指针
//     class Solution {
//     public:
//         int getMinimumDifference(TreeNode* root) {
//             stack<TreeNode*> st;
//             TreeNode* cur = root;
//             TreeNode* pre = nullptr;
//             int result = INT_MAX;
//
//             while (cur != nullptr || !st.empty()) {
//                 if (cur != nullptr) {
//                     st.push(cur);
//                     cur = cur->left; // 左
//                 }else {
//                     cur = st.top();
//                     st.pop();
//
//                     if (pre != nullptr) { // 中
//                         result = min(result, cur->val - pre->val);
//                     }
//                     pre = cur;
//                     cur = cur->right; // 右
//                 }
//             }
//             return  result;
//         }
//     };
//
//
//
//
//
//
//
//
//     return 0;
//
// }