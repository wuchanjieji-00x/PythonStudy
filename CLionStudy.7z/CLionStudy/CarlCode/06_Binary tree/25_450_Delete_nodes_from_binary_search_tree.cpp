// // #include "iostream"
// #include <algorithm>
// using namespace std;
//
// // 450.删除二叉搜索树中的节点
// // 难点在于第五种情况
//
// // 二叉树的定义
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     // 构造函数，用于初始化节点
//     // 三种方式用于构建一个节点
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     // 在创建一个node的时候，需要传入一个int类型的值，作为节点的值, 初始化节点的左右子树为nullptr
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
//
// int main() {
//
//     // 递归
//     class Solution {
//     public:
//         TreeNode* deleteNode(TreeNode* root, int key) {
//             // 根节点是空节点，BST是空树
//             if (root == nullptr) return root; // 第一种情况：没找到删除的节点，遍历到空节点直接返回了
//             if (root->val == key) { // 假设删除的是根节点
//                 // 第二种情况：左右孩子都为空（叶子节点），直接删除节点， 返回NULL为根节点、
//                 // BST只有一个节点，直接删除，返回NULL为根节点
//                 if (root->left == nullptr && root->right == nullptr) {
//                     delete root; ///! 内存释放
//                     return nullptr;
//                 }
//                 // 第三种情况：其左孩子为空，右孩子不为空，删除节点，右孩子补位 ，返回右孩子为根节点
//                 // BST的根节点只有右孩子，那么删除根节点之后，直接返回根节点的右孩子的指针
//                 else if(root->left == nullptr) {
//                     auto retNode = root->right;
//                     delete root; ///! 内存释放
//                     return  retNode;
//                 }
//                 // 第四种情况：其右孩子为空，左孩子不为空，删除节点，左孩子补位，返回左孩子为根节点
//                 // BST的根节点只有左孩子，那么删除根节点之后，直接返回根节点的左孩子的指针
//                 else if (root->right == nullptr) {
//                     auto retNode = root->left;
//                     delete root; ///! 内存释放
//                     return retNode;
//                 }
//                 // 第五种情况：左右孩子节点都不为空，则将删除节点的左子树放到删除节点的右子树的最左面节点的左孩子的位置
//                 // 并返回删除节点右孩子为新的根节点
//                 // 要放的位置是为了保持BST的特性
//                 // 根节点的左右孩子都不为空，而且我们删除的根节点，那么根据BST的特性，
//                 // 我们要把根节点的左孩子直接放到，根节点的右孩子的最左侧叶子节点的左孩子的位置
//                 else { // root->left != nullptr && root->right != nullptr
//                     TreeNode* cur = root->right;
//                     while (cur->left != nullptr) { // 找右子树最左面的节点
//                         cur = cur->left;
//                     } // cur已经指向根节点右孩子的最左侧叶子节点
//                     // 因为这里假设删除的是根节点，所以我们把根节点的左孩子，放到，根节点的右孩子的最左侧叶子节点的左孩子的位置，划重点！！
//                     cur->left = root->left; // 把要删除的节点（root）左子树放在cur的左孩子的位置
//                     TreeNode* tmp = root; // 这里做了个引用，下行其实用tmp->left赋值也可  // 把root节点保存一下，下面来删除
//                     root = root->left; // 返回旧root的右孩子作为新root
//                     delete tmp; ///! 内存释放  // 释放节点内存（这里不写也可以，但C++最好手动释放一下吧）
//                     return root;
//                 }
//             }
//
//             // 如果要删除的点不是根节点，那么根据BST的特性，选取方向进行递归
//             // 因为要删除的点不是根节点，但题目要求我们返回的是新BST的根节点，所以我们要拿到原BST的左右孩子返回的根节点，
//             // 再和原先的根节点一起组成新的BST，最后返回新BST的根节点
//             if (root->val > key) root->left = deleteNode(root->left, key);
//             if (root->val < key) root->right = deleteNode(root->right, key);
//             return root;
//         }
//     };
//
//
//     // 那么情况再普遍一点，如果不是BST，是普通二叉树呢？
//
//     // 递归
//     // 有点绕
//     class Solution {
//     public:
//         TreeNode* deleteNode(TreeNode* root, int key) {
//             if (root == nullptr) return root;
//             if (root->val == key) {
//                 if (root->right == nullptr) { // 这里第二次操作目标值：最终删除的作用
//                     return root->left;
//                 }
//                 TreeNode *cur = root->right;
//                 while (cur->left) {
//                     cur = cur->left;
//                 }
//                 swap(root->val, cur->val); // 这里第一次操作目标值：交换目标值其右子树最左面节点。
//             }
//             root->left = deleteNode(root->left, key);
//             root->right = deleteNode(root->right, key);
//             return root;
//         }
//     };
//
//
//     // 迭代
//     // 没看懂
//     class Solution {
//     private:
//         // 将目标节点（删除节点）的左子树放到 目标节点的右子树的最左面节点的左孩子位置上
//         // 并返回目标节点右孩子为新的根节点
//         // 是动画里模拟的过程
//         TreeNode* deleteOneNode(TreeNode* target) {
//             if (target == nullptr) return target;
//             if (target->right == nullptr) return target->left;
//             TreeNode* cur = target->right;
//             while (cur->left) {
//                 cur = cur->left;
//             }
//             cur->left = target->left;
//             return target->right;
//         }
//     public:
//         TreeNode* deleteNode(TreeNode* root, int key) {
//             if (root == nullptr) return root;
//             TreeNode* cur = root;
//             TreeNode* pre = nullptr; // 记录cur的父节点，用来删除cur
//             while (cur) {
//                 if (cur->val == key) break;
//                 pre = cur;
//                 if (cur->val > key) cur = cur->left;
//                 else cur = cur->right;
//             }
//             if (pre == nullptr) { // 如果搜索树只有头结点
//                 return deleteOneNode(cur);
//             }
//             // pre 要知道是删左孩子还是右孩子
//             if (pre->left && pre->left->val == key) {
//                 pre->left = deleteOneNode(cur);
//             }
//             if (pre->right && pre->right->val == key) {
//                 pre->right = deleteOneNode(cur);
//             }
//             return root;
//         }
//     };
//
//     return 0;
//
// }