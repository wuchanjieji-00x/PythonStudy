// // #include "iostream"
//
// using namespace std;
//
// // 701.二叉搜索树中的插入操作
// // 只要遍历二叉搜索树，找到空节点（叶子节点的子节点或者空树） 插入元素就可以了，那么这道题其实就简单了。
// // 但是如果是平衡二叉树就麻烦了，因为不能要让相邻的节点的深度不能超过1
//
//
// // 二叉树的定义
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     // 构造函数，用于初始化节点
//     // 三种方式用于构建一个节点
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     // 在创建一个node的时候，需要传入一个int类型的值，作为节点的值, 初始化节点的左右子树为nullptr
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
// int main() {
//
//     // 递归，有返回值
//     // 有返回值的话，可以利用返回值完成新加入的节点与其父节点的赋值操作
//     class Solution {
//     public:
//         TreeNode* insertIntoBST(TreeNode* root, int val) {
//             if (root == nullptr) {
//                 TreeNode* node = new TreeNode(val);
//                 return node;
//             }
//             if (root->val > val) root->left = insertIntoBST(root->left, val);
//             if (root->val < val) root->right = insertIntoBST(root->right, val);
//             return root;
//         }
//     };
//
//
//     // 递归，没有返回值
//     // 之所以举这个例子，是想说明通过递归函数的返回值完成父子节点的赋值是可以带来便利的。
//     class Solution {
//     private:
//         TreeNode* parent;
//         void traversal(TreeNode* cur, int val) {
//             if (cur == nullptr) {
//                 TreeNode* node = new TreeNode(val);
//                 if (val > parent->val) parent->right = node;
//                 else parent->left = node;
//                 return;
//             }
//             parent = cur;
//             if (cur->val > val) traversal(cur->left, val);
//             if (cur->val < val) traversal(cur->right, val);
//             return;
//         }
//
//     public:
//         TreeNode* insertIntoBST(TreeNode* root, int val) {
//             parent = new TreeNode(0);
//             if (root == nullptr) {
//                 root = new TreeNode(val);
//             }
//             traversal(root, val);
//             return root;
//         }
//     };
//
//
//
//     // 迭代
//     class Solution {
//     public:
//         TreeNode* insertIntoBST(TreeNode* root, int val) {
//             if (root == nullptr) {
//                 TreeNode* node = new TreeNode(val);
//                 return node;
//             }
//             TreeNode* cur = root;
//             TreeNode* parent = root; // 这个很重要，需要记录上一个节点，否则无法赋值新节点
//             while (cur != nullptr) {
//                 parent = cur;
//                 if (cur->val > val) cur = cur->left;
//                 else cur = cur->right;
//             }
//             TreeNode* node = new TreeNode(val);
//             if (val < parent->val) parent->left = node;// 此时是用parent节点的进行赋值
//             else parent->right = node;
//             return root;
//         }
//     };
//
//
//
//
//
//
//
//     return 0;
//
// }
