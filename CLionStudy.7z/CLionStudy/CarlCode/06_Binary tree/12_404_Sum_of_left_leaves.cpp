//
//
// #include <stack>
// #include <stddef.h>
// using namespace std;
//
// // 404.左叶子之和
//
//
// // Definition for a binary tree node.
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
// int main() {
//
//     // 解法1：递归
//     // 判断当前节点是不是左叶子是无法判断的，必须要通过节点的父节点来判断其左孩子是不是左叶子
//     // 节点A的左孩子不为空，且左孩子的左右孩子都为空（说明是叶子节点），那么A节点的左孩子为左叶子节点
//     class Solution {
//     public:
//         int sumOfLeftLeaves(TreeNode* root) {
//             if (root == nullptr) return 0;
//             if (root->left == nullptr && root->right == nullptr) return 0; // 只有根节点的情况，左叶子为空
//
//             int leftValue = sumOfLeftLeaves(root->left); // 左
//             if (root->left && !root->left->left && !root->left->right) { // 左子树就是一个左叶子的情况
//                 leftValue = root->left->val;
//             }
//             int rightValue = sumOfLeftLeaves(root->right); // 右
//
//             int sum = leftValue + rightValue; // 中
//             return sum;
//         }
//     };
//
//
//     // 解法1：精简版
//     class Solution {
//     public:
//         int sumOfLeftLeaves(TreeNode* root) {
//             if (root == nullptr) return 0;
//             int leftValue = 0;
//             if (root->left != nullptr && root->left->left == nullptr && root->left->right == nullptr) {
//                 leftValue = root->left->val;
//             }
//             return leftValue + sumOfLeftLeaves(root->left) + sumOfLeftLeaves(root->right);
//         }
//     };
//
//
//
//     // 解法2：迭代
//     class Solution {
//     public:
//         int sumOfLeftLeaves(TreeNode* root) {
//             stack<TreeNode*> st;
//             if (root == nullptr) return 0;
//             st.push(root);
//             int result = 0;
//             while (!st.empty()) {
//                 TreeNode* node = st.top();
//                 st.pop();
//                 if (node->left != nullptr && node->left->left == nullptr && node->left->right == nullptr) {
//                     result += node->left->val;
//                 }
//                 if (node->right) st.push(node->right);
//                 if (node->left) st.push(node->left);
//             }
//             return result;
//         }
//     };
//
//
//
//     return 0;
//
// }
