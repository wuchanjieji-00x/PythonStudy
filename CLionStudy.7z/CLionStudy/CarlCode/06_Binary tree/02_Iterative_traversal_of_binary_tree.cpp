// #include "iostream"
// #include <vector>
// #include <stack>
// #include <algorithm>
//
//
// using namespace std;
//
// // 二叉树的迭代遍历
//
//
// /*
// 144.二叉树的前序遍历
// 145.二叉树的后序遍历
// 94.二叉树的中序遍历
// */
//
// // 二叉树的定义
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
// };
//
// int main() {
//
//     // 二叉树三种迭代遍历方式：
//     // 前序遍历：中左右
//     class Solution {
//     public:
//         vector<int> preorderTraversal(TreeNode* root) {
//             stack<TreeNode*> st; // 栈里的元素都是当前节点的指针
//             vector<int> result;
//             if (root == nullptr) return result;
//             st.push(root);
//             while (!st.empty()) {
//                 // 这里相当于我弹出栈顶元素，也就是当前节点，然后我就把当前节点的左右子节点都加进来，直至访问至叶子节点
//                 // 那么就直接将叶子节点的值弹出去加到vector中
//                 TreeNode* cur = st.top(); // 中  // cur是个指针变量，一直指向的是栈顶节点
//                 st.pop();
//                 result.push_back(cur->val);
//                 // 为什么要先加入 右孩子，再加入左孩子呢？ 因为这样出栈的时候才是中左右的顺序
//                 if (cur->right != nullptr) st.push(cur->right); // 右（空节点不入栈）
//                 if (cur->left != nullptr) st.push(cur->left); // 左（空节点不入栈）
//             }
//             return result;
//         }
//     };
//     // 中序遍历：左中右
//     class Solution {
//     public:
//         vector<int> inorderTraversal(TreeNode* root) {
//             stack<TreeNode*> st; // 栈里的元素都是当前节点的指针
//             vector<int> result;
//             TreeNode* cur = root;
//
//             while (cur != nullptr || !st.empty()) {
//                 while (cur != nullptr) { // 指针来访问节点，访问到最底层
//                     st.push(cur); // 将访问的节点放进栈
//                     cur = cur->left; // 一直到叶子节点的左孩子，退出循环
//                 }
//                 cur = st.top(); // 从栈里弹出的数据，就是要处理的数据（放进result数组里的数据）
//                 st.pop();
//                 result.push_back(cur->val);
//                 // 假设二叉树高度为3
//                 // 首先输出最左边的叶子节点，然后指针指向最左边叶子节点的右孩子，为空，然后循环再进来，此时弹出最左边叶子节点的父节点
//                 // 然后指针指向最左边叶子节点的父节点的右孩子（也是叶子节点）循环再进来，输出最左边叶子节点的同父右叶子节点
//                 // 之后再去遍历该叶子节点的左右子节点都为空，输出根节点，然后指针指向根节点的右孩子。循环。
//                 cur = cur->right;
//             }
//         }
//     };
//
//     // 后序遍历：左右中
//     // 前序遍历是左中右，调整代码左右顺序→左右中，反转result数组→左右中，得到后序遍历
//     class Solution {
//     public:
//         vector<int> postorderTraversal(TreeNode* root) {
//             stack<TreeNode*> st; // 栈里的元素都是当前节点的指针
//             vector<int> result;
//             if (root == nullptr) return result;
//             st.push(root);
//             while (!st.empty()) {
//                 // 这里相当于我弹出栈顶元素，也就是当前节点，然后我就把当前节点的左右子节点都加进来，直至访问至叶子节点
//                 // 那么就直接将叶子节点的值弹出去加到vector中
//                 TreeNode* cur = st.top(); // 中  // cur是个指针变量，一直指向的是栈顶节点
//                 st.pop();
//                 result.push_back(cur->val);
//                 // 调整顺序后，出栈的时候是中右左的顺序
//                 if (cur->left != nullptr) st.push(cur->left); // // 相对于前序遍历，这更改一下入栈顺序 左（空节点不入栈）
//                 if (cur->right != nullptr) st.push(cur->right); // 右（空节点不入栈）
//             }
//             reverse(result.begin(), result.end()); // 将结果反转之后就是左右中的顺序了
//             return result;
//         }
//     };
//
//     return 0;
//
// }