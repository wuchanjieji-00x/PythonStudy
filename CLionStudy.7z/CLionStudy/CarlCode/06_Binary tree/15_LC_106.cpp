// #include "iostream"
//
// #include <vector>
// using namespace std;
//
// // 106.从中序与后序遍历序列构造二叉树
//
// // 设计到构造二叉树，都采用前序遍历
//
// // Definition for a binary tree node.
// struct TreeNode {
//     int val;
//     TreeNode *left;
//     TreeNode *right;
//     TreeNode() : val(0), left(nullptr), right(nullptr) {}
//     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
//     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
// };
//
// int main() {
//
//     // 解法1：递归：切割区间
//     class Solution {
//     private:
//         // 参数是中序数组和后序数组，返回值是根节点
//         TreeNode* traversal (vector<int>& inorder, vector<int>& postorder) {
//             // 递归终止条件:
//             // 遍历到叶子节点的处理逻辑：如果后序数组为空，说明遍历到了叶子节点，那对叶子节点再去找子节点就是空指针了
//             // 或者说，如果二叉树是一颗空树。 可是空树的逻辑已经在调用函数那里做过了啊
//             if (postorder.size() == 0) return nullptr;
//             // 注意：前序数组和后序数组的节点数目肯定是相同的
//
//             // 后序遍历数组最后一个元素，就是当前的中间节点
//             // 或者说，后序遍历数组最后一个元素，就是这棵树的根节点
//             int rootValue = postorder[postorder.size() - 1];
//             TreeNode* root = new TreeNode(rootValue);
//
//             // 叶子节点
//             // 或者说，如果后序数组只有一个元素，说明这棵树只有一个节点，那么这个节点就是根节点,也是叶子节点
//             if (postorder.size() == 1) return root;
//
//             // 找到中序遍历的切割点
//             // 在后序数组中找到根节点，那么在中序数组中找到这个根节点对应的下标，这个下标前面是左子树的节点，后面是右子树的节点
//             int delimiterIndex;
//             for (delimiterIndex = 0; delimiterIndex < inorder.size(); delimiterIndex++) {
//                 if (inorder[delimiterIndex] == rootValue) break;
//             }
//
//             // 切割中序数组
//             // 左闭右开区间：[0, delimiterIndex)
//             vector<int> leftInorder(inorder.begin(), inorder.begin() + delimiterIndex);
//             // [delimiterIndex + 1, end)
//             vector<int> rightInorder(inorder.begin() + delimiterIndex + 1, inorder.end() );
//
//             // postorder 舍弃末尾元素
//             // 在获取右后序数组时，移除根节点，所以这里要减一
//             postorder.resize(postorder.size() - 1);
//
//             // 切割后序数组
//             // 依然左闭右开，注意这里使用了左中序数组大小作为切割点
//             // [0, leftInorder.size)
//             vector<int> leftPostorder(postorder.begin(), postorder.begin() + leftInorder.size());
//             // [leftInorder.size(), end)
//             vector<int> rightPostorder(postorder.begin() + leftInorder.size(), postorder.end());
//
//             // 以下为日志
//             cout << "----------" << endl;
//
//             cout << "leftInorder :";
//             for (int i : leftInorder) {
//                 cout << i << " ";
//             }
//             cout << endl;
//
//             cout << "rightInorder :";
//             for (int i : rightInorder) {
//                 cout << i << " ";
//             }
//             cout << endl;
//
//             cout << "leftPostorder :";
//             for (int i : leftPostorder) {
//                 cout << i << " ";
//             }
//             cout << endl;
//             cout << "rightPostorder :";
//             for (int i : rightPostorder) {
//                 cout << i << " ";
//             }
//             cout << endl;
//
//             // 分别以根节点的左右节点为根节点，递归
//             root->left = traversal(leftInorder, leftPostorder);
//             root->right = traversal(rightInorder, rightPostorder);
//
//             return root;
//         }
//     public:
//         TreeNode* buildTree(vector<int>& inorder, vector<int>& postorder) {
//             if (inorder.size() == 0 || postorder.size() == 0) return nullptr;
//             return traversal(inorder, postorder);
//         }
//     };
//
//
//     // 解法2：递归：下标索引
//     // 下面给出用下标索引写出的代码版本：（思路是一样的，只不过不用重复定义vector了，每次用下标索引来分割）
//     class Solution {
//     private:
//         // 中序区间：[inorderBegin, inorderEnd)，后序区间[postorderBegin, postorderEnd)
//         TreeNode* traversal (vector<int>& inorder, int inorderBegin, int inorderEnd, vector<int>& postorder, int postorderBegin, int postorderEnd) {
//             if (postorderBegin == postorderEnd) return nullptr;
//
//             int rootValue = postorder[postorderEnd - 1]; // 根节点是后序数组的最后一个元素
//             TreeNode* root = new TreeNode(rootValue);
//
//             if (postorderEnd - postorderBegin == 1) return root;
//
//             int delimiterIndex;
//             for (delimiterIndex = inorderBegin; delimiterIndex < inorderEnd; delimiterIndex++) {
//                 if (inorder[delimiterIndex] == rootValue) break;
//             }
//             // 切割中序数组
//             // 左中序区间，左闭右开[leftInorderBegin, leftInorderEnd)
//             int leftInorderBegin = inorderBegin;
//             int leftInorderEnd = delimiterIndex;
//             // 右中序区间，左闭右开[rightInorderBegin, rightInorderEnd)
//             int rightInorderBegin = delimiterIndex + 1;
//             int rightInorderEnd = inorderEnd;
//
//             // 切割后序数组
//             // 左后序区间，左闭右开[leftPostorderBegin, leftPostorderEnd)
//             int leftPostorderBegin =  postorderBegin;
//             int leftPostorderEnd = postorderBegin + delimiterIndex - inorderBegin; // 终止位置是 需要加上 中序区间的大小size
//             // 右后序区间，左闭右开[rightPostorderBegin, rightPostorderEnd)
//             int rightPostorderBegin = postorderBegin + (delimiterIndex - inorderBegin);
//             int rightPostorderEnd = postorderEnd - 1; // 排除最后一个元素，已经作为节点了
//
//             // 以下为日志
//             cout << "----------" << endl;
//             cout << "leftInorder :";
//             for (int i = leftInorderBegin; i < leftInorderEnd; i++) {
//                 cout << inorder[i] << " ";
//             }
//             cout << endl;
//
//             cout << "rightInorder :";
//             for (int i = rightInorderBegin; i < rightInorderEnd; i++) {
//                 cout << inorder[i] << " ";
//             }
//             cout << endl;
//
//             cout << "leftpostorder :";
//             for (int i = leftPostorderBegin; i < leftPostorderEnd; i++) {
//                 cout << postorder[i] << " ";
//             }
//             cout << endl;
//
//             cout << "rightpostorder :";
//             for (int i = rightPostorderBegin; i < rightPostorderEnd; i++) {
//                 cout << postorder[i] << " ";
//             }
//             cout << endl;
//
//
//             // 分别以根节点的左右节点为根节点，递归
//             root->left = traversal(inorder, leftInorderBegin, leftInorderEnd,  postorder, leftPostorderBegin, leftPostorderEnd);
//             root->right = traversal(inorder, rightInorderBegin, rightInorderEnd, postorder, rightPostorderBegin, rightPostorderEnd);
//
//             return root;
//         }
//     public:
//         TreeNode* buildTree(vector<int>& inorder, vector<int>& postorder) {
//             if (inorder.size() == 0 || postorder.size() == 0) return nullptr;
//             // 左闭右开的原则
//             return traversal(inorder, 0, inorder.size(), postorder, 0, postorder.size());
//         }
//     };
//
//
//
//     // 105.从前序与中序遍历序列构造二叉树
//     // 递归，带日志
//     class Solution {
// private:
//         TreeNode* traversal (vector<int>& inorder, int inorderBegin, int inorderEnd, vector<int>& preorder, int preorderBegin, int preorderEnd) {
//         if (preorderBegin == preorderEnd) return nullptr;
//
//         int rootValue = preorder[preorderBegin]; // 注意用preorderBegin 不要用0
//         TreeNode* root = new TreeNode(rootValue);
//
//         if (preorderEnd - preorderBegin == 1) return root;
//
//         int delimiterIndex;
//         for (delimiterIndex = inorderBegin; delimiterIndex < inorderEnd; delimiterIndex++) {
//             if (inorder[delimiterIndex] == rootValue) break;
//         }
//         // 切割中序数组
//         // 中序左区间，左闭右开[leftInorderBegin, leftInorderEnd)
//         int leftInorderBegin = inorderBegin;
//         int leftInorderEnd = delimiterIndex;
//         // 中序右区间，左闭右开[rightInorderBegin, rightInorderEnd)
//         int rightInorderBegin = delimiterIndex + 1;
//         int rightInorderEnd = inorderEnd;
//
//         // 切割前序数组
//         // 前序左区间，左闭右开[leftPreorderBegin, leftPreorderEnd)
//         int leftPreorderBegin =  preorderBegin + 1;
//         int leftPreorderEnd = preorderBegin + 1 + delimiterIndex - inorderBegin; // 终止位置是起始位置加上中序左区间的大小size
//         // 前序右区间, 左闭右开[rightPreorderBegin, rightPreorderEnd)
//         int rightPreorderBegin = preorderBegin + 1 + (delimiterIndex - inorderBegin);
//         int rightPreorderEnd = preorderEnd;
//
//         // // 以下为日志
//         // cout << "----------" << endl;
//         // cout << "leftInorder :";
//         // for (int i = leftInorderBegin; i < leftInorderEnd; i++) {
//         //     cout << inorder[i] << " ";
//         // }
//         // cout << endl;
//         //
//         // cout << "rightInorder :";
//         // for (int i = rightInorderBegin; i < rightInorderEnd; i++) {
//         //     cout << inorder[i] << " ";
//         // }
//         // cout << endl;
//         //
//         // cout << "leftPreorder :";
//         // for (int i = leftPreorderBegin; i < leftPreorderEnd; i++) {
//         //     cout << preorder[i] << " ";
//         // }
//         // cout << endl;
//         //
//         // cout << "rightPreorder :";
//         // for (int i = rightPreorderBegin; i < rightPreorderEnd; i++) {
//         //     cout << preorder[i] << " ";
//         // }
//         // cout << endl;
//
//         // 以下为日志
//         root->left = traversal(inorder, leftInorderBegin, leftInorderEnd,  preorder, leftPreorderBegin, leftPreorderEnd);
//         root->right = traversal(inorder, rightInorderBegin, rightInorderEnd, preorder, rightPreorderBegin, rightPreorderEnd);
//
//         return root;
//     }
//
// public:
//     TreeNode* buildTree(vector<int>& preorder, vector<int>& inorder) {
//         if (inorder.size() == 0 || preorder.size() == 0) return nullptr;
//         // 参数坚持左闭右开的原则
//         return traversal(inorder, 0, inorder.size(), preorder, 0, preorder.size());
//
//     }
// };
//
//
//
//
//
//
//
//     return 0;
//
// }
