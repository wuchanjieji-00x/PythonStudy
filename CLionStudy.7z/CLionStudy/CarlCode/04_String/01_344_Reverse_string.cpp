// #include "iostream"
// #include <vector>
//
// using namespace std;
//
// // 344.反转字符串
// // reverse库函数的实现
//
//
//
//
// int main() {
//
//     // 解法1：
//     // 时间复杂度: O(n)
//     // 空间复杂度: O(1)
//     class Solution {
//     public:
//         void reverseString(vector<char>& s) {
//             for (int i = 0, j = s.size()-1; i < s.size()/2; i++, j--) { // 注意这里是小于号
//                 swap(s[i], s[j]);
//             }
//         }
//     };
//
//
//
//     // 解法2：
//     // 时间复杂度：O(N)，其中 N 为字符数组的长度。一共执行了 N/2 次的交换。
//     // 空间复杂度：O(1)。只使用了常数空间来存放若干变量
//     class Solution {
//     public:
//         void reverseString(vector<char>& s) {
//             int n = s.size();
//             for (int left = 0, right = n-1; left < right; left++, right--) {
//                 swap(s[left], s[right]);
//             }
//         }
//     };
//
//
//
//     return 0;
//
// }
