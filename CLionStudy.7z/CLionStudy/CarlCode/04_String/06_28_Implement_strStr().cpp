// #include "iostream"
// #include <vector>
//
// using namespace std;
//
// // 28. 找出字符串中第一个匹配项的下标
//
// // strstr(s1, s2); 返回一个指针，指向字符串 s1 中字符串 s2 的第一次出现的位置(下标)
// // 这里就是利用KMP算法手动实现strstr()函数
//
// // KMP : Knuth-Morris-Pratt 算法
//
//
//
//
// int main() {
//
//     // 解法1：KMP算法：直接用next数组
//     // 时间复杂度: O(n + m)
//     // 空间复杂度: O(m)
//     class Solution {
//     public:
//         void getNext(int* next, const string& s) {
//             int j = 0;
//             next[0] = 0;
//             for(int i = 1; i < s.size(); i++) {
//                 while (j > 0 && s[i] != s[j]) {
//                     j = next[j - 1];
//                 }
//                 if (s[i] == s[j]) {
//                     j++;
//                 }
//                 next[i] = j;
//             }
//         }
//         int strStr(string haystack, string needle) {
//             if (needle.size() == 0) {
//                 return 0;
//             }
//             vector<int> next(needle.size());
//             getNext(&next[0], needle);
//             int j = 0;
//             for (int i = 0; i < haystack.size(); i++) {
//                 while(j > 0 && haystack[i] != needle[j]) {
//                     j = next[j - 1];
//                 }
//                 if (haystack[i] == needle[j]) {
//                     j++;
//                 }
//                 if (j == needle.size() ) {
//                     return (i - needle.size() + 1);
//                 }
//             }
//             return -1;
//         }
//     };
//
//
//
//
//
//
//
//
//     return 0;
//
// }
