// #include "iostream"
//
// using namespace std;
//
// // 卡码网：替换数字
//
//
//
//
// int main() {
//
//     // 解法1：
//     // 思路：首先查看输入的字符串里有多少个数字，扩容原字符串长度；其次定义双指针，分别从新老字符串从后往前遍历，
//     // 老指针遇到字母则将其赋值给新指针，遇数字，老指针不懂，新指针逐个把替换的字符填到新字符串中。
//     // 时间复杂度：O(n)
//     // 空间复杂度：O(1)
//
//         string s;
//         while (cin >> s) { // 确保用户输入的字符串不为空
//             int sOldIndex = s.size() - 1;
//             int count = 0;  // 统计数字的个数
//             for (int i = 0; i < s.size(); i++) {
//                 if (s[i] >= '0' && s[i] <= '9') {  // 这里数字为什么要加单引号
//                     count++;  // 注意这里判断一个字符是否是数字的方式
//                 }
//             }
//
//             s.resize(s.size() + count * 5); // 字符串扩容的库函数  // resize（重新设置）一下字符串的大小
//
//             int sNewIndex = s.size() - 1; // 新指针从后往前遍历扩容后的新数组
//
//             while (sOldIndex >= 0) { // 老指针从后往前遍历老数组
//                 if (s[sOldIndex] >= '0' && s[sOldIndex] <= '9') { // 老指针遇到数字停下，新指针替换数字
//                     s[sNewIndex--] = 'r'; // 每替换一个字符，新指针往前走一位
//                     s[sNewIndex--] = 'e';
//                     s[sNewIndex--] = 'b';
//                     s[sNewIndex--] = 'm';
//                     s[sNewIndex--] = 'u';
//                     s[sNewIndex--] = 'n';
//                 }else {
//                     s[sNewIndex--] = s[sOldIndex]; // 老指针遇到字符，将其赋值给新指针
//                 }
//
//                 sOldIndex--; // 老指针往前走一位
//
//             }
//
//             cout << s << endl;
//         }
//
//
//
//
//
//
//
//
//
//     return 0;
//
// }