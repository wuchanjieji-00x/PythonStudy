// #include "iostream"
// #include <algorithm>
// #include <string>
//
// using namespace std;
//
// // 右旋字符串
//
//
// // s.begin() + n : begin指向第一个元素，begin()+1 指向第二个元素
// // reverse函数是左闭右开
// // 字符串最后一个字符是\0， 所以长度是len-1,所以s.end()是指遍历到最后一个非\0的字符
//
//
//
// int main() {
//
//     // // 解法1：
//     // int n;
//     // string s;
//     // cin >> n >> s;
//     // int len = s.size();  //获取长度
//     //
//     // reverse(s.begin(), s.end());  // 整体反转
//     // reverse(s.begin(), s.begin() + n);  // 先反转前一段，长度n  // 其实只反转到n-1的位置
//     // reverse(s.begin() + n, s.end());  // 再反转后一段
//     //
//     //
//     // cout << s <<endl;
//     //
//     //
//     // // 解法2：先反转局部，后全局反转
//     // reverse(s.begin(), s.begin() + len - n); // 先反转前一段，长度len-n ，注意这里是和版本一的区别
//     // reverse(s.begin() + len - n, s.end()); // 再反转后一段
//     // reverse(s.begin(), s.end()); // 整体反转
//     // cout << s << endl;
//
//
//
// // 验证
//     // string s = {'a', 'b', 'c'};
//     // string s = {1,2,3};
//     // cout << s << endl;
//
//     // string s = "abcdefg";
//     // auto it = s.begin()+2;
//     // char firstChar = *it;
//     // cout << firstChar;
//
//
//     // string s = "abcdefg";
//     // int len = s.size();
//     // cout << len << endl;
//     //
//     // // reverse(s.begin(), s.end());
//     // // cout << s << endl;
//     // auto it = s.begin()+8;
//     // char firstChar = *it;
//     // cout << firstChar << endl;
//     // // reverse(s.begin(), s.begin()+5);
//     // // cout << s << endl;
//     // reverse(s.begin(), s.begin()+7);
//     // cout << s << endl;
//     // // reverse(s.begin(), s.end());
//     //
//     // // cout << s;  // 输出 "!dlroW ,olleH"
//
//
//
//     // // 左旋
//     // // 其实就是反转的区间不同而已
//     // int n;
//     // string s;
//     // cin >> n;
//     // cin >> s;
//     // int len = s.size(); //获取长度
//     // reverse(s.begin(), s.begin() + n); //  反转第一段长度为n
//     // reverse(s.begin() + n, s.end()); // 反转第二段长度为len-n
//     // reverse(s.begin(), s.end());  // 整体反转
//     // cout << s << endl;
//
//
//
//
//
//
//
//
//
//     return 0;
//
// }
