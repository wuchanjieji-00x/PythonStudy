// #include "iostream"
//
// using namespace std;
//
// // 459.重复的子字符串
//
//
// // 没看懂
//
//
//
//
// int main() {
//
//     // 解法1：
//     // 时间复杂度: O(n)
//     // 空间复杂度: O(n)
//
//     // 前缀表（不减一）的C++代码实现
//     class Solution {
//     public:
//         void getNext (int* next, const string& s){
//             next[0] = 0;
//             int j = 0;
//             for(int i = 1;i < s.size(); i++){
//                 while(j > 0 && s[i] != s[j]) {
//                     j = next[j - 1];
//                 }
//                 if(s[i] == s[j]) {
//                     j++;
//                 }
//                 next[i] = j;
//             }
//         }
//         bool repeatedSubstringPattern (string s) {
//             if (s.size() == 0) {
//                 return false;
//             }
//             int next[s.size()];
//             getNext(next, s);
//             int len = s.size();
//             if (next[len - 1] != 0 && len % (len - (next[len - 1] )) == 0) {
//                 return true;
//             }
//             return false;
//         }
//     };
//
//
//
//
//
//
//     return 0;
//
// }
