# collections是Python内建的一个集合模块，提供了许多有用的集合类
#
#
# namedtuple
# 我们知道tuple可以表示不变集合，例如，一个点的二维坐标就可以表示成：
# p = (1, 2)
# 但是，看到(1, 2)，很难看出这个tuple是用来表示一个坐标的
# 定义一个class又小题大做了，这时，namedtuple就派上了用场：
# from collections import namedtuple
# Point = namedtuple('Point',['x','y'])
# p = Point(1,2)
# print(p)
# print(p.x)
# print(p.y)
# namedtuple是一个函数，它用来创建一个自定义的tuple对象，并且规定了tuple元素的个数，并可以用属性而不是索引来引用tuple的某个元素。
# 这样一来，我们用namedtuple可以很方便地定义一种数据类型，它具备tuple的不变性，又可以根据属性来引用，使用十分方便。
# 可以验证创建的Point对象是tuple的一种子类：
# print(isinstance(p,Point))
# print(isinstance(p,tuple))

# 类似的，如果要用坐标和半径表示一个圆，也可以用namedtuple定义：
# namedtuple('名称',[属性list]):
# from collections import namedtuple
# Circle = namedtuple('Circle', ['x', 'y', 'r'])
# c = Circle(1, 2, 3)
# print(c.x)
# print(c.y)
# print(c.r)



# deque
# 使用list存储数据时，按索引访问元素很快，但是插入和删除元素就很慢了，因为list是线性存储，数据量大的时候，插入和删除效率很低。
# deque是为了高效实现插入和删除操作的双向列表，适合用于队列和栈：
# from collections import deque
# q = deque(['a', 'b', 'c', 'a'])
# q.append('x')
# q.appendleft('y')
# q.pop()
# q.popleft()
# print(q)
# # deque除了实现list的append()和pop()外，还支持appendleft()和popleft()，这样就可以非常高效地往头部添加或删除元素



# defaultdict
# 使用dict时，如果引用的Key不存在，就会抛出KeyError。
# 如果希望key不存在时，返回一个默认值，就可以用defaultdict：
# from collections import defaultdict
# dd = defaultdict(lambda: 'N/A')
# dd['key1'] = 'abc'   # key1存在
# print(dd['key1']) # abc
# print(dd['key2']) # N/A
# 注意默认值是调用函数返回的，而函数在创建defaultdict对象时传入。
# 除了在Key不存在时返回默认值，defaultdict的其他行为跟dict是完全一样的。



# OrderedDict
# 使用dict时，Key是无序的。
# 在对dict做迭代时，我们无法确定Key的顺序。
# 如果要保持Key的顺序，可以用OrderedDict：
# from collections import OrderedDict
# d = dict([('a', 1), ('b', 2), ('c', 3)])
# print(d) # dict的Key是无序的  {'a': 1, 'b': 2, 'c': 3}
# od = OrderedDict([('c', 1), ('b', 2), ('a', 3)])
# print(od) # OrderedDict的Key是有序的
# # 注意，OrderedDict的Key会按照插入的顺序排列，不是Key本身排序：
# od = OrderedDict()
# od['z'] = 3
# od['y'] = 1
# od['x'] = 2
# print(list(od.keys()))  # 按照插入的Key的顺序返回

# OrderedDict可以实现一个FIFO（先进先出）的dict，当容量超出限制时，先删除最早添加的Key：
# from collections import OrderedDict
#
# class LastUpdatedOrderedDict(OrderedDict):
#
#     def __init__(self, capacity):
#         super(LastUpdatedOrderedDict, self).__init__()
#         self._capacity = capacity
#
#     def __setitem__(self, key, value):
#         containsKey = 1 if key in self else 0
#         if len(self) - containsKey >= self._capacity:
#             last = self.popitem(last=False)
#             print('remove:', last)
#         if containsKey:
#             del self[key]
#             print('set:', (key, value))
#         else:
#             print('add:', (key, value))
#         OrderedDict.__setitem__(self, key, value)




# ChainMap
# ChainMap可以把一组dict串起来并组成一个逻辑上的dict。
# ChainMap本身也是一个dict，但是查找的时候，会按照顺序在内部的dict依次查找。
# 什么时候使用ChainMap最合适？

# ChainMap的作用是对多个字典dict进行链接
# emm简单来说就是把几个字典绑在了一起变成一个所有字典总和的大字典，但是注意这不等同于拼接！
# 跟普通的字典拼接相比最主要的区别就是这个大字典里能保存一样的键key！
# 当你用被重复的key去访问Value的时候得到的一定是在大字典里位置靠前的Value，
# 被链接起来的字典会因为排序不同而产生优先级！

# 举个例子：应用程序往往都需要传入参数，参数可以通过命令行传入，可以通过环境变量传入，还可以有默认参数。
# 我们可以用ChainMap实现参数的优先级查找，即先查命令行参数，如果没有传入，再查环境变量，如果没有，就使用默认参数。
# 下面的代码演示了如何查找user和color这两个参数：
# from collections import ChainMap
# import os, argparse
#
# # 构造缺省参数：
# defaults = {
#     'color': 'red',
#     'user': 'guest'
# }   # 默认参数-字典
#
#
# # 构造命令行参数：
# parser = argparse.ArgumentParser()     # 参数解析器，不懂的暂时也不用去管
# parser.add_argument('-u', '--user')    # 配置解析器，
# parser.add_argument('-c', '--color')   # 同上，↑记住 ’-u‘ 这两个字符就ok
# namespace = parser.parse_args()        # 运行解析器了
# command_line_args = {k: v for k, v in vars(namespace).items() if v}  # 命令行参数-字典
# 将解析器分成了无数个小部分并用字典生成器重做成一个保存有解析器信息的字典
# { k: v for k, v in vars(namespace).items() if v }是字典生成器
# vars(namespace).items() #vars获取namespace解析器属性并以dict形式返回，items()将dict转为list
#
# # 组合成ChainMap：
# combined = ChainMap(command_line_args, os.environ, defaults) # 绑着三个字典的“大字典”
# 用ChainMap 链接3字典，分别是：命令行参数-字典、环境变量参数-字典、默认参数-字典
# 命令行参数-字典 在最前位置具有最高优先级，默认参数-字典 优先级最低
#
# # 打印参数：
# print('color = %s' % combined['color'])  # 打印大字典combined['color']对应的value
# print('user = %s' % combined['user'])    # 打印......
# 没有任何参数时，打印出默认参数
# 按优先级查找combined['color']...最先在命令行参数-字典里查找对应的key，没有找到...再在环境变量里找，
# 还没找到...最后去默认参数里找，找到了！打印defaults['color']
# 命令行参数、环境变量可以且只能在cmd里添加的...这一节只是讲ChainMap的拓展用法，实际上很少用到不清楚也没事



# Counter
# Counter是一个简单的计数器，例如，统计字符出现的个数：
from collections import Counter
c = Counter()
for ch in 'programming':
    c[ch] = c[ch] + 1
print(c) # 输出是无序的
c.update('hello')  # 也可以一次性update   把hello加进来
print(c) # 输出是无序的



# 小结
# collections模块提供了一些有用的集合类，可以根据需要选用。



