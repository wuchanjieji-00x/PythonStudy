import sys
print(sys.argv)
source = sys.argv[1]
target = sys.argv[2]