# 在1966年，Seymour Papert和Wally Feurzig发明了一种专门给儿童学习编程的语言——LOGO语言，
# 它的特色就是通过编程指挥一个小海龟（turtle）在屏幕上绘图。
#
# 海龟绘图（Turtle Graphics）后来被移植到各种高级语言中，Python内置了turtle库，基本上100%复制了原始的Turtle Graphics的所有功能。
#
# 我们来看一个指挥小海龟绘制一个长方形的简单代码：

# 导入turtle包的所有内容:
# from turtle import *
#
# # 设置笔刷宽度:
# width(4)
#
# # 前进:
# forward(200)
# # 右转90度:
# right(90)
#
# # 笔刷颜色:
# pencolor('red')
# forward(100)
# right(90)
#
# pencolor('green')
# forward(200)
# right(90)
#
# pencolor('blue')
# forward(100)
# right(90)
#
# # 调用done()使得窗口等待被关闭，否则将立刻关闭窗口:
# done()

# 在命令行运行上述代码，会自动弹出一个绘图窗口，然后绘制出一个长方形：


# 从程序代码可以看出，海龟绘图就是指挥海龟前进、转向，海龟移动的轨迹就是绘制的线条。要绘制一个长方形，只需要让海龟前进、右转90度，反复4次
# 调用width()函数可以设置笔刷宽度，调用pencolor()函数可以设置颜色。更多操作请参考turtle库的说明。
# 绘图完成后，记得调用done()函数，让窗口进入消息循环，等待被关闭。否则，由于Python进程会立刻结束，将导致窗口被立刻关闭。

# turtle包本身只是一个绘图库，但是配合Python代码，就可以绘制各种复杂的图形。例如，通过循环绘制5个五角星：
# from turtle import *
#
# def drawStar(x, y):
#     pu()
#     goto(x, y)
#     pd()
#     # set heading: 0
#     seth(0)
#     for i in range(5):
#         fd(40)
#         rt(144)
#
# for x in range(0, 250, 50):
#     drawStar(x, 0)
#
# done()
# 程序执行效果如下：



# 使用递归，可以绘制出非常复杂的图形。
# 例如，下面的代码可以绘制一棵分型树：
from turtle import *

# 设置色彩模式是RGB:
colormode(255) #设置画笔颜色模式，为随机生成RGB色彩做准备

lt(90)

lv = 14
l = 120
s = 45

width(lv)

# 初始化RGB颜色:
r = 0
g = 0
b = 0
pencolor(r, g, b)

penup()
bk(l)
pendown()
fd(l)

def draw_tree(l, level):
    global r, g, b
    # save the current pen width
    w = width()

    # narrow the pen width
    width(w * 3.0 / 4.0)
    # set color:
    r = r + 1
    g = g + 2
    b = b + 3
    pencolor(r % 200, g % 200, b % 200)

    l = 3.0 / 4.0 * l

    lt(s)
    fd(l)

    if level < lv:
        draw_tree(l, level + 1)
    bk(l)
    rt(2 * s)
    fd(l)

    if level < lv:
        draw_tree(l, level + 1)
    bk(l)
    lt(s)

    # restore the previous pen width
    width(w)

speed("fastest")

draw_tree(l, 4)

done()


# 秀儿评论
# from turtle import Turtle,done,colormode,setup,title
#
# from random import randint,uniform
#
# title('给我一点时间，还你一棵树')
#
# colormode(255)      #设置画笔颜色模式，为随机生成RGB色彩做准备
#
# p1 = Turtle()       #实例化一个画笔
#
# p1.width(20)       #设置画笔宽度，初始宽度，主树干宽度
#
# p1.speed(100)      #设置画笔速度，具体是多少最快，查阅一下
#
# p1.pencolor(randint(0,254),randint(0,254),randint(0,254))      #初始画笔颜色,这是随机颜色，可以用0,0,0,表示黑色
#
# p1.hideturtle()    #隐藏画笔外形
#
# l = 150   #初始树干长度
#
# s = 45    #侧枝生长角度  ，这里可以改，观察生长状态
#
# p1.lt(90)          #默认画笔在画布正中央，方向向右，lt(90)调整为向上。
#
# p1.penup()         #提起画笔，以便直接调整画笔位置，移动路径画布上没有痕迹
#
# p1.bk(l)           #向后（向下）移动，调整树干起点
#
# p1.pendown()       #落下画笔，可以继续画
#
# p1.fd(l)           #画主树干
#
# plist = [p1]       #列表化画笔，便于树干分支控制
#
# def draw_tree(plist,l,s,level):      #参数level为分支层数，数值越大分支越多，相对画的时间也越长。
#
#     l = l*uniform(0.7,0.8)           #分支树干为上一个的随机比例，这里可以改
#
#     for p1 in plist:
#
#         w = p1.width()
#
#         p1.width(w*3/4)
#
#         p1.pencolor(randint(0,254),randint(0,254),randint(0,254))
#
#         p2 = p1.clone()
#
#         p1.lt(s)
#
#         p1.fd(l)
#
#         p2.rt(s)
#
#         p2.fd(l)
#
#         lst = []
#
#         lst.append(p1)
#
#         lst.append(p2)
#
#         if level > 0:
#
#             draw_tree(lst,l,s,level-1)
#
# draw_tree(plist,l,s,5)
#
# done()
