# !/usr/bin/env python3
# -*- coding: utf-8 -*-

# reduce把一个函数作用在一个序列[x1, x2, x3, ...]上，这个函数必须接收两个参数，reduce把结果继续和序列的下一个元素做累积计算
# reduce(f, [x1, x2, x3, x4]) = f(f(f(x1, x2), x3), x4)

# 比方说对一个序列求和，就可以用reduce实现：
from functools import reduce
def add(x,y):
    return x+y
print (reduce(add,[1,3,5,7,9]))
# 当然求和运算可以直接用Python内建函数sum()，没必要动用reduce
print (sum(x for x in range(10) if x % 2 != 0))

# 如果要把序列[1, 3, 5, 7, 9]变换成整数13579，reduce就可以派上用场
from functools import reduce
def fn(x,y):
    return x * 10 + y
print (reduce(fn,[1,3,5,7,9]))

# 如果考虑到字符串str也是一个序列，对上面的例子稍加改动，配合map()，我们就可以写出把str转换为int的函数：
from functools import reduce
def fn(x,y):
    return x*10+y
def char2num(s):
    digits = {'0':0,'1':1,'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9}
    return digits[s]
print (reduce(fn,map(char2num,'13579')))

# 整理成一个str2int的函数就是：
from functools import reduce
DIGITS = {'0': 0, '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9}

def str2int(s):
    def fn(x,y):
        return x*10+y
    def char2num(s):
        return DIGITS(s)
    return reduce(fn,map(char2num,s))
print (reduce(fn,map(char2num,'13579')))


# 还可以用lambda函数进一步简化成：
from functools import reduce
DIGITS = {'0': 0, '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9}
def char2num(s):
        return DIGITS(s)
def str2int(s):
     return reduce(lambda x,y:x*10+y,map(char2num,s))
# print (str2int('13579'))
# 也就是说，假设Python没有提供int()5_函数，你完全可以自己写一个把字符串转化为整数的函数，而且只需要几行代码



# 练习1
# 利用map()5_函数，把用户输入的不规范的英文名字，变为首字母大写，其他小写的规范名字。输入：['adam', 'LISA', 'barT']，输出：['Adam', 'Lisa', 'Bart']：



# 练习2
# Python提供的sum()函数可以接受一个list并求和，请编写一个prod()5_函数，可以接受一个list并利用reduce()求积：



# 练习3
def str2float(s):
    integer, decimal = s.split('.')
    def fn(x, y):
        return x * 10 + y
    def char2num(s):
        digits = {'0': 0, '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9}
        return digits[s]
    return reduce(fn, map(char2num, integer)) + reduce(fn, map(char2num, decimal)) / (10**len(decimal))
print('str2float(\'123.456\') =', str2float('123.456'))
if abs(str2float('123.456') - 123.456) < 0.00001:
    print('测试成功!')
else:
    print('测试失败!')



# 源码
from functools import reduce

CHAR_TO_INT = {
    '0': 0,
    '1': 1,
    '2': 2,
    '3': 3,
    '4': 4,
    '5': 5,
    '6': 6,
    '7': 7,
    '8': 8,
    '9': 9
}

def str2int(s):
    ints = map(lambda ch: CHAR_TO_INT[ch], s)
    return reduce(lambda x, y: x * 10 + y, ints)

print(str2int('0'))
print(str2int('12300'))
print(str2int('0012345'))




CHAR_TO_FLOAT = {
    '0': 0,
    '1': 1,
    '2': 2,
    '3': 3,
    '4': 4,
    '5': 5,
    '6': 6,
    '7': 7,
    '8': 8,
    '9': 9,
    '.': -1
}

def str2float(s):
    nums = map(lambda ch: CHAR_TO_FLOAT[ch], s)
    point = 0
    def to_float(f, n):
        nonlocal point
        if n == -1:
            point = 1
            return f
        if point == 0:
            return f * 10 + n
        else:
            point = point * 10
            return f + n / point
    return reduce(to_float, nums, 0.0)

print(str2float('0'))
print(str2float('123.456'))
print(str2float('123.45600'))
print(str2float('0.1234'))
print(str2float('.1234'))
print(str2float('120.0034'))
