# !/usr/bin/env python3
# -*- coding: utf-8 -*-


# 1.变量可以指向函数
print (abs(-10))
print (abs)  # built-in function abs
# 可见，abs(-10)是函数调用，而abs是函数本身

# 要获得函数调用结果，我们可以把结果赋值给变量：
x = abs(-10)
print (x)  

# 但是，如果把函数本身赋值给变量呢？
f = abs   # 注意，这里是abs，不是abs()
print (f)  # built-in function abs
# 结论：函数本身也可以赋值给变量，即：变量可以指向函数

# 如果一个变量指向了一个函数，那么，可否通过该变量来调用这个函数？
print (f(-10))
# 成功！说明变量f现在已经指向了abs函数本身。直接调用abs()函数和调用变量f()完全相同。

# 注：由于abs函数实际上是定义在import builtins模块中的，所以要让修改abs变量的指向在其它模块也生效，要用import builtins; builtins.abs = 10



# 2.函数名也是变量
# 函数名其实就是指向函数的变量！对于abs()这个函数，完全可以把函数名abs看成变量，它指向一个可以计算绝对值的函数！
# abs = 10
# print (abs(-10))  # 'int' object is not callable
# abs已经指向int了，不再是指向计算绝对值的函数了



# 3.传入函数
# 既然变量可以指向函数，函数的参数能接收变量，那么一个函数就可以接收另一个函数作为参数，这种函数就称之为高阶函数
# 编写高阶函数，就是让函数的参数能够接收别的函数
def add(x,y,f):
    return f(x)+f(y)
print (add(-5,6,f))  # print (add(-5,6,abs))



# 小结
# 把函数作为参数传入，这样的函数称为高阶函数
# 函数式编程就是指这种高度抽象的编程范式