# !/usr/bin/env python3
# -*- coding: utf-8 -*-

# 排序算法
# 排序也是在程序中经常用到的算法。无论使用冒泡排序还是快速排序，排序的核心是比较两个元素的大小

# Python内置的sorted()函数就可以对list进行排序：
print (sorted([36,5,-12,9,-21]))

# 此外，sorted()函数也是一个高阶函数，它还可以接收一个key函数来实现自定义的排序，例如按绝对值大小排序
print (sorted([36,5,-12,9,-21],key=abs))  # 按照绝对值大小将list的元素进行排序

# key指定的函数将作用于list的每一个元素上，并根据key函数返回的结果进行排序
# 原始list = [36,5,-12,9,-21]
# 经过key=abs处理过的list = [36, 5,  12, 9,  21]
# 然后sorted()函数按照keys进行排序，并按照对应关系返回list相应的元素



# 字符串排序的例子
print (sorted(['bob','about','Zoo','Credit'])) # 由于'Z' < 'a'，结果，大写字母Z会排在小写字母a的前面
# 默认情况下，对字符串排序，是按照ASCII的大小比较的
# 现在，我们提出排序应该忽略大小写，按照字母序排序, 只要我们能用一个key函数把字符串映射为忽略大小写排序即可
# 忽略大小写来比较两个字符串，实际上就是先把字符串都变成大写（或者都变成小写），再比较。

# 这样，我们给sorted传入key函数，即可实现忽略大小写的排序：
print (sorted(['bob','about','Zoo','Credit'],key=str.lower))  # 先把字符串都变成小写，再比较。

# 要进行反向排序，不必改动key函数，可以传入第三个参数reverse=True：
print (sorted(['bob','about','Zoo','Credit'],key=str.lower,reverse=True))

# 从上述例子可以看出，高阶函数的抽象能力是非常强大的，而且，核心代码可以保持得非常简洁。



# 小结
# sorted()也是一个高阶函数。用sorted()排序的关键在于实现一个映射函数


# 练习 1
# 假设我们用一组tuple表示学生名字和成绩：
L = [('Bob', 75), ('Adam', 92), ('Bart', 66), ('Lisa', 88)]
# 请用sorted()对上述列表分别按名字排序：
def by_name(t):
    return t[0]   #  # 这里的t是L的每一个元素，t[1]是指L每一个元素内的第一个元素
L2 = sorted(L, key=by_name)
print(L2)

# 再按成绩从高到低排序：
def by_score(t):
    return -t[1]    # 这里的t是L的每一个元素，t[1]是指L每一个元素内的第二个元素;负号是指倒序排列，从高到低
L2 = sorted(L, key=by_score)
print(L2)



# 源码
from operator import itemgetter

L = ['bob', 'about', 'Zoo', 'Credit']

print(sorted(L))
print(sorted(L, key=str.lower))

students = [('Bob', 75), ('Adam', 92), ('Bart', 66), ('Lisa', 88)]

print(sorted(students, key=itemgetter(0)))
print(sorted(students, key=lambda t: t[1]))
print(sorted(students, key=itemgetter(1), reverse=True))