# -*- coding: utf-8 -*-

n = 0
while n < 10:
    n = n + 1
    print (n)
print ('END')

m = 0
while m < 10:
    m = m + 1
    if m % 2 == 0:
        continue
    print (m)
print ('END')
