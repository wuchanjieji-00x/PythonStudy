# -*- coding: utf-8 -*-

# 字符串和编码
r = 2.5
s = 3.14*r**2
print(f'The area of a circle with radius {r} is {s:.2f}')
# print('The area of a circle with radius {r} is {s:.2f} error')

s1 = 72
s2 = 85
r = (s2-s1)/s2*100
print('小明成绩提升的百分点是 %.1f%%' % r)