# -*- coding: utf-8 -*-

# 使用list 和 tuple

classmates = ('A''B''C''D')
classmates.append('E')
print (classmates)