# -*- coding: utf-8 -*-

# for 循环

# names = ['michael','Bob','Tracy']
# for name in names:
#    print (name)

#sum = 0
#for x in [1,2,3,4,5,6,7,8,9,10]:
#    sum = sum + x
#    print (sum)
#print (sum)

#list(range(5))

sum = 0
for x in range(101):
    sum = sum + x
print (sum)