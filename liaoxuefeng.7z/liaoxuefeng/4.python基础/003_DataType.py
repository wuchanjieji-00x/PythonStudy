﻿# -*- coding: utf-8 -*-

# 布尔值
#True
#False 
#3>2
#3>5

# True and True
# True and False
# False and False
# 5>3 and 3>1

# True or True
# True or False
# False or False
# 5 > 3 or 1 > 3

# not True
# not False
# not 1>2

# age = 20
# if age >=18:
#     print('adult');
# else:
#     print('teenager')

# a=123  # a是整数
# print(a)
# a='ABC' # a是字符串
# print(a)

# 变量
# a = 'ABC'
# b = a
# a = 'XYZ'
# print(a)

# 常量
# 所谓常量就是不能变的变量，比如常用的数学常数π就是一个常量。在Python中，通常用全部大写的变量名表示常量
# PI = 3.14159265359

# 除法
# 在Python中，有两种除法，一种除法是/ 
# 10 / 3 # 除法计算结果是浮点数
# 9/3 # 即使是两个整数恰好整除，结果也是浮点数
# 还有一种除法是//，称为地板除
# 10//3 # 两个整数的除法仍然是整数，只取结果的整数部分
# 你没有看错，整数的地板除//永远是整数，即使除不尽。要做精确的除法，使用/就可以
# 因为//除法只取结果的整数部分，所以Python还提供一个余数运算，可以得到两个整数相除的余数
# 10 % 3 # 取余







