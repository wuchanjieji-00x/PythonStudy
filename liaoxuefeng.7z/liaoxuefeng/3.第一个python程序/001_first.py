# print 'Hello, world'
# print 'hello','this is the first python code','amazing'
# print 300
# print 100+200
#print '100+200 =',100+200

# 输入和输出
# 任何计算机程序都是为了执行一个特定的任务，有了输入，用户才能告诉计算机程序所需的信息，有了输出，程序运行后才能告诉用户任务的结果
# 输入是Input，输出是Output，因此，我们把输入输出统称为Input/Output，或者简写为IO
# input()和print()是在命令行下面最基本的输入和输出，但是，用户也可以通过其他更高级的图形界面完成输入和输出，比如，在网页上的一个文本框输入自己的名字，点击“确定”后在网页上看到输出信息。
#name = input()
#print ('hello,',name)
name = input('please enter your name:')
print('hello',name)
