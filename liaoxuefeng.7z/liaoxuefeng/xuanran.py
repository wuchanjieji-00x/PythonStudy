from manim import *


class MovingCircle(Scene):
    def construct(self):
        circle = Circle()  # Create a circle
        circle.set_fill(PINK, opacity=0.5)  # Set the color and transparency

        self.play(Create(circle))  # Display the circle on the screen
        self.play(circle.animate.shift(RIGHT * 2))  # Move the circle to the right

