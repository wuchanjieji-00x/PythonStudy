# !/usr/bin/env python3     # 第1行注释可以让这个hello.py文件直接在Unix/Linux/Mac上运行
# -*- coding: utf-8 -*-     # 第2行注释表示.py文件本身使用标准UTF-8编码



# 如果我们要操作文件、目录，可以在命令行下面输入操作系统提供的各种命令来完成。比如dir、cp等命令。
# 如果要在Python程序中执行这些目录和文件的操作怎么办？
# 其实操作系统提供的命令只是简单地调用了操作系统提供的接口函数，Python内置的os模块也可以直接调用操作系统提供的接口函数。

# 打开Python交互式命令行，我们来看看如何使用os模块的基本功能：
'''
>>> import os
>>> os.name # 操作系统类型
'posix'
'''
# 如果是posix，说明系统是Linux、Unix或Mac OS X，如果是nt，就是Windows系统。

# 要获取详细的系统信息，可以调用uname()5_函数：
'''
>>> os.uname()
posix.uname_result(sysname='Darwin', nodename='MichaelMacPro.local', release='14.3.0', 
version='Darwin Kernel Version 14.3.0: Mon Mar 23 11:59:05 PDT 2015; root:xnu-2782.20.48~5/RELEASE_X86_64', machine='x86_64')
'''
# 注意uname()函数在Windows上不提供，也就是说，os模块的某些函数是跟操作系统相关的。



# 环境变量
# 在操作系统中定义的环境变量，全部保存在os.environ这个变量中，可以直接查看：
'''
>>> os.environ
environ({'VERSIONER_PYTHON_PREFER_32_BIT': 'no', 'TERM_PROGRAM_VERSION': '326', 'LOGNAME': 'michael',
 'USER': 'michael', 'PATH': '/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin:/opt/X11/bin:/usr/local/mysql/bin', ...})
'''

# 要获取某个环境变量的值，可以调用os.environ.get('key')：
'''
>>> os.environ.get('PATH')
'/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin:/opt/X11/bin:/usr/local/mysql/bin'
>>> os.environ.get('x', 'default')
'default'
'''



# 操作文件和目录
# 操作文件和目录的函数一部分放在os模块中，一部分放在os.path模块中，这一点要注意一下。
# 查看、创建和删除目录可以这么调用：
'''
# 查看当前目录的绝对路径:
>>> os.path.abspath('.')
'/Users/michael'
# 在某个目录下创建一个新目录，首先把新目录的完整路径表示出来:
>>> os.path.join('/Users/michael', 'testdir')
'/Users/michael/testdir'
# 然后创建一个目录:
>>> os.mkdir('/Users/michael/testdir')
# 删掉一个目录:
>>> os.rmdir('/Users/michael/testdir')
'''

# 把两个路径合成一个时，不要直接拼字符串，而要通过os.path.join()5_函数，这样可以正确处理不同操作系统的路径分隔符。在Linux/Unix/Mac下，os.path.join()返回这样的字符串：
# part-1/part-2
# 而Windows下会返回这样的字符串：
# part-1\part-2

# 同样的道理，要拆分路径时，也不要直接去拆字符串，而要通过os.path.split()5_函数，这样可以把一个路径拆分为两部分，后一部分总是最后级别的目录或文件名：
'''
>>> os.path.split('/Users/michael/testdir/file.txt')
('/Users/michael/testdir', 'file.txt')
'''

# os.path.splitext()可以直接让你得到文件扩展名，很多时候非常方便：
'''
>>> os.path.splitext('/path/to/file.txt')
('/path/to/file', '.txt')
'''

# 这些合并、拆分路径的函数并不要求目录和文件要真实存在，它们只对字符串进行操作。


# 文件操作使用下面的函数。假定当前目录下有一个test.txt文件：
'''
# 对文件重命名:
>>> os.rename('test.txt', 'test.py')
# 删掉文件:
>>> os.remove('test.py')
'''
# 但是复制文件的函数居然在os模块中不存在！原因是复制文件并非由操作系统提供的系统调用
# 理论上讲，我们通过上一节的读写文件可以完成文件复制，只不过要多写很多代码。
# 幸运的是shutil模块提供了copyfile()的函数，你还可以在shutil模块中找到很多实用函数，它们可以看做是os模块的补充

# 最后看看如何利用Python的特性来过滤文件。比如我们要列出当前目录下的所有目录，只需要一行代码：
'''
>>> [x for x in os.listdir('.') if os.path.isdir(x)]
['.lein', '.local', '.m2', '.npm', '.ssh', '.Trash', '.vim', 'Applications', 'Desktop', ...]
'''

# 要列出所有的.py文件，也只需一行代码：
'''
[x for x in os.listdir('.') if os.path.isfile(x) and os.path.splitext(x)[1]=='.py']
'''




# 小结
# Python的os模块封装了操作系统的目录和文件操作，要注意这些函数有的在os模块中，有的在os.path模块中。



# 练习
# https://blog.csdn.net/qq_40906557/article/details/88913088?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522166713623916782428649962%2522%252C%2522scm%2522%253A%252220140713.130212432.pc%255Fall.%2522%257D&request_id=166713623916782428649962&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~first_rank_ecpm_v1~hot_rank-1-88913088-null-null.142^v62^opensearch_v2,201^v3^control_2,213^v1^t3_esquery_v2&utm_term=%E5%BB%96%E9%9B%AA%E5%B3%B0%20%E6%93%8D%E4%BD%9C%E6%96%87%E4%BB%B6%E5%92%8C%E7%9B%AE%E5%BD%95&spm=1018.2226.3001.4187
# 1.利用os模块编写一个能实现dir -l输出的程序。
import os,time
path = r'C:\Users\dell\work'
filenum,filesize,dirnum = 0,0,0
for name in os.listdir(path):

#listdir(dir)返回dir路径下所有的文件和目录

    if os.path.isfile(name):
        print('%s\t\t%d\t%s'%(time.strftime('%Y/%m/%d%H:%M',time.localtime(os.path.getmtime(name))),os.path.getsize(name),name))
        #\t是制表符 使得对齐,一个\t,8个位置
        #os.path.getmtime(name) 获得name文件的最后修改的时间（时间戳）
        #time.localtime() 将Timestamp对象转换为struct_time对象
        #strftime()将struct_time对象转换为格式化时间 2009/01/07 23:54
        filenum= filenum+1
        filesize += os.path.getsize(name)
        
    if os.path.isdir(name):
        print('%s\t<DIR>\t\t%s'%(time.strftime('%Y/%m/%d %H:%M',time.localtime(os.path.getmtime(name))),name))
        dirnum+=1
    print('\t\t%d个文件\t\t%d个字节'%(filenum,filesize))
    print('\t\t%d个目录'%dirnum)



# 2. 编写一个程序，能在当前目录以及当前目录的所有子目录下查找文件名包含指定字符串的文件，并打印出相对路径。
import os
def search(text,path ='.'):
    for name in os.listdir():
        current = os.path.join(path,name)#递归得以实现的关键
        if os.path.isdir(name):
            search(text,current)
        elif name.find(text)!= -1:
            print(current)

if __name__ == '__main__':
    text = input('Please input')
    search(text)





# 源码
from datetime import datetime
import os

pwd = os.path.abspath('..')

print('      Size     Last Modified  Name')
print('------------------------------------------------------------')

for f in os.listdir(pwd):
    fsize = os.path.getsize(f)
    mtime = datetime.fromtimestamp(os.path.getmtime(f)).strftime('%Y-%m-%d %H:%M')
    flag = '/' if os.path.isdir(f) else ''
    print('%10d  %s  %s%s' % (fsize, mtime, f, flag))