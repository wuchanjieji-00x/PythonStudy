# !/usr/bin/env python3     # 第1行注释可以让这个hello.py文件直接在Unix/Linux/Mac上运行
# -*- coding: utf-8 -*-     # 第2行注释表示.py文件本身使用标准UTF-8编码


# 在Python中，安装第三方模块，是通过包管理工具pip完成的
# 如果你正在使用Mac或Linux，安装pip本身这个步骤就可以跳过了
# 如果你正在使用Windows，请参考安装Python一节的内容，确保安装时勾选了pip和Add python.exe to Path





# 模块搜索路径
# 当我们试图加载一个模块时，Python会在指定的路径下搜索对应的.py文件，如果找不到，就会报错：
# import mymodule   # No module named 'mymodule'
# 默认情况下，Python解释器会搜索当前目录、所有已安装的内置模块和第三方模块
# 搜索路径存放在sys模块的path变量中：
import sys
print (sys.path)


# 如果我们要添加自己的搜索目录，有两种方法：
# 一是直接修改sys.path，添加要搜索的目录：
import sys
print (sys.path.append('Users/xiaozh52/pythonstudy/picturePool'))
# 这种方法是在运行时修改，运行结束后失效。

# 第二种方法是设置环境变量PYTHONPATH，该环境变量的内容会被自动添加到模块搜索路径中。
# 设置方式与设置Path环境变量类似。注意只需要添加你自己的搜索路径，Python自己本身的搜索路径不受影响。